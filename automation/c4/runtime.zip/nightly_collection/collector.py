"""Isolated RAID collection. Python 3.14, standard library only; never imports the GUI.

Commands: prepare, sample, run, status, verify, self-test.
Only this script's directory is writable. run resumes durable per-champion results.
"""
from __future__ import annotations

import argparse
import copy
import gzip
import hashlib
import json
import logging
import os
import re
import signal
import sys
import time
import traceback
import unicodedata
import urllib.error
import urllib.parse
import urllib.request
import urllib.robotparser
from collections import Counter, defaultdict
from datetime import datetime, timezone, timedelta
from html.parser import HTMLParser
from html import unescape
from pathlib import Path

HOME = Path(__file__).resolve().parent
PROJECT = HOME.parent
KST = timezone(timedelta(hours=9))
UA = "RAIDChampionDBNightly/1.0 (personal research; sequential requests)"
SOURCES = {"hellhades": "https://hellhades.com", "ayumilove": "https://ayumilove.net"}
VERSION = "3"
STOP = False
LOG = logging.getLogger("raid-nightly")


def now():
    return datetime.now(KST).isoformat(timespec="seconds")


def norm(value):
    # No edit distance, punctuation stripping, generated slugs, or inferred aliases.
    return " ".join(unicodedata.normalize("NFC", unescape(str(value or ""))).casefold().split())


def digest(data):
    return hashlib.sha256(data).hexdigest()


def local(path):
    path = Path(path).resolve()
    if path != HOME and HOME not in path.parents:
        raise ValueError("Refusing a write outside the isolated collection directory: " + str(path))
    return path


def atomic_bytes(path, data):
    path = local(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    with temp.open("wb") as stream:
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temp, path)


def save(path, value):
    atomic_bytes(path, (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode("utf-8"))


def read(path, default=None):
    return json.loads(Path(path).read_text(encoding="utf-8-sig")) if Path(path).exists() else copy.deepcopy(default)


class Node:
    def __init__(self, tag="document", attrs=(), parent=None, order=0):
        self.tag, self.attrs, self.parent, self.order = tag, dict(attrs), parent, order
        self.children = []

    def text(self):
        if self.tag in ("script", "style", "noscript"):
            return ""
        return " ".join(" ".join(c.text() if isinstance(c, Node) else c for c in self.children).split())

    def all(self, tag=None, **attrs):
        result = []
        for child in self.children:
            if not isinstance(child, Node):
                continue
            if (tag is None or child.tag == tag) and all(child.attrs.get(k) == v for k, v in attrs.items()):
                result.append(child)
            result.extend(child.all(tag, **attrs))
        return result

    def has_class(self, value):
        return value in self.attrs.get("class", "").split()

    def ancestor(self, predicate):
        p = self.parent
        while p:
            if predicate(p):
                return p
            p = p.parent
        return None


class DOM(HTMLParser):
    VOID = {"area", "base", "br", "col", "embed", "hr", "img", "input", "link", "meta", "param", "source", "track", "wbr"}

    def __init__(self, html):
        super().__init__(convert_charrefs=True)
        self.root = Node()
        self.stack, self.nodes = [self.root], []
        self.feed(html)
        self.close()

    def handle_starttag(self, tag, attrs):
        if tag in ("li", "td", "th", "tr", "p") and self.stack[-1].tag == tag:
            self.stack.pop()
        node = Node(tag, attrs, self.stack[-1], len(self.nodes))
        self.nodes.append(node)
        self.stack[-1].children.append(node)
        if tag not in self.VOID:
            self.stack.append(node)

    def handle_startendtag(self, tag, attrs):
        self.handle_starttag(tag, attrs)
        if tag not in self.VOID:
            self.handle_endtag(tag)

    def handle_endtag(self, tag):
        for i in range(len(self.stack) - 1, 0, -1):
            if self.stack[i].tag == tag:
                del self.stack[i:]
                break

    def handle_data(self, data):
        self.stack[-1].children.append(data)


class SourceHalted(RuntimeError):
    pass


class SafeRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        old = urllib.parse.urlsplit(req.full_url)
        new = urllib.parse.urlsplit(newurl)
        if new.scheme != "https" or old.hostname != new.hostname:
            raise SourceHalted("Unexpected cross-host redirect: " + newurl)
        return super().redirect_request(req, fp, code, msg, headers, newurl)


class Client:
    """One request at a time, durable cache, robots policy, and permanent source halt on blocking."""
    def __init__(self, delay=4.0, offline=False):
        self.delay = max(3.0, delay)
        self.offline = offline
        self.state = read(HOME / "checkpoint.json", {"created_at": now(), "sources": {}, "requests": 0})
        self.robots, self.last_request = {}, {}
        self.opener = urllib.request.build_opener(SafeRedirect())

    def persist(self):
        self.state["updated_at"] = now()
        save(HOME / "checkpoint.json", self.state)

    def halt(self, source, reason):
        self.state["sources"][source] = {"status": "halted", "reason": reason, "at": now()}
        self.persist()
        LOG.error("SOURCE_HALTED %s %s", source, reason)
        raise SourceHalted(source + ": " + reason)

    def get(self, source, url, policy=False):
        origin = SOURCES[source]
        parsed = urllib.parse.urlsplit(url)
        if parsed.scheme != "https" or parsed.netloc != urllib.parse.urlsplit(origin).netloc:
            raise ValueError("Source URL host mismatch: " + url)
        key = digest(url.encode())
        meta_path, raw_path = HOME / "cache" / (key + ".json"), HOME / "cache" / (key + ".html.gz")
        if meta_path.exists() and raw_path.exists():
            meta = read(meta_path)
            raw = gzip.decompress(raw_path.read_bytes())
            if digest(raw) != meta["sha256"]:
                raise ValueError("Cache checksum mismatch: " + url)
            return raw.decode(meta.get("charset") or "utf-8", "replace"), meta
        if self.offline:
            raise RuntimeError("Not cached: " + url)
        if self.state["sources"].get(source, {}).get("status") == "halted":
            raise SourceHalted(source + ": " + self.state["sources"][source]["reason"])
        if not policy:
            if source not in self.robots:
                text, _ = self.get(source, origin + "/robots.txt", policy=True)
                robot = urllib.robotparser.RobotFileParser()
                robot.parse(text.splitlines())
                self.robots[source] = robot
            robot = self.robots[source]
            if not robot.can_fetch(UA, url):
                self.halt(source, "robots.txt disallows " + url)
            crawl_delay = robot.crawl_delay(UA) or robot.crawl_delay("*") or 0
        else:
            crawl_delay = 0
        wait = max(self.delay, crawl_delay) - (time.monotonic() - self.last_request.get(source, 0))
        if wait > 0:
            time.sleep(wait)
        if STOP:
            raise KeyboardInterrupt
        self.last_request[source] = time.monotonic()
        self.state["requests"] += 1
        self.state["last_request_at"] = now()
        self.persist()
        try:
            request = urllib.request.Request(url, headers={"User-Agent": UA, "Accept": "text/html,text/plain,application/xml", "Accept-Language": "en"})
            with self.opener.open(request, timeout=35) as response:
                raw = response.read(12_000_001)
                if len(raw) > 12_000_000:
                    raise ValueError("Response exceeds 12 MB limit")
                charset = response.headers.get_content_charset() or "utf-8"
                meta = {"source": source, "requested_url": url, "actual_url": response.url, "status": response.status,
                        "collected_at": now(), "sha256": digest(raw), "charset": charset,
                        "content_type": response.headers.get("Content-Type"), "cache_file": str(raw_path.relative_to(HOME))}
        except urllib.error.HTTPError as exc:
            self.persist()
            if exc.code in (401, 403, 407, 429, 451, 503):
                self.halt(source, f"HTTP {exc.code} at {url}; no bypass or automatic retry")
            raise
        except SourceHalted as exc:
            self.halt(source, str(exc))
        text = raw.decode(charset, "replace")
        if re.search(r"<title[^>]*>\s*(?:just a moment|access denied|attention required|verify (?:you|your))", text, re.I):
            self.halt(source, "Access challenge at " + url)
        self.state["sources"].setdefault(source, {"status": "active"})
        self.persist()
        atomic_bytes(raw_path, gzip.compress(raw, mtime=0))
        save(meta_path, meta)
        LOG.info("FETCH %s %s bytes=%s", source, url, len(raw))
        return text, meta


def configure_logging(background=False):
    HOME.mkdir(exist_ok=True)
    LOG.setLevel(logging.INFO)
    fmt = logging.Formatter("%(asctime)s %(levelname)s %(message)s")
    fmt.converter = lambda stamp: datetime.fromtimestamp(stamp, KST).timetuple()
    handlers = [logging.FileHandler(HOME / "progress.log", encoding="utf-8")]
    if not background:
        handlers.insert(0, logging.StreamHandler())
    for handler in handlers:
        handler.setFormatter(fmt)
        LOG.addHandler(handler)


def signal_stop(signum, frame):
    global STOP
    STOP = True
    LOG.warning("STOP_REQUESTED signal=%s; preserving checkpoints", signum)


def section(doc, heading, pattern):
    start = next((n for n in doc.nodes if n.tag == heading and re.search(pattern, n.text(), re.I)), None)
    if not start:
        return []
    end = next((n.order for n in doc.nodes[start.order + 1:] if n.tag == heading), len(doc.nodes))
    return [n for n in doc.nodes if start.order < n.order < end]


def classes(nodes, value):
    return [n for n in nodes if n.has_class(value)]


def direct_parts(node):
    """Visible block lines, preserving explicit br separators without reading scripts/comments."""
    result = []
    def visit(n):
        if isinstance(n, str):
            result.append(n)
            return
        if n.tag in ("script", "style", "noscript"):
            return
        if n.tag in ("br", "p", "li", "div", "h2", "h3", "h4", "tr"):
            result.append("\n")
        for c in n.children:
            visit(c)
        if n.tag in ("p", "li", "div", "h2", "h3", "h4", "tr"):
            result.append("\n")
    visit(node)
    return [" ".join(line.split()) for line in "".join(result).splitlines() if line.strip()]


def unique(values):
    return list(dict.fromkeys(v for v in values if v))


def number(text):
    match = re.fullmatch(r"\s*([\d,]+(?:\.\d+)?)\s*%?\s*", text)
    return float(match[1].replace(",", "")) if match and "." in match[1] else int(match[1].replace(",", "")) if match else None


def parse_stats(nodes):
    # Only a source-labelled stat block; never search the entire page for arbitrary numbers.
    labels = {"hp": "HP", "health": "HP", "atk": "ATK", "attack": "ATK", "def": "DEF", "defense": "DEF",
              "spd": "SPD", "speed": "SPD", "c.rate": "C.RATE", "crit rate": "C.RATE", "c.dmg": "C.DMG",
              "crit damage": "C.DMG", "res": "RES", "resistance": "RES", "acc": "ACC", "accuracy": "ACC"}
    candidates = []
    for node in nodes:
        if node.attrs.get("id") not in ("stats", "base-stats") and not node.has_class("base-stats"):
            continue
        lines = direct_parts(node)
        stats = {}
        for i, line in enumerate(lines):
            match = re.fullmatch(r"([A-Za-z. ]+)\s*:\s*([\d,.]+%?)", line)
            label = norm(match[1]) if match else norm(line)
            value = number(match[2]) if match else number(lines[i + 1]) if i + 1 < len(lines) else None
            if label in labels and value is not None:
                stats[labels[label]] = value
        if stats:
            candidates.append(stats)
    if len({json.dumps(v, sort_keys=True) for v in candidates}) == 1:
        return {"values": candidates[0], "context": "source-labelled block; rank/level not independently confirmed"}
    return {}


def parse_ayumilove(doc):
    content = next((n for n in doc.nodes if n.has_class("entry-content")), None)
    if not content:
        raise ValueError("Ayumilove article container not found")
    nodes = content.all()
    data = {"basic": {}, "skills": [], "aura": [], "gear": {}, "masteries": [], "ratings": {}, "base_stats": parse_stats(nodes)}
    for td in content.all("td"):
        headings = td.all("h4")
        if not headings:
            continue
        title = norm(headings[0].text())
        lines = direct_parts(td)
        if title == "overview":
            for line in lines:
                match = re.fullmatch(r"(NAME|FACTION|RARITY|ROLE|AFFINITY|RANK|USABILITY|TOMES):\s*(.+)", line)
                if match:
                    data["basic"][match[1].lower()] = match[2].strip()
        if title in ("grinding", "dungeons", "potion", "doom tower"):
            for i, heading in enumerate(headings):
                end = headings[i + 1].order if i + 1 < len(headings) else float("inf")
                items = [n.text() for n in td.all() if heading.order < n.order < end and n.tag == "li"]
                if not items:
                    between = [n for n in td.all() if heading.order < n.order < end and n.tag == "p"]
                    items = [line for n in between for line in direct_parts(n)]
                if items:
                    data["ratings"][heading.text()] = items
    skill_nodes = section(doc, "h2", r"\bSkills(?:\s|$)")
    for p in skill_nodes:
        if p.tag != "p":
            continue
        strong = p.all("strong")
        if not strong:
            continue
        source_label = strong[0].text().strip()
        if not source_label or re.match(r"^(?:Level|Damage|Multiplier|Note)\b", source_label, re.I):
            continue
        text = p.text()
        if not text.startswith(source_label):
            continue
        name = re.sub(r"\s*\(Cooldown:\s*\d+\s*turns?\)\s*$", "", source_label, flags=re.I).strip()
        name = re.sub(r"\s*\((?:Passive|Active)\)\s*$", "", name, flags=re.I).strip()
        remaining = text[len(source_label):].strip()
        label_cooldown = re.search(r"\(Cooldown:\s*(\d+)\s*turns?\)", source_label, re.I)
        cooldown = re.match(r"^\(Cooldown:\s*(\d+)\s*turns?\)", remaining, re.I)
        if cooldown:
            remaining = remaining[cooldown.end():].strip()
        cut = re.search(r"\bLevel\s*\d+\s*:|\bDamage (?:Multiplier|based on)\s*:", remaining, re.I)
        description = remaining[:cut.start()].strip() if cut else remaining
        books = [line for line in direct_parts(p) if re.match(r"Level\s*\d+\s*:", line, re.I)]
        item = {"name": name, "source_label": source_label, "description": description,
                "cooldown": int((cooldown or label_cooldown)[1]) if cooldown or label_cooldown else None, "books": books}
        if norm(name) == "aura":
            data["aura"].append(description)
        elif description:
            data["skills"].append(item)
    gear_nodes = section(doc, "h2", r"\b(?:Build|Equipment) Guide\b")
    for table in (n for n in gear_nodes if n.tag == "td"):
        heading = table.all("h4")
        if heading and norm(heading[0].text()) in ("recommended artifacts", "stats allocation", "stats priority"):
            data["gear"][heading[0].text()] = direct_parts(table)[1:]
    mastery_nodes = section(doc, "h2", r"\bMaster(?:y|ies)(?: Guide)?$")
    for table in (n for n in mastery_nodes if n.tag == "table"):
        trees = {}
        for td in table.all("td"):
            headings = td.all("h4")
            if not headings:
                continue
            tree = norm(headings[0].text())
            if tree in ("offense", "defense", "support"):
                trees[tree] = [n.text() for n in td.all("li")]
        if not trees:
            continue
        previous = [n for n in mastery_nodes if n.order < table.order]
        titles = [n.text() for n in previous if n.tag == "h4" and norm(n.text()) not in ("offense", "defense", "support")]
        images = [n.attrs.get("src") for n in previous if n.tag == "img" and "/mastery/" in n.attrs.get("src", "")]
        data["masteries"].append({"title": titles[-1] if titles else "General", "trees": trees,
                                  "image_url": images[-1] if images else None, "source_tree_labels_preserved": True})
    return data


def parse_hellhades(doc, index_rows):
    row = index_rows[0]
    data = {"basic": {"name": unescape(row["champion"]), "rarity": row.get("rarity"), "affinity": row.get("affinity_index"),
                       "faction": row.get("faction_index"), "role": row.get("role")},
            "skills": [], "aura": [], "gear": {}, "masteries": [], "ratings": [], "base_stats": parse_stats(doc.nodes)}
    for form_row in index_rows:
        data["ratings"].append({"form_label": form_row.get("shortname"), "values": {k: v for k, v in form_row.items()
                                if k not in ("id", "url", "shortname", "champion", "affinity", "faction", "heroId")}})
    for skill in classes(doc.nodes, "raid-skill"):
        titles, descriptions, cooldowns = skill.all("h4"), classes(skill.all(), "raid-skill-description"), classes(skill.all(), "raid-skill-cooldown")
        if not titles or not descriptions:
            continue
        match = re.search(r"(\d+)\s*Turns?", cooldowns[0].text(), re.I) if cooldowns else None
        data["skills"].append({"name": titles[0].text(), "description": descriptions[0].text(),
                               "cooldown": int(match[1]) if match else None,
                               "books": [n.text() for n in classes(skill.all(), "raid-skill-book-row")]})
    for n in classes(doc.nodes, "raid-aura-container"):
        if n.text():
            data["aura"].append(n.text())
    tabs = {n.attrs.get("data-tab"): n.text() for n in classes(doc.nodes, "msb-accordion")}
    for board in classes(doc.nodes, "msb-container"):
        trees = {}
        icon_records = []
        for tree in ("offense", "defense", "support"):
            panels = classes(board.all(), "msb-" + tree)
            trees[tree] = []
            for panel in panels:
                for icon in classes(panel.all(), "msb-mastery-image"):
                    imgs = icon.all("img")
                    if not imgs:
                        continue
                    img = imgs[0]
                    title = img.attrs.get("title", "")
                    name = title.split(" - ", 1)[0].strip()
                    selected = not icon.has_class("rslm-disabled")
                    icon_records.append({"tree": tree, "name": name, "selected": selected, "source_title": title,
                                         "icon_url": img.attrs.get("data-orig-src") or img.attrs.get("src")})
                    if selected and name:
                        trees[tree].append(name)
        if any(trees.values()):
            data["masteries"].append({"id": board.attrs.get("id"), "title": tabs.get(board.attrs.get("id")),
                                      "trees": trees, "icons": icon_records, "selection_evidence": "published disabled CSS class"})
    for heading in doc.nodes:
        if heading.tag not in ("h3", "h4") or not re.fullmatch(r"Recommended PV[EP] (?:Stats|Artifact Sets)", heading.text(), re.I):
            continue
        end = next((n.order for n in doc.nodes[heading.order + 1:] if n.tag in ("h2", "h3", "h4")), len(doc.nodes))
        blocks = [n.text() for n in doc.nodes[heading.order + 1:end] if n.has_class("fusion-text") and n.text() and n.text() != heading.text()]
        if blocks:
            data["gear"][heading.text()] = " ".join(unique(blocks))
    return data


FACTIONS = {"bannerlords": "banner lords", "sacred-order": "sacred order", "the-sacred-order": "sacred order",
            "knight-revenant": "knights revenant", "knights-revenant": "knights revenant"}
ROLES = {"supp": "support", "atk": "attack", "def": "defense"}


def canonical_basic(key, value):
    value = norm(value)
    if key == "faction":
        return FACTIONS.get(value, value.replace("-", " "))
    if key == "role":
        return ROLES.get(value, value)
    return value


def quality(data, source):
    errors, warnings = [], []
    for key in ("name", "faction", "rarity", "affinity", "role"):
        if not isinstance(data.get("basic", {}).get(key), str) or not data["basic"][key].strip():
            errors.append("missing_or_invalid_basic." + key)
    if not isinstance(data.get("skills"), list) or not data["skills"]:
        errors.append("missing_skills")
    seen = set()
    for skill in data.get("skills", []):
        if not isinstance(skill.get("name"), str) or not skill["name"] or not isinstance(skill.get("description"), str) or not skill["description"]:
            errors.append("invalid_skill")
        if skill.get("cooldown") is not None and not isinstance(skill["cooldown"], int):
            errors.append("invalid_skill_cooldown")
        if norm(skill.get("name")) in seen:
            warnings.append("duplicate_skill_name:" + skill["name"])
        seen.add(norm(skill.get("name")))
    for field in ("gear", "masteries", "ratings", "base_stats"):
        if not data.get(field):
            warnings.append("not_available_or_not_structurally_extractable." + field)
    return {"status": "failed" if errors else "parsed_needs_crosscheck", "errors": unique(errors), "warnings": unique(warnings)}


INDEX_URL = "https://hellhades.com/wp-json/hh-api/v3/champions?mode=full"
SAMPLE_NAMES = ("Kael", "Abbess", "Arbiter", "Androc the Glorious", "Shieldguard", "Bully", "Big Un")


def protected_snapshot():
    paths = list(PROJECT.glob("*.py")) + list(PROJECT.glob("*names_ko.json"))
    for folder in ("data", "images", "images_collected", "assets", "mastery_layout_work", "mastery_mapping_step", "mastery_icon_prototype"):
        paths.extend(p for p in (PROJECT / folder).rglob("*") if p.is_file() and "__pycache__" not in p.parts)
    return {str(p.relative_to(PROJECT)): digest(p.read_bytes()) for p in sorted(set(paths))}


def check_protected(manifest):
    problems = []
    for name, expected in manifest["protected_files"].items():
        path = PROJECT / name
        if not path.is_file() or digest(path.read_bytes()) != expected:
            problems.append(name)
    return {"checked_at": now(), "files": len(manifest["protected_files"]), "unchanged": not problems, "changed_or_missing": problems}


def ayumi_slug(url):
    # A shared published slug is a candidate only, never evidence of champion identity.
    path = urllib.parse.urlsplit(url).path.strip("/")
    return path.removeprefix("raid-shadow-legends-").removesuffix("-skill-mastery-equip-guide")


def prepare(client):
    path = HOME / "manifest.json"
    if path.exists():
        return read(path)
    protected = protected_snapshot()
    champions = read(PROJECT / "data/champions_collected.json")["champions"]
    originals = read(PROJECT / "data/champions.json")["champions"]
    validations = read(PROJECT / "data/champion_url_validation_all.json")["results"]
    korean = read(PROJECT / "data/bulk_stage11/champion_names_ko_verified.json", {})
    existing_raw = read(PROJECT / "collected_champions/progress.json", {}).get("records", {})
    for source, origin in SOURCES.items():
        client.get(source, origin + "/robots.txt", policy=True)
    index_text, index_meta = client.get("hellhades", INDEX_URL)
    rows = json.loads(index_text)["champions"]
    by_name, by_slug = defaultdict(list), defaultdict(list)
    for row in rows:
        by_name[norm(row["champion"])].append(row)
        by_slug[urllib.parse.urlsplit(row["url"]).path.strip("/").rsplit("/", 1)[-1]].append(row)
    targets, names_seen, urls_seen, ids_seen = [], set(), set(), set()
    for index, champ in enumerate(champions):
        name, url = champ["name_en"], champ.get("source", {}).get("guide")
        if not name or not url or norm(name) in names_seen or url in urls_seen:
            raise ValueError("Duplicate/missing local champion identity: " + str(name))
        if urllib.parse.urlsplit(url).netloc != "ayumilove.net":
            raise ValueError("Unexpected existing source URL: " + url)
        names_seen.add(norm(name)); urls_seen.add(url)
        validation = validations.get(url, {})
        aliases = [name]
        if validation.get("http_status") == 200 and validation.get("ayumi_url") == url:
            for key in ("page_h1", "page_title"):
                header = (validation.get(key) or "").split("|")[0].strip()
                if header:
                    aliases.append(header)
        found = by_name.get(norm(name), [])
        if not found:
            found = [r for alias in aliases[1:] for r in by_name.get(norm(alias), [])]
        method = "exact_published_name"
        if not found:
            found = by_slug.get(ayumi_slug(url), [])
            method = "published_slug_candidate_requires_skill_crosscheck"
        urls = {r["url"] for r in found}
        post_ids = {str(r["id"]) for r in found}
        if len(urls) != 1 or len(post_ids) != 1:
            found, method = [], "unresolved_or_conflicting_published_URL"
        identifier = "champ_" + digest(url.encode())[:20]
        if identifier in ids_seen:
            raise ValueError("Champion ID collision")
        ids_seen.add(identifier)
        prior = existing_raw.get(url)
        target = {"id": identifier, "local_index": index, "name_en": name, "known_published_names": unique(aliases),
                  "ayumilove_url": url, "hellhades_url": found[0]["url"] if found else None,
                  "hellhades_identity_method": method, "hellhades_index_rows": found,
                  "existing_record": {"path": "collected_champions/progress.json", "key": url,
                                      "sha256": digest(json.dumps(prior, sort_keys=True, ensure_ascii=False).encode()) if prior else None,
                                      "status": prior.get("status") if prior else None},
                  "existing_korean": {"name": korean.get(name) or champ.get("name_ko") or next((c.get("name_ko") for c in originals if norm(c.get("name_en")) == norm(name)), None),
                                      "verification": "existing_project_label; game Korean original evidence not established here"}}
        targets.append(target)
    if len(targets) != 1049:
        raise ValueError("Expected exactly the existing 1049 champions, got " + str(len(targets)))
    manifest = {"schema_version": 1, "created_at": now(), "target_count": len(targets), "targets": targets,
                "identity_rule": "exact source names; same published URL/post ID groups transformed forms; shared slugs remain candidates until exact skills and basic fields agree",
                "index_provenance": index_meta, "index_discovery": "public tier-list.js v3/champions + js-fe.js /wp-json/hh-api/; unauthenticated GET only",
                "request_policy": {"minimum_start_interval_seconds": client.delay, "concurrency": 1, "stop_source_on_block": True},
                "protected_files": protected, "integration": "forbidden; separate output only"}
    save(path, manifest)
    LOG.info("PREPARED targets=%s mapping=%s", len(targets), dict(Counter(t["hellhades_identity_method"] for t in targets)))
    return manifest


def result_path(target):
    return HOME / "records" / (target["id"] + ".json")


def empty_record(target):
    return {"schema_version": 1, "champion_id": target["id"], "name_en": target["name_en"], "name_ko": None,
            "existing_korean": target["existing_korean"], "sources": {}, "cross_validation": None}


def mastery_check(data):
    mapping = read(PROJECT / "mastery_layout_work/mastery_verified_positions.json")["masteries"]
    names = defaultdict(set)
    for pos, record in mapping.items():
        if record.get("status") != "REFERENCE_VERIFIED":
            continue
        for name in (record["name_en"], record["name_ko"], *[a for a in record["aliases"] if a in record.get("alias_evidence", {})]):
            names[norm(name)].add(pos)
    result = Counter()
    details = []
    for i, build in enumerate(data.get("masteries", [])):
        seen = set()
        for tree, values in build.get("trees", {}).items():
            for value in values:
                slots = names.get(norm(value), set())
                kind = "unmatched" if not slots else "mapping_conflict" if len(slots) != 1 else "tree_conflict" if not next(iter(slots)).startswith(tree + "_") else "duplicate" if next(iter(slots)) in seen else "matched"
                result[kind] += 1
                if kind == "matched":
                    seen.update(slots)
                else:
                    details.append({"build_index": i, "tree": tree, "name": value, "status": kind})
    return {"scope": "name/icon identity only; recommendation content and current game build not verified",
            "counts": dict(result), "issues": details}


def supplement_forms(client, target, data):
    """Use the exact public frontend requests, preserving coefficients as raw model data only."""
    hero_ids = {int(r.get("heroId") or 0) for r in target["hellhades_index_rows"]}
    if len(hero_ids) != 1 or next(iter(hero_ids)) <= 0:
        raise ValueError("No unambiguous published hero ID for alternate forms")
    hero = next(iter(hero_ids))
    # raid-champions.js explicitly computes f = A - A % 10 before requesting forms.
    model = hero - hero % 10
    url = SOURCES["hellhades"] + "/wp-json/hh-api/v3/raid/forms/" + str(model)
    text, forms_meta = client.get("hellhades", url)
    rows = json.loads(text)
    if not isinstance(rows, list):
        raise ValueError("Unexpected forms response type")
    selected = [r for r in rows if isinstance(r, dict) and str(r.get("heroid")) == str(hero)]
    if len({r.get("form") for r in selected}) < 2:
        raise ValueError("Published alternate forms not available for the exact hero ID")
    groups = []
    for form in selected:
        query = urllib.parse.urlencode({"skills": form["skills"], "model": form["model"], "heroid": form["heroid"]})
        text, meta = client.get("hellhades", SOURCES["hellhades"] + "/wp-json/hh-api/v3/skills?" + query)
        skills = json.loads(text)
        if not isinstance(skills, list) or not skills:
            raise ValueError("Published form skill response missing or invalid")
        parsed = []
        for s in skills:
            if not isinstance(s, dict) or not isinstance(s.get("name"), str) or not isinstance(s.get("description"), str):
                raise ValueError("Invalid alternate-form skill schema")
            name = s["name"]
            if s.get("type") == "Passive":
                name = re.sub(r"\s*\[P\]\s*$", "", name)
            cooldown = int(s["cooldown"]) if str(s.get("cooldown", "")).isdigit() else None
            parsed.append({"name": name, "source_label": s["name"], "source_skill_id": s.get("id"), "form": form["form"],
                           "type": s.get("type"), "description": DOM(s["description"]).root.text(),
                           "cooldown": cooldown, "books": s.get("books"), "multiplier": s.get("multiplier")})
        groups.append({"form": form["form"], "source_model_record": form, "skills": parsed, "provenance": meta})
    data["static_skills"] = data["skills"]
    data["skills_by_form"] = groups
    data["skills"] = [skill for group in groups for skill in group["skills"]]
    data["form_provenance"] = forms_meta
    data["skill_scope"] = "all public form skill records for exact source hero ID; duplicate names kept per form"
    data["raw_model_stat_note"] = "Forms API health/attack/defense are model coefficients; not treated as max-level base stats or converted by guessed formulas"


def collect_one(client, target, source):
    url = target[source + "_url"]
    base = {"source": source, "requested_url": url, "attempted_at": now(), "parser_version": VERSION,
            "collection_status": "failed", "identity_status": "unconfirmed", "verification_status": "unconfirmed"}
    if not url:
        return {**base, "error": "No unique published source URL; not generated or guessed"}
    html, meta = client.get(source, url)
    base["provenance"] = meta
    doc = DOM(html)
    h1 = doc.root.all("h1")
    if len(h1) != 1:
        return {**base, "error": "Missing or ambiguous page heading"}
    heading = h1[0].text().split("|")[0].strip()
    allowed = target["known_published_names"] if source == "ayumilove" else [r["champion"] for r in target["hellhades_index_rows"]]
    if norm(heading) not in {norm(v) for v in allowed}:
        return {**base, "observed_heading": heading, "error": "Page heading differs from published identity; no fuzzy matching"}
    actual = urllib.parse.urlsplit(meta["actual_url"])
    expected = urllib.parse.urlsplit(url)
    canonical = [n.attrs.get("href") for n in doc.root.all("link") if "canonical" in n.attrs.get("rel", "").split()]
    if actual.netloc != expected.netloc or actual.path.rstrip("/") != expected.path.rstrip("/") or (canonical and any(urllib.parse.urlsplit(u).path.rstrip("/") != actual.path.rstrip("/") for u in canonical)):
        return {**base, "error": "Actual/canonical URL differs from expected published page", "observed_canonical": canonical}
    data = parse_ayumilove(doc) if source == "ayumilove" else parse_hellhades(doc, target["hellhades_index_rows"])
    if source == "hellhades":
        data["published_forms"] = [{"label": r.get("shortname"), "hero_id": r.get("heroId")} for r in target["hellhades_index_rows"]]
        data["skill_scope"] = "server-rendered published skills; alternate dynamic forms are not inferred"
        data["ratings_provenance"] = {"url": INDEX_URL, "collected_at": read(HOME / "manifest.json")["index_provenance"]["collected_at"]}
        if len(target["hellhades_index_rows"]) > 1:
            supplement_forms(client, target, data)
    audit = quality(data, source)
    if source == "ayumilove" and norm(data["basic"].get("name")) not in {norm(v) for v in allowed}:
        audit["errors"].append("Article NAME differs from page identity")
    data["mastery_mapping_check"] = mastery_check(data)
    if audit["errors"]:
        audit["status"] = "failed"
    base.update({"observed_heading": heading, "data": data, "quality": audit,
                 "collection_status": "success" if not audit["errors"] else "parse_failed",
                 "identity_status": "candidate" if source == "hellhades" and "candidate" in target["hellhades_identity_method"] else "exact_published_name",
                 "verification_status": "pending_crosscheck" if not audit["errors"] else "unconfirmed"})
    return base


def comparison(left, right, normalize=lambda value: value):
    left_missing, right_missing = left is None or left == "" or left == [], right is None or right == "" or right == []
    if left_missing and right_missing:
        status = "both_missing"
    elif left_missing or right_missing:
        status = "one_source_only"
    else:
        status = "match" if normalize(left) == normalize(right) else "different"
    return {"status": status, "hellhades": left, "ayumilove": right}


def crosscheck(record, target):
    sources = record["sources"]
    hh, ay = sources.get("hellhades", {}), sources.get("ayumilove", {})
    both = all(s.get("collection_status") == "success" for s in (hh, ay))
    identity_evidence = None
    if both and hh.get("identity_status") == "candidate":
        hdata, adata = hh["data"], ay["data"]
        shared = {norm(s["name"]) for s in hdata["skills"]} & {norm(s["name"]) for s in adata["skills"]}
        fields_match = all(canonical_basic(key, hdata["basic"].get(key)) == canonical_basic(key, adata["basic"].get(key))
                           for key in ("faction", "rarity", "affinity", "role"))
        if len(shared) >= 2 and fields_match:
            hh["identity_status"] = "cross_source_exact_skill_identity"
            identity_evidence = {"method": "same published slug plus four exact normalized basic fields and at least two identical full skill names",
                                 "shared_skill_names": sorted(shared), "basic_fields": ["faction", "rarity", "affinity", "role"],
                                 "urls": [hh["requested_url"], ay["requested_url"]], "name_similarity_used": False}
            hh["identity_evidence"] = identity_evidence
    identities_valid = both and all(s.get("identity_status") in ("exact_published_name", "cross_source_exact_skill_identity") for s in (hh, ay))
    values, consensus = {}, {}
    for key in ("name", "faction", "rarity", "affinity", "role"):
        l = hh.get("data", {}).get("basic", {}).get(key) if hh.get("collection_status") == "success" else None
        r = ay.get("data", {}).get("basic", {}).get(key) if ay.get("collection_status") == "success" else None
        entry = comparison(l, r, lambda value: canonical_basic(key, value))
        if both and not identities_valid:
            entry.update(status="unconfirmed", reason="Cross-site champion identity not established")
        values["basic." + key] = entry
    for key in ("HP", "ATK", "DEF", "SPD", "C.RATE", "C.DMG", "RES", "ACC"):
        l = hh.get("data", {}).get("base_stats", {}).get("values", {}).get(key)
        r = ay.get("data", {}).get("base_stats", {}).get("values", {}).get(key)
        entry = comparison(l, r)
        if l is not None and r is not None:
            entry.update(status="unconfirmed", reason="Level, rank and ascension contexts not independently aligned")
        values["base_stats." + key] = entry
    lskills = hh.get("data", {}).get("skills", []) if hh.get("collection_status") == "success" else []
    rskills = ay.get("data", {}).get("skills", []) if ay.get("collection_status") == "success" else []
    values["skills.names"] = comparison([s["name"] for s in lskills], [s["name"] for s in rskills], lambda value: sorted(norm(n) for n in value))
    lmap, rmap = defaultdict(list), defaultdict(list)
    for skill in lskills:
        lmap[norm(skill["name"])].append(skill)
    for skill in rskills:
        rmap[norm(skill["name"])].append(skill)
    for name in sorted(set(lmap) | set(rmap)):
        for key in ("description", "cooldown"):
            left = lmap[name][0].get(key) if len(lmap[name]) == 1 else None
            right = rmap[name][0].get(key) if len(rmap[name]) == 1 else None
            entry = comparison(left, right, norm if key == "description" else lambda value: value)
            if len(lmap[name]) > 1 or len(rmap[name]) > 1:
                entry.update(status="unconfirmed", reason="Duplicate skill name requires form-specific comparison")
            values["skills." + name + "." + key] = entry
    if not identities_valid:
        for entry in values.values():
            entry.update(status="unconfirmed", reason="One or both sources not successfully collected" if not both else "Cross-site champion identity not established")
    for path, entry in values.items():
        if entry["status"] == "match" and identities_valid:
            consensus[path] = {"value": entry["hellhades"], "scope": "two published sources agree; not game-client verification"}
    counts = Counter(entry["status"] for entry in values.values())
    completed = identities_valid
    status = "not_comparable" if not completed else "with_differences" if counts["different"] else "agreement_on_comparable_fields"
    record["cross_validation"] = {"checked_at": now(), "completed": completed, "status": status, "field_counts": dict(counts),
                                   "fields": values, "consensus": consensus, "game_verified": False,
                                   "recommendation_policy": "gear, stats priorities, mastery builds and ratings are source-specific strategies; differences are not data errors",
                                   "recommendations_preserved_separately": True}
    for source_record in (hh, ay):
        if source_record.get("collection_status") == "success":
            source_record["verification_status"] = "crosschecked_with_differences" if completed and counts["different"] else "crosschecked_available_fields" if completed else "unconfirmed"
    record["updated_at"] = now()
    return record


def load_records(manifest):
    records = {}
    for t in manifest["targets"]:
        path = result_path(t)
        if not path.exists():
            continue
        try:
            record = read(path)
            if record["champion_id"] != t["id"] or record["name_en"] != t["name_en"] or not isinstance(record["sources"], dict):
                raise ValueError("record identity/schema mismatch")
            records[t["id"]] = record
        except (ValueError, KeyError, TypeError) as exc:
            raise RuntimeError("Damaged saved record; preserved for inspection: " + str(path)) from exc
    return records


def summarize(manifest, records, client, status=None):
    counts = {source: Counter() for source in SOURCES}
    fields, champions = Counter(), Counter()
    for target in manifest["targets"]:
        record = records.get(target["id"], {})
        for source in SOURCES:
            item = record.get("sources", {}).get(source, {})
            state = item.get("collection_status", "pending")
            counts[source][state] += 1
            if item.get("identity_status") == "candidate":
                counts[source]["identity_unconfirmed"] += 1
        review = record.get("cross_validation") or {}
        if review.get("completed"):
            champions["cross_validation_completed"] += 1
            champions[review["status"]] += 1
        else:
            champions["not_comparable_or_pending"] += 1
        fields.update(review.get("field_counts", {}))
    summary = {"updated_at": now(), "target_count": len(manifest["targets"]), "run_status": status or client.state.get("run_status"),
               "process": client.state.get("process"), "sources": {key: dict(value) for key, value in counts.items()},
               "source_halts": {key: value for key, value in client.state["sources"].items() if value.get("status") == "halted"},
               "champions": dict(champions), "field_status_counts": dict(fields), "http_requests": client.state["requests"],
               "collection_success_is_not_verification_success": True, "game_build_verified": False,
               "operating_database_integration": "not performed", "protection_check": client.state.get("protection_check")}
    summary["collection_complete"] = all(counts[s]["pending"] == 0 for s in SOURCES)
    summary["cross_validation_complete"] = champions["cross_validation_completed"] == len(manifest["targets"])
    for source in SOURCES:
        summary["sources"][source]["failed_total"] = counts[source]["failed"] + counts[source]["parse_failed"]
    save(HOME / "summary.json", summary)
    return summary


class RunLock:
    def __enter__(self):
        import msvcrt
        self.stream = local(HOME / "run.lock").open("a+b")
        if (HOME / "run.lock").stat().st_size == 0:
            self.stream.write(b"0"); self.stream.flush()
        self.stream.seek(0)
        try:
            msvcrt.locking(self.stream.fileno(), msvcrt.LK_NBLCK, 1)
        except OSError:
            self.stream.close()
            raise RuntimeError("Another collector holds the run lock; a duplicate process was not started")
        return self

    def __exit__(self, *args):
        import msvcrt
        self.stream.seek(0)
        msvcrt.locking(self.stream.fileno(), msvcrt.LK_UNLCK, 1)
        self.stream.close()


def sample_gate(manifest, records):
    details = []
    by_name = {t["name_en"]: t for t in manifest["targets"]}
    for name in SAMPLE_NAMES:
        if name not in by_name:
            details.append({"champion": name, "passed": False, "reason": "Sample champion missing"})
            continue
        target = by_name[name]
        record = records.get(target["id"], {})
        for source in SOURCES:
            item = record.get("sources", {}).get(source, {})
            passed = (item.get("collection_status") == "success" and item.get("parser_version") == VERSION
                      and not item.get("quality", {}).get("errors")
                      and item.get("identity_status") in ("exact_published_name", "cross_source_exact_skill_identity")
                      and result_path(target).is_file())
            details.append({"champion": name, "source": source, "passed": passed,
                            "skills": len(item.get("data", {}).get("skills", [])),
                            "gear_available": bool(item.get("data", {}).get("gear")),
                            "masteries_available": bool(item.get("data", {}).get("masteries")),
                            "missing_fields": item.get("quality", {}).get("warnings", []),
                            "error": item.get("error") or item.get("quality", {}).get("errors")})
    return {"checked_at": now(), "passed": bool(details) and all(d["passed"] for d in details), "checks": details,
            "requirements": "Correct published identity and URL, four basic fields, skill name/effect, durable JSON; absent optional fields explicitly recorded"}


def execute(client, manifest, mode, max_items=None, retry_failed=False):
    records = load_records(manifest)
    if mode == "run":
        gate = sample_gate(manifest, records)
        if not gate["passed"]:
            raise RuntimeError("Full collection refused: live sample gate has not passed")
    protection = check_protected(manifest)
    if not protection["unchanged"]:
        raise RuntimeError("Existing protected files changed externally: " + ", ".join(protection["changed_or_missing"][:5]))
    client.state.update(run_status="sample_running" if mode == "sample" else "running", process={"pid": os.getpid(), "started_at": now(), "mode": mode}, protection_check=protection)
    client.state.pop("finished_at", None)
    client.persist()
    summarize(manifest, records, client)
    selected = [t for t in manifest["targets"] if mode != "sample" or t["name_en"] in SAMPLE_NAMES]
    if mode == "sample":
        selected.sort(key=lambda t: SAMPLE_NAMES.index(t["name_en"]))
    processed, skipped, limited, fatal = 0, 0, False, None
    try:
        # Source order is deliberate. Each completed source is immediately durable per champion.
        for source in SOURCES:
            if client.state["sources"].get(source, {}).get("status") == "halted":
                LOG.warning("SKIP_HALTED_SOURCE %s", source)
                continue
            consecutive_parse_errors = 0
            for target in selected:
                if STOP or (max_items is not None and processed >= max_items):
                    limited = True
                    break
                record = records.get(target["id"], empty_record(target))
                previous = record["sources"].get(source)
                if previous and previous.get("parser_version") == VERSION and (previous.get("collection_status") == "success" or not retry_failed):
                    skipped += 1
                    LOG.info("RESUME_SKIP %s %s status=%s", source, target["name_en"], previous.get("collection_status"))
                    continue
                LOG.info("COLLECT %s %s id=%s", source, target["name_en"], target["id"])
                halted = False
                try:
                    result = collect_one(client, target, source)
                except KeyboardInterrupt:
                    raise
                except Exception as exc:
                    halted = isinstance(exc, SourceHalted)
                    result = {"source": source, "requested_url": target[source + "_url"], "attempted_at": now(),
                              "collection_status": "failed", "identity_status": "unconfirmed", "verification_status": "unconfirmed",
                              "parser_version": VERSION, "error_type": type(exc).__name__, "error": str(exc),
                              "retryable": not halted and not isinstance(exc, urllib.error.HTTPError)}
                    LOG.error("FAILED %s %s %s", source, target["name_en"], str(exc))
                result["attempts"] = (previous or {}).get("attempts", 0) + 1
                record["sources"][source] = result
                crosscheck(record, target)
                save(result_path(target), record)
                # Reopen the actual saved JSON before committing its completion checkpoint.
                saved = read(result_path(target))
                if saved != record:
                    raise RuntimeError("JSON persistence verification failed")
                records[target["id"]] = saved
                processed += 1
                client.state["last_completed"] = {"champion_id": target["id"], "name_en": target["name_en"], "source": source,
                                                   "status": result["collection_status"], "at": now()}
                client.persist()
                LOG.info("SAVED %s %s status=%s skills=%s builds=%s", source, target["name_en"], result["collection_status"],
                         len(result.get("data", {}).get("skills", [])), len(result.get("data", {}).get("masteries", [])))
                if mode == "sample" or processed % 5 == 0:
                    summarize(manifest, records, client)
                consecutive_parse_errors = consecutive_parse_errors + 1 if result["collection_status"] == "parse_failed" else 0
                if consecutive_parse_errors >= 3:
                    try:
                        client.halt(source, "Three consecutive schema/parse failures; source paused to avoid collecting bad data")
                    except SourceHalted:
                        halted = True
                if halted:
                    break
            if limited:
                break
    except KeyboardInterrupt:
        limited = True
        LOG.warning("INTERRUPTED progress preserved")
    except Exception as exc:
        fatal = {"type": type(exc).__name__, "reason": str(exc), "at": now()}
        client.state["fatal_error"] = fatal
        raise
    finally:
        client.state["sample_validation"] = sample_gate(manifest, records)
        pending = sum(not records.get(t["id"], {}).get("sources", {}).get(s) for t in selected for s in SOURCES)
        status = "error_resumable" if fatal else "stopped_resumable" if limited else "blocked_resumable" if pending else "sample_passed" if mode == "sample" and client.state["sample_validation"]["passed"] else "sample_failed" if mode == "sample" else "completed_with_errors" if any(records[t["id"]]["sources"][s]["collection_status"] != "success" for t in selected for s in SOURCES) else "completed"
        client.state.update(run_status=status, finished_at=now(), resumed_items_skipped=skipped)
        client.state["process"]["exited_at"] = now()
        client.state["protection_check"] = check_protected(manifest)
        client.persist()
        summary = summarize(manifest, records, client, status)
        LOG.info("FINISH status=%s processed=%s resumed_skipped=%s pending=%s", status, processed, skipped, pending)
    return summary


def self_test():
    import tempfile
    from unittest.mock import patch
    # Simulate a crash between record commit and checkpoint commit: the durable record wins.
    with tempfile.TemporaryDirectory(prefix="selftest_", dir=HOME) as temp:
        path = local(Path(temp) / "record.json")
        save(path, {"sources": {"hellhades": {"collection_status": "success"}}})
        before = path.read_bytes()
        checkpoint = {"completed": []}
        assert read(path)["sources"]["hellhades"]["collection_status"] == "success" and not checkpoint["completed"]
        assert path.read_bytes() == before
        try:
            save(PROJECT / "main.py", {})
            raise AssertionError("write isolation failed")
        except ValueError:
            pass
    assert comparison(None, None)["status"] == "both_missing"
    assert comparison(0, None)["status"] == "one_source_only"
    assert comparison("a", "b")["status"] == "different"
    assert comparison("A", "a", norm)["status"] == "match"
    # Two different champions with only a similar name must never gain a cross-source identity.
    target = {"id": "test", "name_en": "Test"}
    record = {"sources": {s: {"collection_status": "success", "identity_status": "candidate" if s == "hellhades" else "exact_published_name",
                              "requested_url": s, "data": {"basic": {"faction": "A", "rarity": "Rare", "affinity": "Void", "role": "Attack"},
                              "skills": [{"name": "Skill " + s, "description": "effect"}]}} for s in SOURCES}}
    assert not crosscheck(record, target)["cross_validation"]["completed"]
    pending = {"sources": {"hellhades": record["sources"]["hellhades"]}}
    review = crosscheck(pending, target)["cross_validation"]
    assert set(review["field_counts"]) == {"unconfirmed"}, review
    # No actual HTTP request: a 403 must halt the source before any second attempt.
    fake = Client(offline=False)
    fake.state = {"requests": 0, "sources": {}}
    fake.persist = lambda: None
    robot = urllib.robotparser.RobotFileParser()
    robot.parse(["User-agent: *", "Allow: /"])
    fake.robots = {"hellhades": robot}
    url = SOURCES["hellhades"] + "/__nightly_policy_test__/"
    with patch.object(fake.opener, "open", side_effect=urllib.error.HTTPError(url, 403, "test", {}, None)) as mocked, patch.object(LOG, "error"):
        for _ in range(2):
            try:
                fake.get("hellhades", url)
                raise AssertionError("blocked source was allowed")
            except SourceHalted:
                pass
        assert mocked.call_count == 1 and fake.state["sources"]["hellhades"]["status"] == "halted"
    LOG.info("SELF_TEST_PASS atomic persistence, checkpoint-lag recovery, write isolation, five-state comparison, no fuzzy identity, stop on access denial")


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("command", choices=("prepare", "sample", "run", "status", "verify", "self-test"))
    parser.add_argument("--delay", type=float, default=4.0, help="Sequential request start interval, minimum 3 seconds")
    parser.add_argument("--max-items", type=int, help="Graceful interruption after this many new source records; for resume verification")
    parser.add_argument("--retry-failed", action="store_true", help="Retry failed items; blocked sources stay halted")
    parser.add_argument("--background", action="store_true", help="Log to files only, for a detached Windows process")
    args = parser.parse_args()
    configure_logging(args.background)
    for sig in (signal.SIGINT, signal.SIGTERM):
        signal.signal(sig, signal_stop)
    if args.command == "status":
        print(json.dumps(read(HOME / "summary.json", {}), ensure_ascii=False, indent=2)); return
    if args.command == "self-test":
        self_test(); return
    with RunLock():
        client = Client(args.delay)
        manifest = prepare(client)
        if args.command == "prepare":
            print(json.dumps({"targets": manifest["target_count"], "mapping": dict(Counter(t["hellhades_identity_method"] for t in manifest["targets"]))}, indent=2)); return
        if args.command == "verify":
            check = check_protected(manifest)
            print(json.dumps(check, ensure_ascii=False, indent=2))
            if not check["unchanged"]:
                raise SystemExit(2)
            return
        summary = execute(client, manifest, args.command, args.max_items, args.retry_failed)
        if not args.background:
            print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    try:
        main()
    except Exception:
        LOG.exception("FATAL; existing results retained; repeat command to resume")
        raise

