"""Pure display-only skill links. No champion edits, translations, combat rules or IO.

Published records retain their exact identity anchors. The separate game view
uses hero/form/skill ID references and audited serialization keys + enum constants,
not English names, list order guesses, or a sample flag correlation.
"""
from collections import Counter, defaultdict
from html import unescape
import re


def exact(value):
    return " ".join(str(value or "").split()).casefold()


def compile_game_views(document, schema):
    """Whole-corpus display decisions; raw English/analysis inputs stay untouched.

    Different hero-state variants are NOT selected by list position. Only an
    identical (form, slot, skill ID) reference in every variant may survive.
    Hidden HUD skills and unknown fields fail closed. IsSecret is a separate
    condition flag, NOT a visibility enum: visible secret skills retain their
    descriptions, with their actual activation explicitly unverified.
    """
    expected_keys = {"Id":"i", "Group":"g", "Cooldown":"c", "Visibility":"vn", "IsSecret":"h"}
    if (schema.get("schema_version") != 1 or schema.get("game_data_version") != document["game_data_version"]
            or schema.get("cache_sha256") != document["source"]["sha256"]
            or any(schema["fields"][k]["key"] != v for k,v in expected_keys.items())):
        raise ValueError("Unverified skill display schema")
    visibility = {v["value"]: k for k,v in schema["enums"]["SharedModel.Meta.Skills.Visibility"].items()}
    groups = {v["value"]: k for k,v in schema["enums"]["SharedModel.Meta.Skills.SkillGroup"].items()}
    if visibility.get(0) != "Visible" or groups != {0:"Active", 1:"Passive"}:
        raise ValueError("Unsupported visibility/kind enum")
    records, reasons = {}, {}
    for key, skill in document["skills"].items():
        raw = skill["raw_metadata"]
        reason = None
        if skill["classification"]["status"] == "internal_clone":
            reason = "explicit_internal_clone"
        elif type(raw["vn"]) is not int or raw["vn"] not in visibility:
            reason = "unknown_visibility"
        elif visibility[raw["vn"]] != "Visible":
            reason = "hidden_by_game_visibility"
        elif type(raw["h"]) is not bool:
            reason = "unknown_secret_flag"
        elif type(raw["g"]) is not int or raw["g"] not in groups:
            reason = "unknown_skill_kind"
        elif not skill.get("name_ko") and not skill["english"].get("name"):
            reason = "no_verified_display_name"
        if reason:
            reasons[int(key)] = reason
        else:
            records[int(key)] = {"skill_id":int(key), "kind":groups[raw["g"]],
                                 "name":skill.get("name_ko") or skill["english"]["name"],
                                 "description":skill.get("description_ko"),
                                 "name_ko":bool(skill.get("name_ko")),
                                 "description_ko":bool(skill.get("description_ko")),
                                 "special_condition_unverified":raw["h"],
                                 "cooldown_raw":raw["c"],
                                 "localization_keys":dict(skill["localization_keys"])}
    views = {}
    for champion in document["champions"]:
        variants = champion["game_variants"]
        contexts = [{(f["form_index"], r["order"], r["skill_id"])
                     for f in v["forms"] for r in f["skills"]} for v in variants]
        invariant = set.intersection(*contexts)
        held = []
        for context in sorted(set.union(*contexts)):
            form, order, identifier = context
            reason = reasons.get(identifier)
            if not reason and context not in invariant:
                reason = "variant_dependent_skill_reference"
            if reason:
                held.append({"form_index":form, "order":order, "skill_id":identifier, "reason":reason})
        forms = []
        for form in variants[0]["forms"]:
            entries = []
            for ref in form["skills"]:
                identifier = ref["skill_id"]
                if identifier in records and (form["form_index"],ref["order"],identifier) in invariant:
                    entries.append(dict(records[identifier], order=ref["order"]))
            forms.append({"form_index":form["form_index"], "skills":entries})
        views[champion["champion_id"]] = {
            "champion_id":champion["champion_id"], "game_hero_ids":[v["game_hero_id"] for v in variants],
            "forms":forms, "held":held, "game_data_version":document["game_data_version"],
            "aura_raw_present":any(v["aura"]["raw"] for v in variants),
            "identity_method":champion["identity_evidence"]["method"],
        }
    return views


def audit_game_views(views, all_skill_ids):
    linked, champions, pending = set(), [], defaultdict(set)
    for identifier, view in sorted(views.items()):
        ids = {s["skill_id"] for f in view["forms"] for s in f["skills"]}
        if ids: champions.append(identifier)
        linked.update(ids)
        for item in view["held"]: pending[item["reason"]].add(item["skill_id"])
    return {"target_champions":len(views), "linked_champions":champions, "linked_skill_ids":sorted(linked),
            "pending_by_reason":{k:sorted(v-linked) for k,v in sorted(pending.items()) if v-linked},
            "unconnected_skill_ids":sorted(set(all_skill_ids)-linked)}


def description_key(value):
    # Formatting equivalence only; no token similarity or numerical signatures.
    text = re.sub(r"</?color(?:=[^>]*)?>", "", str(value or ""))
    return exact(unescape(text).replace("\u2019", "'"))


def compile_index(document):
    skills = document["skills"]
    champions = {}
    for champion in document["champions"]:
        contexts = defaultdict(set)
        for variant in champion["game_variants"]:
            for form in variant["forms"]:
                for ref in form["skills"]:
                    contexts[ref["skill_id"]].add((variant["game_hero_id"], form["form_index"]))
        names, descriptions = defaultdict(set), defaultdict(set)
        eligible, held = {}, {}
        for identifier, scope in contexts.items():
            record = skills[str(identifier)]
            status = record["classification"]["status"]
            if status != "display_candidate":
                held[identifier] = "internal_clone" if status == "internal_clone" else "unverified_visibility"
                continue
            eligible[identifier] = record
            if record["english"]["name"]:
                names[exact(record["english"]["name"])].add(identifier)
            desc = record["raw_localization"].get("description_default")
            if (isinstance(desc, str) and len(desc.strip()) >= 40
                    and not re.search(r"^(?:Skill\s*\d|Attack:|Debuff:)|passive part", desc, re.I)):
                descriptions[description_key(desc)].add(identifier)
        champions[champion["champion_id"]] = {
            "eligible": eligible, "held": held, "contexts": dict(contexts),
            "names": dict(names), "descriptions": dict(descriptions),
            "name_en": champion["name_en"],
        }
    return champions


def _cooldown(skill):
    value = skill.get("cooldown")
    if value is None:
        found = re.search(r"\bCooldown:\s*(\d+)\s*turns?\b", str(skill.get("source_label") or ""), re.I)
        value = int(found[1]) if found else None
    return value


def connect(index, champion_id, skills):
    """Return one decision per existing record, including every withholding reason."""
    info = index.get(champion_id)
    decisions = [{"status": "held", "reason": "champion_not_linked", "skill_id": None} for _ in skills]
    if not info:
        return decisions
    names = Counter(exact(s.get("name")) for s in skills if isinstance(s, dict))
    descriptions = Counter(description_key(s.get("description")) for s in skills if isinstance(s, dict))
    groups = defaultdict(list)
    for position, skill in enumerate(skills):
        decision = decisions[position]
        if not isinstance(skill, dict):
            decision["reason"] = "invalid_source_skill"
            continue
        method = None
        explicit = skill.get("game_skill_id")
        if explicit is not None:
            if type(explicit) is not int or explicit not in info["eligible"]:
                decision["reason"] = "unverified_or_invalid_game_skill_id"
                continue
            ids, method = {explicit}, "explicit_game_skill_id"
        else:
            ids = info["names"].get(exact(skill.get("name")), set())
            if ids and names[exact(skill.get("name"))] == 1:
                method = "unique_exact_full_published_name"
            else:
                ids = info["descriptions"].get(description_key(skill.get("description")), set())
                if ids and descriptions[description_key(skill.get("description"))] == 1:
                    method = "unique_exact_full_English_description"
                else:
                    decision["reason"] = "no_unique_explicit_identity_anchor"
                    continue
        if len(ids) != 1:
            decision["reason"] = "ambiguous_skill_identity"
            continue
        identifier = next(iter(ids))
        record = info["eligible"][identifier]
        raw_cd, cd = record["raw_metadata"]["c"], _cooldown(skill)
        if not (type(raw_cd) is int and ((raw_cd == 0 and cd is None) or type(cd) is int and cd == raw_cd)):
            decision["reason"] = "cooldown_conflict_or_unknown"
            continue
        if skill.get("type") == "Passive" and record["raw_metadata"]["g"] != 1:
            decision["reason"] = "skill_kind_conflict"
            continue
        decision.update(status="provisional", reason=None, skill_id=identifier, method=method)
        groups[str(skill.get("form") or "")].append(position)
    # Every source form must have a common game form/variant. Labels or order never select it.
    for positions in groups.values():
        scopes = [info["contexts"][decisions[p]["skill_id"]] for p in positions]
        shared = set.intersection(*scopes)
        identifiers = [decisions[p]["skill_id"] for p in positions]
        duplicates = {k for k, count in Counter(identifiers).items() if count > 1}
        for p in positions:
            decision = decisions[p]
            if decision["skill_id"] in duplicates:
                decision.update(status="held", reason="duplicate_source_reference", skill_id=None)
            elif not shared:
                decision.update(status="held", reason="form_context_conflict", skill_id=None)
            else:
                decision.update(status="verified", form_contexts=sorted(shared))
    return decisions


def overlay(index, champion_id, skills):
    decisions = connect(index, champion_id, skills)
    result = []
    for skill, decision in zip(skills, decisions):
        if not isinstance(skill, dict):
            result.append(None)
            continue
        item = {"name": skill.get("name"), "description": skill.get("description"), "game_skill_id": None}
        if decision["status"] == "verified":
            record = index[champion_id]["eligible"][decision["skill_id"]]
            for field, localized in (("name", "name_ko"), ("description", "description_ko")):
                old = skill.get(field)
                if not re.search("[가-힣]", str(old or "")) and record.get(localized):
                    item[field] = re.sub(r"</?color(?:=[^>]*)?>", "", record[localized])
            item["game_skill_id"] = decision["skill_id"]
            item["evidence"] = {
                "champion_id": champion_id, "method": decision["method"],
                "form_contexts": decision["form_contexts"], "cooldown_compatible": True,
                "source": "game_static_cache_11.85.5", "scope": "display_only_not_combat_verification",
            }
        result.append(item)
    return result


def audit(index, published_by_champion, all_skill_ids):
    """Whole-corpus deterministic audit, including absent sources and never-visible candidates."""
    verified, champion_ids = set(), set()
    reasons = defaultdict(set)
    for champion_id in sorted(index):
        sources = published_by_champion.get(champion_id, {})
        if not sources:
            reasons["no_validated_published_skill_source"].update(index[champion_id]["eligible"])
        for source in sorted(sources):
            for decision in connect(index, champion_id, sources[source]):
                if decision["status"] == "verified":
                    verified.add(decision["skill_id"])
                    champion_ids.add(champion_id)
        for identifier, reason in index[champion_id]["held"].items():
            reasons[reason].add(identifier)
    eligible = {i for c in index.values() for i in c["eligible"]}
    already_explained = set().union(*reasons.values()) if reasons else set()
    reasons["no_verified_identity_or_form_anchor"].update(eligible - verified - already_explained)
    pending = {key: sorted(ids - verified) for key, ids in sorted(reasons.items()) if ids - verified}
    return {"target_champions": len(index), "verified_champions": sorted(champion_ids),
            "verified_skill_ids": sorted(verified), "pending_by_reason": pending,
            "unconnected_skill_ids": sorted(set(all_skill_ids) - verified)}

