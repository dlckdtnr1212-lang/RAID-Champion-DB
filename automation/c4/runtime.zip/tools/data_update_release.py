"""Local publication preflight. Never contacts or writes to GitHub."""
from pathlib import Path
import json
import tempfile
import shutil

from game_data_update import DataUpdateManager, UpdateError, confined, digest, json_bytes
from game_data_online import validate_online_manifest, extract_package

ROOT = Path(__file__).resolve().parent.parent


def preflight(output, manifest_path, base, app_version, published_index=None, allow_test_data=False, installed_store=None):
    output = Path(output).resolve()
    manifest_path = Path(manifest_path).resolve()
    if not manifest_path.is_relative_to(output):
        raise UpdateError('Manifest must be inside the publication directory')
    doc = json_bytes(manifest_path.read_bytes())
    validate_online_manifest(doc, app_version, doc.get('channel'))
    if manifest_path.relative_to(output).as_posix() != doc['channel']+'/manifest.json':
        raise UpdateError('Manifest is not in its channel publication path')
    is_test = bool(doc.get('test_data')) or any(marker in doc['description'].lower()
        for marker in ('synthetic', 'never publish', 'do not publish'))
    if is_test and not allow_test_data:
        raise UpdateError('Synthetic package is not eligible for publication')
    if published_index is None and not allow_test_data:
        raise UpdateError('Published file index is required for immutable-name validation; use an explicit empty index for the first publication')
    inventory = {}
    expected = {manifest_path.relative_to(output).as_posix()}
    entries = {f['path']: f for f in doc['files']}
    scratch = ROOT/'scratch/data_update_dev3/preflight'; scratch.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(dir=scratch) as temp:
        temp = Path(temp)
        extracted = temp/'payload'; extracted.mkdir()
        for package in doc['packages']:
            name = package['path']; path = confined(output, name)
            if path.stat().st_size != package['size'] or digest(path) != package['sha256']:
                raise UpdateError('Publication ZIP size/SHA-256 mismatch')
            extract_package(path, package, entries, extracted)
            expected.add(name)
        for item in doc['files']:
            name = f"files/{doc['data_version']}/{item['path']}"
            path = confined(output, name)
            if path.stat().st_size != item['size'] or digest(path) != item['sha256']:
                raise UpdateError('Publication raw sidecar size/SHA-256 mismatch')
            expected.add(name)
        actual = {p.relative_to(output).as_posix() for p in output.rglob('*') if p.is_file()}
        if actual != expected:
            raise UpdateError('Unlisted or missing publication files')
        manager = DataUpdateManager(base, temp/'validation_store', app_version)
        if installed_store:
            # Copy only the verified current overlay into the disposable store.
            # Never migrate/write the installed store, cache or personal files.
            current=DataUpdateManager(base,installed_store,app_version).snapshot()
            if current.error:
                raise UpdateError('Installed validation data needs recovery first')
            if current.generation:
                generation=manager.store/'generations'/current.generation.name
                for name in current.inventory:
                    target=confined(generation/'files',name)
                    target.parent.mkdir(parents=True,exist_ok=True)
                    shutil.copyfile(current.resolve(name),target)
                meta=generation/'generation.json'
                shutil.copyfile(current.generation/'generation.json',meta)
                manager.store.mkdir(parents=True,exist_ok=True)
                (manager.store/'active.json').write_text(json.dumps({'active':{
                    'generation':current.generation.name,'sha256':digest(meta)},'previous':None}),encoding='utf8')
        result = manager.apply(doc, package_dir=extracted)
        if not result.get('success') or not result.get('applied'):
            raise UpdateError('Publication prerequisite/schema/ID validation failed: '+str(result.get('error', 'version already installed')))
        for name in sorted(expected):
            path = confined(output, name)
            inventory[name] = {'size': path.stat().st_size, 'sha256': digest(path)}
    published = json_bytes(Path(published_index).read_bytes()) if published_index else {}
    prior = published.get('files', {})
    if not isinstance(prior,dict):raise UpdateError('Invalid published file index')
    mutable = {f'beta/manifest.json', f'stable/manifest.json'}
    for name, item in inventory.items():
        if name not in mutable and name in prior and prior[name] != item:
            raise UpdateError('Published immutable payload name collision: '+name)
    payloads = [name for name in inventory if name not in mutable and name not in prior]
    return {'success': True, 'preflight_pass': True, 'publication_approved': False, 'published': False,
            'test_data': is_test, 'data_version': doc['data_version'], 'channel': doc['channel'],
            'immutable_names_checked':published_index is not None,
            'files': inventory, 'publish_first': payloads,
            'already_published_unchanged': [n for n in inventory if n not in mutable and n in prior],
            'publish_last': manifest_path.relative_to(output).as_posix()}
