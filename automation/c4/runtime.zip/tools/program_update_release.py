"""Local-only Velopack pack + signed approval. No upload/publish functionality."""
import argparse
import base64
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from application_update import APP_ID, canonical, canonical_hash, verify_approval, atomic_json
from game_data_update import UpdateError, approved_url, version
from release_tools.release_versions import validate_release


def init_key(private, public):
    from cryptography.hazmat.primitives import serialization
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    if private.exists() or public.exists(): raise UpdateError('Never overwrite an existing signing key/trust file')
    key = Ed25519PrivateKey.generate()
    private.parent.mkdir(parents=True, exist_ok=True)
    private.write_bytes(key.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8, serialization.NoEncryption()))
    atomic_json(public, {'format_version': 1, 'keys': {'raid_release_1': base64.b64encode(key.public_key().public_bytes_raw()).decode()}})


def approve(feed_dir, key_file, trust_file, *, package_version, app_version, channel, sequence,
            url_base, data_manifest=None, local_proof=False, data_min='1.0.0', data_max='1.0.1'):
    from cryptography.hazmat.primitives import serialization
    version(app_version, True)
    approved_url(url_base + '/placeholder.nupkg')
    feed = json.loads((feed_dir/f'releases.{channel}.json').read_bytes())
    manifest = json.loads(data_manifest.read_bytes()) if data_manifest else None
    if not local_proof:
        validate_release(package_version, app_version, manifest, channel)
    payload = {'format_version': 1, 'channel': channel, 'sequence': sequence,
               'expires_at': int(time.time())+180*86400,
               'local_proof_only': local_proof,
               'data_manifest_canonical_sha256': canonical_hash(manifest) if manifest else None,
               'program': {'package_version': package_version, 'app_version': app_version,
                           'data_schema_version': 1, 'supported_data_versions': {'min': data_min, 'max': data_max},
                           'description': '승인된 Windows 프로그램 변경분. 사용자 개인 파일 보존.',
                           'feed': feed, 'urls': {a['FileName']: url_base.rstrip('/')+'/'+a['FileName'] for a in feed['Assets']}}}
    key = serialization.load_pem_private_key(key_file.read_bytes(), password=None)
    envelope = {'payload': payload, 'signature': base64.b64encode(key.sign(canonical(payload))).decode(), 'key_id': 'raid_release_1'}
    verify_approval(envelope, json.loads(trust_file.read_bytes()), channel, allow_local_proof=local_proof)
    path = feed_dir/'approval.json'
    if path.exists(): raise UpdateError('Choose a fresh local release directory')
    atomic_json(path, envelope)
    return envelope


def main():
    p = argparse.ArgumentParser(description=__doc__)
    sub = p.add_subparsers(dest='command', required=True)
    key = sub.add_parser('init-key')
    key.add_argument('--private', type=Path, required=True)
    key.add_argument('--public', type=Path, default=ROOT/'release_tools/update_trust.json')
    data = sub.add_parser('approve-data', help='Connect an existing DEV4/6 preflighted data manifest; no app build')
    data.add_argument('--manifest', type=Path, required=True)
    data.add_argument('--preflight', type=Path, required=True)
    data.add_argument('--previous-approval', type=Path)
    data.add_argument('--output', type=Path, required=True)
    data.add_argument('--key', type=Path, required=True)
    data.add_argument('--channel', choices=['beta','stable'], required=True)
    data.add_argument('--sequence', type=int, required=True)
    pack = sub.add_parser('pack')
    pack.add_argument('--bundle', type=Path, required=True)
    pack.add_argument('--output', type=Path, required=True)
    pack.add_argument('--previous', type=Path)
    pack.add_argument('--version', required=True)
    pack.add_argument('--app-version', required=True)
    pack.add_argument('--channel', choices=['beta', 'stable'], required=True)
    pack.add_argument('--sequence', type=int, required=True)
    pack.add_argument('--asset-url-base', required=True)
    pack.add_argument('--data-manifest', type=Path)
    pack.add_argument('--data-min', default='1.0.0', help='Minimum active game-data version accepted by this program')
    pack.add_argument('--data-max', help='Maximum accepted data version; defaults to supplied manifest version')
    pack.add_argument('--key', type=Path, required=True)
    pack.add_argument('--trust', type=Path, default=ROOT/'release_tools/update_trust.json')
    pack.add_argument('--vpk', type=Path, default=ROOT/'scratch/auto_update_b/tools/vpk_cli/tools/net10.0/any/vpk.dll')
    pack.add_argument('--local-proof', action='store_true')
    args = p.parse_args()
    if args.command == 'init-key':
        init_key(args.private, args.public)
        print('Signing key created locally; keep private key out of all bundles. Public trust: '+str(args.public))
        return
    if args.command == 'approve-data':
        from cryptography.hazmat.primitives import serialization
        from game_data_update import digest
        preflight = json.loads(args.preflight.read_bytes())
        doc = json.loads(args.manifest.read_bytes())
        if not preflight.get('preflight_pass') or preflight.get('data_version') != doc['data_version'] or doc.get('channel') != args.channel:
            raise UpdateError('Matching existing data publication preflight is required')
        entry = preflight.get('publication_files', preflight.get('files', {})).get(args.channel+'/manifest.json')
        if not entry or entry['sha256'] != digest(args.manifest):
            raise UpdateError('Data manifest differs from existing preflight')
        prior = json.loads(args.previous_approval.read_bytes())['payload'] if args.previous_approval else {}
        payload = dict(prior, format_version=1, channel=args.channel, sequence=args.sequence,
                       expires_at=int(time.time())+180*86400,
                       data_manifest_canonical_sha256=canonical_hash(doc))
        payload.setdefault('program', None)
        if args.output.exists(): raise UpdateError('Never overwrite an existing approval candidate')
        key = serialization.load_pem_private_key(args.key.read_bytes(), password=None)
        envelope = {'payload':payload,'signature':base64.b64encode(key.sign(canonical(payload))).decode(),'key_id':'raid_release_1'}
        verify_approval(envelope, json.loads((ROOT/'release_tools/update_trust.json').read_bytes()), args.channel)
        atomic_json(args.output, envelope)
        print(json.dumps({'success':True,'published':False,'publish_last':str(args.output)}))
        return
    if args.output.exists(): raise UpdateError('Never overwrite an existing release candidate')
    if not args.local_proof:
        from PyInstaller.archive.readers import CArchiveReader
        from tools.auto_update_b_review import pe_version, pe_fixed_version
        manifest = json.loads(args.data_manifest.read_bytes()) if args.data_manifest else None
        fixed = validate_release(args.version, args.app_version, manifest, args.channel)
        executable = args.bundle/'RAID_Champion_DB.exe'
        archive = CArchiveReader(str(executable))
        modules = archive.open_embedded_archive('PYZ.pyz').toc
        if ('windows_entry' not in archive.toc or 'auto_update_candidate_entry' in archive.toc
                or any(name.startswith(('tools.', 'test_', 'dev6_candidate_entry', 'auto_update_candidate_entry')) for name in modules)):
            raise UpdateError('Production package requires the ordinary Windows entry without review modules')
        bundled = json.loads((args.bundle/'_internal/ui_web_proof/packaging_manifest.json').read_bytes())
        if (pe_version(executable) != args.version or tuple(pe_fixed_version(executable)) != fixed
                or bundled['application']['version'] != args.app_version):
            raise UpdateError('Actual PE, package and compatibility versions disagree')
    # Explicit bundle created by the existing public-source/resource allowlist.
    forbidden = {'teams.json', 'owned_champions.json', 'account_settings.json', 'final_stats.json',
                 'update_control.json', 'approval.key', 'embedded_private_data.json'}
    for path in args.bundle.rglob('*'):
        if path.name in forbidden or any(part in ('user_data','game_data_updates','dev_test_data') for part in path.relative_to(args.bundle).parts):
            raise UpdateError('Personal/update-store file cannot be packaged: '+path.name)
    args.output.mkdir(parents=True)
    if args.previous:
        # Only the immediately previous Full is needed to generate this delta.
        index = json.loads((args.previous/f'assets.{args.channel}.json').read_bytes())
        previous_full = [item['RelativeFileName'] for item in index if item['Type'] == 'Full']
        if len(previous_full) != 1:
            raise UpdateError('Previous release must identify exactly one baseline Full')
        path = args.previous/previous_full[0]
        if path.name != previous_full[0] or not path.is_file():
            raise UpdateError('Unsafe or missing baseline Full')
        try: os.link(path, args.output/path.name)
        except OSError: shutil.copyfile(path, args.output/path.name)
    command = ['dotnet', str(args.vpk), 'pack', '--packId', APP_ID, '--packVersion', args.version,
               '--packDir', str(args.bundle), '--mainExe', 'RAID_Champion_DB.exe', '--channel', args.channel,
               '--runtime', 'win-x64', '--packAuthors', 'JYrun', '--packTitle', 'RAID Champion DB Auto Update Beta' if args.channel == 'beta' else 'RAID Champion DB',
               '--noPortable', '--outputDir', str(args.output)]
    subprocess.run(command, check=True)
    # Keep old local proof builds out of a new public feed and upload directory.
    feed_path = args.output/f'releases.{args.channel}.json'
    feed = json.loads(feed_path.read_bytes())
    feed['Assets'] = [a for a in feed['Assets'] if a['Version'] == args.version]
    atomic_json(feed_path, feed)
    legacy = args.output/('RELEASES-'+args.channel)
    if legacy.exists():
        names = {a['FileName'] for a in feed['Assets']}
        legacy.write_text(''.join(line+'\n' for line in legacy.read_text().splitlines()
                                  if len(line.split()) == 3 and line.split()[1] in names), encoding='utf8')
    if args.previous:
        (args.output/previous_full[0]).unlink()  # unlink only this new directory's baseline link
    approve(args.output, args.key, args.trust, package_version=args.version, app_version=args.app_version,
            channel=args.channel, sequence=args.sequence, url_base=args.asset_url_base,
            data_manifest=args.data_manifest, local_proof=args.local_proof, data_min=args.data_min,
            data_max=args.data_max or (json.loads(args.data_manifest.read_bytes())['data_version'] if args.data_manifest else '1.0.0'))
    print(json.dumps({'success': True, 'published': False, 'publication_approved': False,
                      'publish_first': [p.name for p in args.output.glob('*.nupkg')],
                      'publish_last': 'program-updates/'+args.channel+'/approval.json',
                      'installer': [p.name for p in args.output.glob('*Setup.exe')]}))


if __name__ == '__main__': main()
