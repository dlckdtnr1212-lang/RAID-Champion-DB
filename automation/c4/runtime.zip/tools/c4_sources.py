"""Bounded C-4 discovery and validation adapters over the existing C-1 parser."""
from __future__ import annotations

import copy
import hashlib
from pathlib import Path
import re
import time
from types import SimpleNamespace
from urllib.parse import urlsplit, urljoin, parse_qs

from tools import c_data_pipeline as c
from tools import c_night_collect as old


def fingerprint(value):
    return hashlib.sha256(c.encoded(value)).hexdigest()


def index_rows(raw):
    doc = c.json_bytes(raw)
    rows = doc.get('champions') if isinstance(doc, dict) else doc
    if not isinstance(rows, list):
        raise c.UpdateError('Unexpected C-1 champion index schema')
    result = {}
    for row in rows:
        hid = row.get('heroId')
        if type(hid) is not int or hid <= 0:
            continue
        item = {k: row.get(k) for k in ('heroId', 'champion', 'rarity', 'role', 'affinity_index', 'faction_index', 'url')}
        if hid in result and result[hid] != item:
            raise c.UpdateError('Conflicting duplicate index hero ID')
        result[hid] = item
    if not result:
        raise c.UpdateError('Empty champion index is not a successful change check')
    return result


def news_links(raw):
    doc = old.OLD.DOM(raw.decode('utf8', 'replace'))
    return sorted({urljoin(old.NEWS, n.attrs.get('href', '')) for n in doc.nodes if n.tag == 'a' and
                   re.search(r'/843_news/\d+_[^/?]*(?:new-update-version|update-highlights|new-champions)', n.attrs.get('href', ''))})


def article(raw):
    """Reuse C-1 DOM, restrict facts to the first post, never forum replies."""
    doc = old.OLD.DOM(raw.decode('utf8', 'replace'))
    title = next((n.text() for n in doc.nodes if n.tag == 'h2' and re.search(r'(?:Version|Highlights)\s+\d+', n.text(), re.I)), '')
    first = next((n for n in doc.nodes if n.tag == 'h3'), None)
    if not first or not title:
        raise c.UpdateError('Official article structure unavailable; no inferred facts')
    # Existing C-1 parser identifies the announcement by first h3's parent.
    # If that parent also contains reply controls, refuse its scope.
    container = first.parent
    nodes = container.all()
    lines = [n.text().strip() for n in nodes if n.tag in ('p', 'h3', 'h4', 'li') and n.text().strip()]
    if any(s in container.text() for s in ('Leave a comment', 'Comments are closed')):
        raise c.UpdateError('Announcement/reply boundary needs source adapter review')
    match = re.search(r'(?:Version|Highlights)\s+(\d+\.\d+(?:\.\d+)?)', title, re.I)
    game_version = match[1] if match else None
    if game_version and len(game_version.split('.')) == 2:
        raise c.UpdateError('Official patch version is incomplete; no assumed patch number')
    if not game_version:
        raise c.UpdateError('No explicit official patch version')
    return {'title': title, 'game_version': game_version, 'lines': lines}


def exact_metadata(document, name, field):
    labels = {'role': 'Type', 'rarity': 'Rarity', 'affinity': 'Affinity', 'faction': 'Faction'}
    lines = document['lines']
    positions = [i for i, line in enumerate(lines) if line == name]
    if len(positions) != 1 or field not in labels:
        return None
    # Strict complete four-line metadata block. Never borrow a later champion's field.
    block = lines[positions[0] + 1:positions[0] + 5]
    values = {}
    for text in block:
        match = re.fullmatch(r'(Rarity|Type|Affinity|Faction):\s*(.+)', text)
        if match:
            values[match[1]] = match[2]
    return values[labels[field]] if set(values) == set(labels.values()) else None


class Sources:
    def __init__(self, root, *, deadline_seconds=900, request_limit=40):
        self.root = c.scratch_path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        self.deadline = time.monotonic() + deadline_seconds
        self.limit = request_limit
        self.requests = []
        self.completed = c.read(self.root / 'completed_requests.json') if (self.root / 'completed_requests.json').is_file() else {}
        old.OUT = self.root  # Only C-4's separate scratch cache, never original C-1 results.
        self.args = SimpleNamespace(offline=False, refresh=True, max_hours=.25, retry_failed=False)
        self.state = {'halted': {}}
        self.client = old.Client(self)
        self.client_run_fetch = self.client.fetch

    def check(self):
        if time.monotonic() >= self.deadline:
            raise c.UpdateError('C-4 bounded collection deadline reached; resume next run')

    def pause(self, seconds):
        self.check()
        if time.monotonic() + seconds >= self.deadline:
            raise c.UpdateError('C-4 source pacing exceeds run budget')
        time.sleep(seconds)

    def checkpoint(self):
        c.write(self.root / 'source_halt.json', self.state['halted'])

    def close(self):
        self.client.close()

    def reset_batch(self, batch_id):
        if self.completed.get('batch_id') != batch_id:
            self.completed = {'batch_id': batch_id, 'urls': {}}
            c.write(self.root / 'completed_requests.json', self.completed)
            c.write(self.root / 'checkpoints/state.json', {'tasks': {}, 'halted': {}})
            c.write(self.root / 'normalized/records.json', {})

    def fetch(self, url, *, detect=False):
        if not detect and url in self.completed.get('urls', {}):
            prior = self.client.cache.get(url)
            if prior and prior['sha256'] == self.completed['urls'][url]:
                data = c.confined(self.root, prior['path']).read_bytes()
                if hashlib.sha256(data).hexdigest() == prior['sha256']:
                    return data, prior
        self.check()
        if len(self.requests) >= self.limit:
            raise c.UpdateError('C-4 per-run request limit; resume next run')
        self.requests.append(url)
        data, meta = self.client_run_fetch(url)
        if not detect:
            self.completed.setdefault('urls', {})[url] = meta['sha256']
            c.write(self.root / 'completed_requests.json', self.completed)
        return data, meta

    def seed(self):
        """Use only the relevant C-1 cached responses, never run its entry point."""
        cache = c.read(c.C1 / 'checkpoints/http.json')
        for url in (old.INDEX, old.NEWS, old.PATCH):
            if url not in self.client.cache and url in cache:
                item = cache[url]
                source = c.confined(c.C1, item['path'])
                if source.is_file() and c.digest(source) == item['sha256']:
                    target = c.confined(self.root, item['path'])
                    target.parent.mkdir(parents=True, exist_ok=True)
                    if not target.exists():
                        target.write_bytes(source.read_bytes())
                    self.client.cache[url] = item
        c.write(self.root / 'checkpoints/http.json', self.client.cache)

    def discover(self):
        data, _ = self.fetch(old.INDEX, detect=True)
        rows = index_rows(data)
        news, _ = self.fetch(old.NEWS, detect=True)
        links = news_links(news)
        documents, errors = [], []
        # Check latest patch content too: an edited announcement can retain its URL.
        patch_links = [u for u in links if 'new-update-version' in u]
        latest = max(patch_links, key=lambda u: int(re.search(r'/843_news/(\d+)', u)[1])) if patch_links else old.PATCH
        try:
            raw, meta = self.fetch(latest, detect=True)
            documents.append(dict(article(raw), source=latest, raw_file=meta['path'], raw_file_sha256=meta['sha256']))
        except (OSError, ValueError, old.Skip) as exc:
            errors.append(str(exc))
        stable = {'rows': {str(h): fingerprint(v) for h, v in rows.items()}, 'links': links,
                  'articles': {d['source']: fingerprint({'version': d['game_version'], 'lines': d['lines']}) for d in documents}}
        return {'fingerprint': fingerprint(stable), 'stable': stable, 'rows': rows,
                'documents': documents, 'errors': errors}

    def prior_stable(self):
        cache = c.read(c.C1 / 'checkpoints/http.json')
        item = cache.get(old.INDEX)
        if not item:
            return {}
        path = c.confined(c.C1, item['path'])
        if c.digest(path) != item['sha256']:
            raise c.UpdateError('C-1 discovery seed changed')
        return {'rows': {str(h): fingerprint(v) for h, v in index_rows(path.read_bytes()).items()}, 'articles': {}}

    def collect(self, baseline, targets, batch_id):
        self.reset_batch(batch_id)
        collector = old.Collector(self.args)
        collector.deadline = self.deadline
        collector.client.close()
        collector.client = self.client
        # Collector.champion/skills/task/emit/persist remain the original implementation.
        # Only fetch is adapted to reuse completed pieces after interruption.
        self.client.fetch = lambda url: self.fetch(url)
        collector.game = baseline.game
        collector.hero_map = baseline.hero
        collector.champs = {cid: row for cid in baseline.targets for _, row in [baseline.collected_row(cid)] if row}
        for row in targets:
            collector.task('c4_hero:' + str(row['heroId']), lambda row=row: collector.champion({'row': row}))
            collector.persist()
        failed = {k: v for k, v in collector.state['tasks'].items() if v['status'] != 'done'}
        if failed:
            raise c.UpdateError('Incremental C-1 tasks incomplete: ' + ','.join(failed))
        return collector.records

    def initial_candidates(self):
        prior = c.read(c.C1 / 'changes/c_diff_dry_run.json')
        wanted = {r['record_id'] for r in prior['records'] if r['classification'] in ('NEW', 'CHANGED')}
        records = c.read(c.C1 / 'normalized/records.json')
        selected = {key: value for key, value in records.items() if key in wanted}
        for record in selected.values():
            source = c.confined(c.C1, record['raw_file'])
            if c.digest(source) != record['raw_file_sha256']:
                raise c.UpdateError('Original C-1 candidate evidence changed')
            target = c.confined(self.root, record['raw_file'])
            target.parent.mkdir(parents=True, exist_ok=True)
            if not target.exists():
                target.write_bytes(source.read_bytes())
        return selected

    def refresh_metadata(self, records, discovery, baseline):
        """Reuse C-1 emit/canonical enums for only the selected existing candidates."""
        meta = self.client.cache[old.INDEX]
        output = copy.deepcopy(records)
        emitter = SimpleNamespace(check=self.check, records=output)
        for record in records.values():
            if record['kind'] != 'champion_field':
                continue
            hid, field = record['game_hero_id'], record['identity'][1]
            current = discovery['rows'].get(hid)
            if not current:
                continue
            column = {'name_en': 'champion', 'affinity': 'affinity_index', 'faction': 'faction_index'}.get(field, field)
            value = current[column]
            if field != 'name_en':
                value = old.OLD.canonical_basic(field, value)
            ids = baseline.hero.get(str(hid), set())
            cid = next(iter(ids)) if len(ids) == 1 else None
            old.Collector.emit(emitter, 'champion_field', [str(hid), field], value, meta,
                               record.get('old_value'), champion_id=cid, game_hero_id=hid)
        return output


class ValidatedComparison(c.Comparison):
    """Add actual-source receipts without accepting caller-provided verified flags."""
    def __init__(self, baseline, records, source_root, documents):
        super().__init__(baseline, records, source_root)
        self.documents = documents

    def row(self, rid, record):
        row = super().row(rid, record)
        row['calculation_impact'] = ('metadata_input_change; existing enum validation required; no formula/stat rewrite'
                                     if record['kind'] == 'champion_field' else 'unresolved_skill_semantics')
        if record['kind'] == 'champion_field' and row['gates']['exact_ids']:
            raw = c.json_bytes(self.raw(record))
            if record['source'] != old.INDEX:
                row['invalid'] = True
                row['reasons'].append('not_the_pinned_C1_index_source')
                return row
            source = index_rows(c.encoded(raw)).get(record['game_hero_id'])
            field = record['identity'][1]
            column = {'name_en': 'champion', 'faction': 'faction_index', 'affinity': 'affinity_index'}.get(field, field)
            if not source or c.normalize_champion(field, source.get(column)) != c.normalize_champion(field, record['new_value']):
                row['invalid'] = True
                row['reasons'].append('raw_index_id_value_mismatch')
                return row
            row['source_id_value_checked'] = True
            if field == 'name_en':
                # Under the already exact game ID only; not an entity-name join.
                plain = lambda s: ''.join(ch for ch in s.casefold() if ch.isalnum())
                if plain(row['operating_value']) == plain(record['new_value']):
                    row['reference_only'] = True
                    row['reasons'].append('same_ID_display_punctuation_or_capitalization_only_no_identity_rewrite')
            for document in self.documents:
                raw_path = c.confined(self.c1, document['raw_file'])
                if c.digest(raw_path) != document['raw_file_sha256']:
                    raise c.UpdateError('Official announcement evidence changed')
                # Reparse original bytes; never trust a hand-written parsed-document receipt.
                actual = article(raw_path.read_bytes())
                if actual['game_version'] != document['game_version']:
                    raise c.UpdateError('Official announcement version mismatch')
                if urlsplit(document['source']).hostname != 'forum.plarium.com' or not re.fullmatch(
                    r'https://forum\.plarium\.com/raid-shadow-legends/843_news/\d+_new-update-version-[a-z0-9-]+/', document['source']):
                    continue
                value = exact_metadata(actual, source['champion'], field)
                versions = [self.baseline.game.get('game_data_version') or '0.0.0']
                skill_ids = {t[3] for t in self.baseline.links if t[0] == record['champion_id']}
                versions += [v for v, overlay in self.baseline.game.get('patch_overlays', {}).items()
                             if skill_ids.intersection(map(str, overlay.get('skill_ids', [])))]
                minimum = max(c.version(v) for v in versions)
                if value is not None and c.version(actual['game_version']) >= minimum and (
                    c.normalize_champion(field, value) == row.get('normalized_new_value')):
                    row['gates']['source_evidence'] = True
                    row['source_proof'] = {'kind': 'official_metadata_exact_name_plus_existing_verified_hero_ID',
                        'source': document['source'], 'sha256': document['raw_file_sha256'], 'raw_file': document['raw_file'],
                        'game_version': actual['game_version'], 'field': field, 'literal': value,
                        'index_sha256': record['raw_file_sha256']}
                    row['reasons'].append('official_metadata_and_exact_source_hero_ID_agree')
        if record['kind'] == 'skill':
            # Reconstruct C-1's fields from its hash-checked raw response. Shared
            # receipts cannot substitute a skill object or derived cooldown/name.
            parts = urlsplit(record['source'])
            query = parse_qs(parts.query)
            raw_rows = c.json_bytes(self.raw(record))
            sid, hid = str(record['skill_id']), str(record['game_hero_id'])
            objects = [s for s in raw_rows if isinstance(s, dict) and str(s.get('id')) == sid] if isinstance(raw_rows, list) else []
            if (parts.scheme != 'https' or parts.hostname != 'hellhades.com' or parts.path != '/wp-json/hh-api/v3/skills'
                or query.get('heroid') != [hid] or len(objects) != 1
                or sid not in query.get('skills', [''])[0].split(',')):
                raise c.UpdateError('Raw skill source/hero/skill identity mismatch')
            obj = objects[0]
            expected = {k: obj.get(k) for k in ('id', 'name', 'description', 'type', 'cooldown', 'books', 'multiplier', 'abilities', 'unity')}
            fields = {'name': obj.get('name'), 'description': old.text(obj.get('description')), 'type': obj.get('type'),
                'cooldown_raw': obj.get('cooldown'), 'books': obj.get('books'), 'multipliers_raw': obj.get('multiplier'),
                'abilities': obj.get('abilities'), 'hits_raw': [m.get('attacks') for m in (obj.get('multiplier') or []) if isinstance(m, dict)]}
            if record['new_value'] != expected or record.get('fields') != fields:
                raise c.UpdateError('Raw skill values differ from collected receipt')
            row['skill_validation'] = {'exact_game_form_link': row['gates']['exact_ids'],
                'raw_source_id_value_checked': True,
                'cooldown_compared': [x for x in row['comparisons'] if x['field'] == 'cooldown_unbooked'],
                'effects_coefficients_books_targets': 'not_equivalent_to_game_schema_no_inference',
                'automatic_numeric_engine_change': False}
        return row


def new_champion_review(baseline, candidate_records):
    original = c.read(c.C1 / 'normalized/records.json')
    ids = sorted({r['game_hero_id'] for r in candidate_records.values() if r.get('champion_id') is None and r.get('game_hero_id')})
    result = []
    for hid in ids:
        records = [r for r in original.values() if r.get('game_hero_id') == hid]
        forms = [r['new_value'] for r in records if r['kind'] == 'champion_form']
        skills = {str(r['skill_id']) for r in records if r['kind'] == 'skill'}
        required = {s for f in forms for s in f['skills'].split(',')}
        result.append({'game_hero_id': hid, 'stable_champion_id': None,
            'name_en': next((r['new_value'] for r in records if r['kind'] == 'champion_field' and r['identity'][1] == 'name_en'), None),
            'forms': len(forms), 'source_skills': len(skills), 'all_source_skill_refs_present': bool(required) and required <= skills,
            'missing_source_skill_ids': sorted(required - skills),
            'existing_exact_ID_mapping': bool(baseline.hero.get(str(hid))),
            'db_registration_ready': False, 'readiness': 'REVIEW_REQUIRED',
            'missing': ['verified_local_champion_ID', 'game_Korean_localization', 'verified_max_level_stats',
                        'complete_game_display_schema_links', 'verified_effect_and_calculation_semantics'],
            'note': 'Source form model coefficients are not max-level champion stats. No invented ID or Korean label.'})
    return result
