"""C-4 scheduled, incremental, data-only automation. No program builds or UI writes."""
from __future__ import annotations

from collections import Counter
import contextlib
import copy
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import sys
import time
import uuid

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from tools import c_data_pipeline as c
from tools.c4_sources import Sources, ValidatedComparison, fingerprint, new_champion_review
from tools.c4_github import (GitHub, Blocked, KEY, TRUST, canonical_hash, local_baseline,
                             publish, RAW, MANIFEST, APPROVAL)
from tools.c_night_collect import Skip as SourceSkip

HOME = ROOT / 'scratch/c4_auto_update'
STATUSES = ('NO_CHANGE', 'NO_UPDATE', 'READY', 'PUBLISHED', 'BLOCKED', 'FAILED')


class Busy(Blocked):
    pass


def now():
    return datetime.now(timezone.utc).isoformat(timespec='seconds')


class Lock:
    def __init__(self, path):
        self.path = c.scratch_path(path)

    def __enter__(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.file = self.path.open('a+b')
        self.file.seek(0)
        if self.path.stat().st_size == 0:
            self.file.write(b'0')
            self.file.flush()
        self.file.seek(0)
        try:
            if os.name == 'nt':
                import msvcrt
                msvcrt.locking(self.file.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(self.file, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError:
            self.file.close()
            raise Busy('Another C-4 execution owns the lock')
        return self

    def __exit__(self, *_):
        self.file.close()


def signer_health():
    try:
        import base64
        from cryptography.hazmat.primitives import serialization
        key = serialization.load_pem_private_key(KEY.read_bytes(), password=None)
        return key.public_key().public_bytes_raw() == base64.b64decode(c.read(TRUST)['keys']['raid_release_1'])
    except (OSError, ValueError, ImportError, KeyError):
        return False


def protected():
    baseline = c.Baseline()
    names = c.protected_paths(baseline, c.C1) + [ROOT / 'tools/c_night_collect.py',
        ROOT / 'tools/c4_auto_update.py', ROOT / 'tools/c4_sources.py', ROOT / 'tools/c4_github.py', TRUST]
    names += [p for p in (ROOT / 'tools/c4_hybrid.py', ROOT / 'tools/c4_cloud_smoke.py') if p.is_file()]
    if (ROOT / 'c_night_collect.cmd').is_file():
        names.append(ROOT / 'c_night_collect.cmd')
    return {str(p.relative_to(ROOT)): c.digest(p) for p in names}


def guard(before):
    if any(c.digest(c.project_path(ROOT / path)) != sha for path, sha in before.items()):
        raise Blocked('Operating/C-1/personal/runtime input changed during C-4 run')


def baseline_from_journal(job):
    manifest = c.scratch_path(ROOT / job['baseline_manifest'])
    approval = c.scratch_path(ROOT / job['baseline_approval'])
    return {'manifest': c.read(manifest), 'approval': c.read(approval),
            'manifest_raw': manifest.read_bytes(), 'approval_raw': approval.read_bytes()}


def validate_sources(package, ready, baseline_manifest):
    path = c.scratch_path(ROOT / package['source_bundle'])
    if c.digest(path) != package['source_bundle_sha256']:
        raise Blocked('Source validation bundle changed')
    bundle = c.read(path)
    application_base = c.project_path(ROOT / package.get('baseline_base', '.'))
    if not package.get('test_data') and application_base != ROOT:
        raise Blocked('Production C-4 requires the actual application baseline')
    base = c.Baseline(ROOT / package['baseline_manifest'], ROOT / package['baseline_source'], application_base, expected_version=None)
    if canonical_hash(base.manifest) != canonical_hash(baseline_manifest):
        raise Blocked('Package source validation used a different baseline')
    rows = ValidatedComparison(base, bundle['records'], ROOT / bundle['source_root'], bundle['documents']).run()
    current = {r['record_id']: r for r in rows}
    for previous in ready:
        row = current.get(previous['record_id'])
        if not row or row.get('invalid') or row['classification'] not in ('NEW', 'CHANGED') or not all(
            row['gates'].get(g) for g in ('source_evidence', 'exact_ids', 'value_validation', 'no_conflict')):
            raise Blocked('AUTO_READY source facts no longer validate')
        if row['operations'] != previous['operations'] or row.get('source_proof') != previous.get('source_proof'):
            raise Blocked('AUTO_READY operation/source identity changed')


class Pipeline:
    def __init__(self, root=HOME, *, github=None, sources=None, publishing=False):
        self.root = c.scratch_path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        self.github = github or GitHub(self.root / 'github')
        self.sources = sources
        self.publishing = publishing
        self.state_path = self.root / 'state.json'
        self.state = c.read(self.state_path) if self.state_path.is_file() else {
            'format_version': 1, 'observed': None, 'initial_review_complete': False,
            'backlog': [], 'pending': None, 'last_published': None, 'processed_batches': []}
        self.run_id = uuid.uuid4().hex
        self.run_dir = self.root / 'runs' / self.run_id
        self.run_dir.mkdir(parents=True, exist_ok=False)
        self.result = {'format_version': 1, 'run_id': self.run_id, 'started_at': now(),
                       'status': None, 'published': False, 'program_modified': False}

    def save(self):
        c.write(self.state_path, self.state)

    def event(self, stage, **values):
        entry = {'at': now(), 'run_id': self.run_id, 'stage': stage, **values}
        with (self.run_dir / 'events.jsonl').open('a', encoding='utf8') as out:
            out.write(json.dumps(entry, ensure_ascii=False, allow_nan=False) + '\n')

    def finish(self, status, *, update_latest=True, **values):
        if status not in STATUSES:
            raise c.UpdateError('Invalid C-4 state')
        self.result.update(status=status, finished_at=now(), **values)
        c.write(self.run_dir / 'result.json', self.result)
        if update_latest:
            c.write(self.root / 'latest.json', self.result)
        self.event(status, **{k: v for k, v in values.items() if k in ('reason', 'data_version', 'auto_ready', 'error')})
        return self.result

    def resume_publication(self, job):
        if job.get('attempts', 0) >= 3:
            return self.finish('BLOCKED', reason='publication_retry_limit_3; fix the cause and explicitly reset this batch',
                               pending_batch=job['batch_id'])
        path = c.scratch_path(ROOT / job['comparison'])
        if c.digest(path) != job['comparison_sha256']:
            raise Blocked('Pending comparison/package proof changed')
        result = c.read(path)
        guard(result['protected_inputs'])
        ready = [r for r in result['records'] if r['readiness'] == 'AUTO_READY']
        package = result['package']
        baseline = baseline_from_journal(job)
        validate_sources(package, ready, baseline['manifest'])
        if not self.publishing:
            return self.finish('READY', auto_ready=len(ready), data_version=package['data_version'], published=False,
                               package=package, reason='validated; publication not enabled for this invocation')
        if not signer_health():
            raise Blocked('Unattended signing unavailable; existing trust/key required')
        job['attempts'] = job.get('attempts', 0) + 1
        self.save()  # Count a crash/network interruption as an attempt too.
        self.event('publish', batch_id=job['batch_id'], attempt=job['attempts'])
        outcome = publish(self.github, package, ready, baseline, job,
                          lambda updated: (self.state.update(pending=updated), self.save()), source_validator=validate_sources)
        self.state['last_published'] = outcome
        self.state['processed_batches'].append(job['batch_id'])
        self.state['processed_batches'] = self.state['processed_batches'][-256:]
        self.state['pending'] = None
        self.save()
        return self.finish('PUBLISHED', published=True, auto_ready=len(ready), **{k: v for k, v in outcome.items() if k != 'status'})

    def execute(self):
        before = protected()
        with Lock(self.root / 'run.lock'):
            try:
                if self.state_path.is_file():
                    self.state = c.read(self.state_path)
                if self.state['pending'] and self.state['pending'].get('comparison'):
                    self.event('resume_saved_package')
                    outcome = self.resume_publication(self.state['pending'])
                    guard(before)
                    return outcome
                remote = self.github.snapshot()
                self.event('official_baseline', data_version=remote['manifest']['data_version'], head=remote['head'])
                baseline_dir = self.root / 'official' / canonical_hash(remote['manifest'])
                baseline = local_baseline(remote, baseline_dir, self.github)
                self.sources = self.sources or Sources(self.root / 'sources')
                self.sources.seed()
                self.event('detect')
                discovery = self.sources.discover()
                if (not self.state.get('pending') and not discovery['errors'] and
                    getattr(self.sources, 'shared_processed', lambda *_: False)(discovery, baseline)):
                    self.state.update(observed=discovery['fingerprint'], source_stable=discovery['stable'],
                        initial_review_complete=True, validation_adapter_sha256=c.digest(ROOT / 'tools/c4_sources.py'),
                        official_manifest_hash=canonical_hash(remote['manifest']), backlog=[])
                    self.save()
                    guard(before)
                    return self.finish('NO_CHANGE', reason='same_source_and_official_manifest_already_processed_by_cloud',
                        detail_collection_requests=0, data_version=baseline.manifest['data_version'])
                observed = self.state.get('observed')
                adapter_sha = c.digest(ROOT / 'tools/c4_sources.py')
                revision = getattr(self.sources, 'review_revision', None)
                initial = (not self.state['initial_review_complete'] or self.state.get('validation_adapter_sha256') != adapter_sha
                           or self.state.get('shared_review_revision') != revision
                           or self.state.get('official_manifest_hash', canonical_hash(remote['manifest'])) != canonical_hash(remote['manifest']))
                pending = self.state.get('pending')
                if pending:
                    # Freeze the batch selected before interruption. New changes wait.
                    targets = pending['targets']
                    batch_id = pending['batch_id']
                else:
                    if observed == discovery['fingerprint'] and not self.state['backlog'] and not initial:
                        guard(before)
                        return self.finish('BLOCKED' if discovery['errors'] else 'NO_CHANGE',
                            reason='source_detection_incomplete' if discovery['errors'] else 'source_fingerprints_unchanged',
                            detail_collection_requests=0, warnings=discovery['errors'], data_version=baseline.manifest['data_version'])
                    previous = self.state.get('source_stable') or self.sources.prior_stable()
                    old_rows = previous.get('rows', {})
                    changed = [h for h, row in discovery['rows'].items() if old_rows.get(str(h)) != fingerprint(row)] if previous else []
                    queued = {r['heroId']: r for r in self.state['backlog']}
                    for hid in changed:
                        queued[hid] = discovery['rows'][hid]
                    # An article can change skills without changing index metadata.
                    if not initial and previous.get('articles') != discovery['stable']['articles']:
                        for document in discovery['documents']:
                            lines = set(document['lines'])
                            for hid, row in discovery['rows'].items():
                                if row['champion'] in lines:
                                    queued[hid] = row
                    targets = [queued[k] for k in sorted(queued)][:8]
                    self.state['backlog'] = [queued[k] for k in sorted(queued)][8:]
                    # First review uses completed C-1 evidence for the requested 52,
                    # not another all-champion form/skill collection.
                    if initial:
                        self.state['backlog'] = list(queued.values())
                        targets = []
                    batch_id = fingerprint({'source': discovery['fingerprint'], 'targets': targets, 'initial': initial,
                                            'baseline': canonical_hash(remote['manifest']), 'adapter': adapter_sha,
                                            'shared_revision': revision})
                    if batch_id in self.state['processed_batches']:
                        guard(before)
                        return self.finish('NO_CHANGE', reason='already_processed_batch', detail_collection_requests=0)
                    self.state['pending'] = {'batch_id': batch_id, 'targets': targets, 'initial': initial, 'phase': 'collection',
                                             'baseline_manifest_hash': canonical_hash(remote['manifest']), 'attempts': 0,
                                             'source_fingerprint': discovery['fingerprint'], 'source_stable': discovery['stable']}
                    self.save()
                pending = self.state['pending']
                if pending['baseline_manifest_hash'] != canonical_hash(remote['manifest']):
                    raise Blocked('Official baseline moved during pending collection')
                if pending.get('collection_attempts', 0) >= 3:
                    raise Blocked('Incremental collection retry limit 3; inspect source access before resetting batch')
                pending['collection_attempts'] = pending.get('collection_attempts', 0) + 1
                self.save()
                detail_start = len(self.sources.requests)
                if pending['initial']:
                    records = self.sources.initial_candidates()
                    records = self.sources.refresh_metadata(records, discovery, baseline)
                else:
                    records = self.sources.collect(baseline, targets, batch_id) if targets else {}
                self.event('compare', candidate_records=len(records), target_heroes=len(targets))
                rows = ValidatedComparison(baseline, records, self.sources.root, discovery['documents']).run()
                original_new = new_champion_review(baseline, records) if pending['initial'] else []
                work = self.run_dir / 'c3'
                package = c.prepare(baseline, rows, work)
                bundle = self.run_dir / 'source_bundle.json'
                c.write(bundle, {'records': records, 'documents': discovery['documents'],
                                 'source_root': str(self.sources.root.relative_to(ROOT)),
                                 'source_fingerprint': pending.get('source_fingerprint', discovery['fingerprint']),
                                 'coverage_hero_ids': [r['heroId'] for r in targets] if not pending['initial'] else []})
                if package['status'] == 'LOCAL_VALIDATED':
                    package.update(source_bundle=str(bundle.relative_to(ROOT)), source_bundle_sha256=c.digest(bundle),
                        baseline_manifest=str(baseline.manifest_path.relative_to(ROOT)),
                        baseline_source=str(baseline.source.relative_to(ROOT)), baseline_base=str(baseline.base.relative_to(ROOT)))
                count = Counter(r['readiness'] for r in rows)
                report = {'format_version': 1, 'run_id': self.run_id, 'batch_id': batch_id, 'records': rows,
                    'package': package, 'totals': {'reviewed_records': len(rows), 'AUTO_READY': count['AUTO_READY'],
                        'readiness': dict(count), 'classifications': dict(Counter(r['classification'] for r in rows))},
                    'new_champions': original_new, 'source_warnings': discovery['errors'], 'protected_inputs': before,
                    'historical_already_applied': c.regressions(baseline) if baseline.manifest['data_version'] == '1.0.1' else
                        {'scope': '1.0.1 regression already established; current generation is newer'}}
                comparison_path = self.run_dir / 'comparison.json'
                guard(before)
                c.write(comparison_path, report)
                c.write(self.root / 'last_comparison.json', report)
                self.result.update(auto_ready=count['AUTO_READY'], reviewed_records=len(rows),
                    data_version=baseline.manifest['data_version'], source_checks=len(self.sources.requests),
                    detail_collection_requests=len(self.sources.requests) - detail_start,
                    comparison=str(comparison_path.relative_to(ROOT)), protected_unchanged=True, warnings=discovery['errors'])
                # A new upstream change arriving during a resumed batch must remain
                # detectable on the next tick, rather than being marked processed.
                self.state['observed'] = pending.get('source_fingerprint', discovery['fingerprint'])
                self.state['source_stable'] = pending.get('source_stable', discovery['stable'])
                self.state['initial_review_complete'] = True
                self.state['validation_adapter_sha256'] = adapter_sha
                self.state['shared_review_revision'] = revision
                self.state['official_manifest_hash'] = canonical_hash(remote['manifest'])
                if package['status'] == 'NO_PACKAGE':
                    self.state['processed_batches'].append(batch_id)
                    self.state['processed_batches'] = self.state['processed_batches'][-256:]
                    self.state['pending'] = None
                    self.save()
                    return self.finish('NO_UPDATE', reason='AUTO_READY_0_no_package_no_version_increment',
                                       backlog_heroes=len(self.state['backlog']))
                prior_path = self.run_dir / 'baseline_approval.json'
                prior_path.write_bytes(remote['approval_raw'])
                pending.update(phase='ready', comparison=str(comparison_path.relative_to(ROOT)),
                    comparison_sha256=c.digest(comparison_path), baseline_manifest=str(baseline.manifest_path.relative_to(ROOT)),
                    baseline_approval=str(prior_path.relative_to(ROOT)))
                self.save()
                guard(before)
                return self.resume_publication(pending)
            except (Blocked, SourceSkip) as exc:
                guard(before)
                self.save()
                return self.finish('BLOCKED', reason=str(exc), pending_batch=(self.state.get('pending') or {}).get('batch_id'))
            except Exception as exc:
                guard(before)
                self.save()
                return self.finish('FAILED', error=type(exc).__name__ + ': ' + str(exc))
            finally:
                if self.sources:
                    self.sources.close()


def main():
    import argparse
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--publish', action='store_true', help='Enable existing-key data-only publication after every gate')
    p.add_argument('--status', action='store_true')
    p.add_argument('--root', type=Path, default=HOME)
    p.add_argument('--reset-blocked', help='Explicitly reset retry count for this exact pending batch ID')
    args = p.parse_args()
    root = c.scratch_path(args.root)
    if args.status:
        state = c.read(root / 'state.json') if (root / 'state.json').is_file() else {}
        pending = state.get('pending') or {}
        result = {'latest': c.read(root / 'latest.json') if (root / 'latest.json').is_file() else None,
                  'last_published': state.get('last_published'), 'backlog_heroes': len(state.get('backlog', [])),
                  'pending': {k: pending[k] for k in ('batch_id', 'phase', 'attempts', 'collection_attempts') if k in pending},
                  'initial_review_complete': state.get('initial_review_complete', False), 'signer_ready': signer_health()}
    elif args.reset_blocked:
        with Lock(root / 'run.lock'):
            state = c.read(root / 'state.json')
            if not state.get('pending') or state['pending']['batch_id'] != args.reset_blocked:
                raise Blocked('Pending batch ID does not match reset request')
            state['pending'].update(attempts=0, collection_attempts=0)
            c.write(root / 'state.json', state)
        result = {'status': 'READY_TO_RETRY', 'batch_id': args.reset_blocked}
    else:
        pipeline = Pipeline(root, publishing=args.publish)
        try:
            result = pipeline.execute()
        except Busy as exc:
            # Lock contention never changes the running owner's main state.
            result = pipeline.finish('BLOCKED', update_latest=False, reason=str(exc))
        except Exception as exc:
            result = pipeline.finish('FAILED', error=type(exc).__name__ + ': ' + str(exc))
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 1 if result.get('status') in ('FAILED', 'BLOCKED') else 0


if __name__ == '__main__':
    raise SystemExit(main())
