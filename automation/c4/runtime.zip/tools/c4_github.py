"""C-4 data-only publication: immutable bytes first, signed activation last.

Uses the same Git object/ref transaction as B. Never creates Releases or uploads
program binaries, and never prints or exports a signing key or gh credential.
"""
from __future__ import annotations

import base64
import copy
import hashlib
import io
import json
import os
from pathlib import Path
import subprocess
import shutil
import sys

from tools import c_data_pipeline as c
from application_update import canonical_hash, verify_approval
from game_data_online import GitHubTransport, validate_online_manifest

REPO = 'dlckdtnr1212-lang/RAID-Champion-DB'
API = 'repos/' + REPO
RAW = 'https://raw.githubusercontent.com/' + REPO + '/main/'
GH = (Path(shutil.which('gh') or '/usr/bin/gh') if os.environ.get('GITHUB_ACTIONS') == 'true'
      else c.ROOT / 'scratch/auto_update_b/remote_review/github_cli/bin/gh.exe')
KEY = c.ROOT / 'scratch/auto_update_b/signing/approval.key'
TRUST = c.ROOT / 'release_tools/update_trust.json'
MANIFEST = 'data-updates/beta/manifest.json'
APPROVAL = 'program-updates/beta/approval.json'


class Blocked(c.UpdateError):
    pass


def git_sha(data):
    return hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()


def change_identity(ready):
    """Stable cross-host identity independent of a local run or package version."""
    facts = [{'source': r['source'], 'champion_id': r['champion_id'], 'game_hero_id': r['game_hero_id'],
              'skill_id': r.get('skill_id'), 'patch': r.get('source_proof', {}).get('game_version'),
              'content_sha256': r.get('raw_file_sha256'), 'operations': r['operations']}
             for r in sorted(ready, key=lambda r: r['record_id'])]
    return canonical_hash(facts)


class GitHub:
    def __init__(self, work, gh=GH, transport=None):
        self.work = c.scratch_path(work)
        self.work.mkdir(parents=True, exist_ok=True)
        self.gh = Path(gh).resolve() if os.environ.get('GITHUB_ACTIONS') == 'true' else c.project_path(gh)
        self.transport = transport or GitHubTransport()

    def api(self, path, method='GET', body=None):
        if not path.startswith(API + '/') and path != API:
            raise Blocked('C-4 GitHub repository boundary rejected')
        args = [str(self.gh), 'api', path, '--method', method]
        temp = None
        if body is not None:
            import uuid
            temp = self.work / ('request_' + uuid.uuid4().hex + '.json')
            c.write(temp, body)
            args += ['--input', str(temp)]
        try:
            result = subprocess.run(args, cwd=c.ROOT, capture_output=True, timeout=90,
                creationflags=subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0)
        finally:
            if temp:
                temp.unlink(missing_ok=True)
        if result.returncode:
            raise Blocked('GitHub authentication/permission/API operation failed: ' + method + ' ' + path.split('?')[0])
        return c.json_bytes(result.stdout) if result.stdout.strip() else None

    def blob(self, sha):
        item = self.api(API + '/git/blobs/' + sha)
        data = base64.b64decode(item['content'])
        if git_sha(data) != sha:
            raise Blocked('GitHub blob integrity mismatch')
        return data

    def snapshot(self):
        head = self.api(API + '/git/ref/heads/main')['object']['sha']
        commit = self.api(API + '/git/commits/' + head)
        tree = self.api(API + '/git/trees/' + commit['tree']['sha'] + '?recursive=1')
        if tree.get('truncated'):
            raise Blocked('Incomplete official Git tree')
        files = {f['path']: f for f in tree['tree'] if f['type'] == 'blob'}
        manifest_raw = self.blob(files[MANIFEST]['sha'])
        approval_raw = self.blob(files[APPROVAL]['sha'])
        manifest, approval = c.json_bytes(manifest_raw), c.json_bytes(approval_raw)
        validate_online_manifest(manifest, c.APP, 'beta')
        payload = verify_approval(approval, c.read(TRUST), 'beta')
        if payload.get('local_proof_only') or payload['data_manifest_canonical_sha256'] != canonical_hash(manifest):
            raise Blocked('Official manifest is not bound by current trusted signature')
        return {'head': head, 'tree': commit['tree']['sha'], 'files': files, 'manifest': manifest,
                'approval': approval, 'manifest_raw': manifest_raw, 'approval_raw': approval_raw}

    def anonymous(self, path, *, limit):
        stream = io.BytesIO()
        # No gh/token transport. A commit-specific URL avoids main/raw cache races.
        self.transport.fetch(path, stream, limit, timeout=90)
        return stream.getvalue()

    def commit_files(self, before, files, message):
        entries = []
        for name, data in sorted(files.items()):
            sha = git_sha(data)
            if before['files'].get(name, {}).get('sha') == sha:
                continue
            item = self.api(API + '/git/blobs', 'POST', {'encoding': 'base64', 'content': base64.b64encode(data).decode()})
            if item['sha'] != sha:
                raise Blocked('Uploaded Git blob SHA mismatch')
            entries.append({'path': name, 'mode': '100644', 'type': 'blob', 'sha': sha})
        if not entries:
            return before['head']
        tree = self.api(API + '/git/trees', 'POST', {'base_tree': before['tree'], 'tree': entries})
        commit = self.api(API + '/git/commits', 'POST', {'message': message, 'tree': tree['sha'], 'parents': [before['head']]})
        # Non-forced compare against the parent. Concurrent changes reject this ref update.
        self.api(API + '/git/refs/heads/main', 'PATCH', {'sha': commit['sha'], 'force': False})
        return commit['sha']


def local_baseline(remote, work, github):
    work = c.scratch_path(work)
    work.mkdir(parents=True, exist_ok=True)
    manifest_path = work / 'manifest.json'
    manifest_path.write_bytes(remote['manifest_raw'])
    source = work / 'source'
    for item in remote['manifest']['files']:
        target = c.confined(source, item['path'])
        if target.is_file() and c.digest(target) == item['sha256']:
            continue
        historical = c.confined(c.SOURCE, item['path'])
        data = historical.read_bytes() if historical.is_file() and c.digest(historical) == item['sha256'] else (
            github.anonymous(item['url'], limit=item['size']))
        if len(data) != item['size'] or hashlib.sha256(data).hexdigest() != item['sha256']:
            raise Blocked('Official overlay size/SHA mismatch')
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
    return c.Baseline(manifest_path, source, c.ROOT, expected_version=None)


def sign_data(manifest_path, preflight, previous, output, key=KEY, trust=TRUST):
    """Call B's existing approve-data command, then preserve the same program feed.

    Compatibility bounds may extend only to the tested same-ABI data version;
    no executable/feed/package URL, hash or target program version is changed.
    """
    from application_update import canonical
    from cryptography.hazmat.primitives import serialization
    if not c.project_path(key).is_file():
        raise Blocked('Existing approval signing key unavailable')
    current_payload = verify_approval(previous, c.read(trust), 'beta')
    doc = c.read(manifest_path)
    if doc.get('test_data'):
        raise Blocked('Test data cannot obtain an official approval')
    if doc['compatible_app_versions'] != {'min': c.APP, 'max': c.APP}:
        raise Blocked('Untested program/data ABI')
    output = c.scratch_path(output)
    prior_path, check_path = output.parent / 'previous_approval.json', output.parent / 'preflight.json'
    c.write(prior_path, previous)
    c.write(check_path, preflight)
    command = [sys.executable, str(c.ROOT / 'tools/program_update_release.py'), 'approve-data',
               '--manifest', str(manifest_path), '--preflight', str(check_path), '--previous-approval', str(prior_path),
               '--output', str(output), '--key', str(key), '--channel', 'beta', '--sequence', str(current_payload['sequence'] + 1)]
    completed = subprocess.run(command, cwd=c.ROOT, capture_output=True, timeout=90,
        creationflags=subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0)
    if completed.returncode:
        raise Blocked('Existing B approve-data signing command failed')
    envelope = c.read(output)
    payload = envelope['payload']
    program = payload.get('program')
    if program and c.version(doc['data_version']) > c.version(program['supported_data_versions']['max']):
        # The exact existing program/data ABI has passed B preflight + actual apply.
        program['supported_data_versions']['max'] = doc['data_version']
        signer = serialization.load_pem_private_key(Path(key).read_bytes(), password=None)
        envelope['signature'] = base64.b64encode(signer.sign(canonical(payload))).decode()
        c.write(output, envelope)
    verify_approval(envelope, c.read(trust), 'beta')
    compare = copy.deepcopy(payload.get('program'))
    if compare:
        compare['supported_data_versions'] = current_payload['program']['supported_data_versions']
    if compare != current_payload.get('program'):
        raise Blocked('Data-only approval changed program identity/feed')
    return envelope


def package_check(package, ready, baseline_manifest, *, allow_test=False):
    if package.get('status') != 'LOCAL_VALIDATED' or not ready or package['actual_changed_records'] != len(ready):
        raise Blocked('No validated data-only package')
    if any(c.readiness(row) != 'AUTO_READY' or not row.get('source_proof') for row in ready):
        raise Blocked('AUTO_READY lacks complete gates/source proof')
    manifest_path = c.scratch_path(c.ROOT / package['manifest'])
    if c.digest(manifest_path) != package['manifest_sha256']:
        raise Blocked('Package manifest SHA mismatch')
    doc = c.read(manifest_path)
    validate_online_manifest(doc, c.APP, 'beta')
    if (doc.get('test_data') or package.get('test_data')) and not allow_test:
        raise Blocked('Synthetic packages are never published')
    before = c.version(baseline_manifest['data_version'])
    expected = f'{before[0]}.{before[1]}.{before[2]+1}'
    if doc['data_version'] != expected or package['data_version'] != expected:
        raise Blocked('Nonsequential or duplicate data version')
    proof_path = c.scratch_path(c.ROOT / package['validation_file'])
    if c.digest(proof_path) != package['validation_sha256']:
        raise Blocked('Apply/preflight proof SHA mismatch')
    proof = c.read(proof_path)
    if not proof['preflight'].get('preflight_pass') or not all(proof['isolated_update'].get(k) for k in (
        'apply', 'duplicate_noop', 'interrupted_commit_preserved', 'damaged_generation_fallback',
        'pinned_reader_preserved', 'personal_sentinels_preserved')):
        raise Blocked('Required existing-engine apply/recovery checks failed')
    inventory = {}
    root = manifest_path.parents[1]
    for item in doc['packages']:
        inventory['data-updates/' + item['path']] = item
    for item in doc['files']:
        inventory[f"data-updates/files/{doc['data_version']}/{item['path']}"] = item
    payloads = {}
    for name, item in inventory.items():
        source = c.confined(root, name.removeprefix('data-updates/'))
        if source.stat().st_size != item['size'] or c.digest(source) != item['sha256']:
            raise Blocked('Payload SHA/size mismatch')
        payloads[name] = source.read_bytes()
    actual = {p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()}
    expected_paths = {n.removeprefix('data-updates/') for n in payloads} | {'beta/manifest.json'}
    if actual != expected_paths:
        raise Blocked('Unexpected files in data publication')
    return manifest_path, doc, payloads, proof['preflight']


def publish(github, package, ready, baseline, journal, save, *, signer=sign_data, source_validator=None, allow_test=False):
    """Idempotent two-phase publication; the active signed pair is one Git commit."""
    if getattr(github, 'network_enabled', True) and not (
        os.environ.get('GITHUB_ACTIONS') == 'true' and os.environ.get('GITHUB_REPOSITORY') == REPO
        and os.environ.get('C4_ENABLE_PUBLISH') == 'true'):
        raise Blocked('Official data publication belongs exclusively to the enabled GitHub Actions job')
    if allow_test and (isinstance(github, GitHub) or getattr(github, 'network_enabled', True)):
        raise Blocked('Test publication may only use an isolated in-memory repository')
    if source_validator is None:
        from tools.c4_auto_update import validate_sources
        source_validator = validate_sources
    source_validator(package, ready, baseline['manifest'])
    manifest_path, doc, payloads, preflight = package_check(package, ready, baseline['manifest'], allow_test=allow_test)
    current = github.snapshot()
    change_hash = change_identity(ready)
    ledger_name = 'automation/c4/processed/' + change_hash + '.json'
    if ledger_name in current['files'] and canonical_hash(current['manifest']) != canonical_hash(doc):
        raise Blocked('Same patch/IDs/before-after/content already officially processed')
    if canonical_hash(current['manifest']) == canonical_hash(doc):
        if current['approval']['payload']['data_manifest_canonical_sha256'] != canonical_hash(doc):
            raise Blocked('Previously published manifest/approval mismatch')
        journal.update(phase='activated', activation_commit=current['head'])
    else:
        if canonical_hash(current['manifest']) != canonical_hash(baseline['manifest']) or (
            current['approval'] != baseline['approval']):
            raise Blocked('Official data/approval changed since comparison; rebase required')
        for name, data in payloads.items():
            prior = current['files'].get(name)
            if prior and prior['sha'] != git_sha(data):
                raise Blocked('Immutable published name collision')
        envelope_path = manifest_path.parents[2] / 'signed_data_approval.json'
        if envelope_path.is_file():
            envelope = c.read(envelope_path)
            verify_approval(envelope, c.read(TRUST), 'beta', allow_local_proof=allow_test)
            if envelope['payload']['data_manifest_canonical_sha256'] != canonical_hash(doc) or (
                envelope['payload']['sequence'] != current['approval']['payload']['sequence'] + 1):
                raise Blocked('Stale signed data candidate')
        else:
            envelope = signer(manifest_path, preflight, current['approval'], envelope_path)
        verify_approval(envelope, c.read(TRUST), 'beta', allow_local_proof=allow_test)
        payload_commit = github.commit_files(current, payloads, 'C4 data ' + doc['data_version'] + ': immutable payloads')
        journal.update(phase='payloads', payload_commit=payload_commit)
        save(journal)
        for name, expected in payloads.items():
            url = RAW.replace('/main/', '/' + payload_commit + '/') + name
            actual = github.anonymous(url, limit=len(expected))
            if actual != expected:
                raise Blocked('Uploaded payload anonymous byte verification failed')
        latest = github.snapshot()
        if latest['manifest_raw'] != baseline['manifest_raw'] or latest['approval_raw'] != baseline['approval_raw']:
            raise Blocked('Active metadata moved before activation')
        pair = {MANIFEST: manifest_path.read_bytes(), APPROVAL: c.encoded(envelope),
                ledger_name: c.encoded({'format_version': 1, 'change_sha256': change_hash,
                    'data_version': doc['data_version'], 'manifest_sha256': canonical_hash(doc)})}
        activation = github.commit_files(latest, pair, 'C4 data ' + doc['data_version'] + ': activate verified signed manifest')
        journal.update(phase='activated', activation_commit=activation)
        save(journal)
    # Resume after a lost response/termination without re-signing or bumping a version.
    active = github.snapshot()
    if canonical_hash(active['manifest']) != canonical_hash(doc):
        raise Blocked('Official activated version not visible')
    for name, expected in payloads.items():
        actual = github.anonymous(RAW.replace('/main/', '/' + active['head'] + '/') + name, limit=len(expected))
        if actual != expected:
            raise Blocked('Final public payload integrity mismatch')
    for name, expected in ((MANIFEST, active['manifest_raw']), (APPROVAL, active['approval_raw'])):
        actual = github.anonymous(RAW.replace('/main/', '/' + active['head'] + '/') + name, limit=2 * 1024 * 1024)
        if actual != expected:
            raise Blocked('Final public signed metadata unavailable')
    journal.update(phase='published', data_version=doc['data_version'])
    save(journal)
    return {'status': 'PUBLISHED', 'data_version': doc['data_version'], 'commit': active['head'],
            'signature_valid': True, 'anonymous_payloads_verified': True,
            'program_binaries_changed': False, 'release_created': False}
