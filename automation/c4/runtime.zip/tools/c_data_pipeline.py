"""C-2/C-3: offline C-1 comparison and locally validated B-format packages.

No collector import, network client, publisher, scheduler or application mutation.
Unknown source semantics stay in the queue. See docs/C_DATA_PIPELINE.md.
"""
from __future__ import annotations

import argparse
import copy
from collections import Counter, defaultdict
import hashlib
import json
import os
from pathlib import Path
import re
import sys
import tempfile
from urllib.parse import urlsplit

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from game_data_update import (DataSnapshot, DataUpdateManager, UpdateError, confined,
                              digest, json_bytes, validate_payload, version)
from tools.data_update import build_online_package
from tools.data_update_release import preflight

C1 = ROOT / 'scratch/c_auto_collection'
OFFICIAL = ROOT / 'scratch/auto_update_b/official_beta30_7/before/data-updates/beta/manifest.json'
SOURCE = ROOT / 'scratch/data_update_dev5/source'
REVIEW = ROOT / 'scratch/data_update_dev5/patch1190_review.json'
COLLECTED = 'data/champions_collected.json'
SKILLS = 'data/bulk_stage11/champion_skills_ko_game.json'
APP = '1.0.0-beta.30'  # Existing data ABI, separate from the beta.30.7 PE version.
CLASSES = ('NEW', 'CHANGED', 'ALREADY_APPLIED', 'UNCHANGED', 'UNMATCHED', 'UNCERTAIN', 'CONFLICT')
STATES = ('AUTO_READY', 'REVIEW_REQUIRED', 'REFERENCE_ONLY', 'REJECTED')
GATES = ('source_evidence', 'exact_ids', 'value_validation', 'schema_validation',
         'no_conflict', 'compatibility', 'apply_recovery')
OFFICIAL_HOSTS = frozenset(('forum.plarium.com', 'raid-support.plarium.com'))
TRUSTED_HOSTS = OFFICIAL_HOSTS | {'hellhades.com'}


def read(path):
    return json_bytes(Path(path).read_bytes())


def encoded(doc):
    return json.dumps(doc, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False).encode('utf8')


def write(path, doc):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + '.tmp')
    tmp.write_bytes(encoded(doc))
    os.replace(tmp, path)


def project_path(path):
    path = Path(path).resolve()
    if not path.is_relative_to(ROOT):
        raise UpdateError('Path outside this project')
    return path


def scratch_path(path):
    path = project_path(path)
    if not path.is_relative_to(ROOT / 'scratch'):
        raise UpdateError('C output must be in project scratch')
    return path


def at(doc, pointer):
    """Strict JSON pointer; no fallback, text search or fuzzy matching."""
    if pointer == '':
        return doc
    if not isinstance(pointer, str) or not pointer.startswith('/'):
        raise UpdateError('Invalid JSON pointer')
    for key in pointer[1:].split('/'):
        key = key.replace('~1', '/').replace('~0', '~')
        doc = doc[int(key)] if isinstance(doc, list) else doc[key]
    return doc


def replace(doc, pointer, value, before, existed=True):
    parent, key = pointer.rsplit('/', 1)
    obj = at(doc, parent)
    key = int(key) if isinstance(obj, list) else key.replace('~1', '/').replace('~0', '~')
    present = key < len(obj) if isinstance(obj, list) else key in obj
    if present != existed or (present and obj[key] != before):
        raise UpdateError('Baseline value changed before staging')
    obj[key] = copy.deepcopy(value)


def classify(before, after, *, exists=True, matched=True, uncertain=False, conflict=False, applied=False):
    if conflict:
        return 'CONFLICT'
    if not matched:
        return 'UNMATCHED'
    if applied and before == after:
        return 'ALREADY_APPLIED'
    if uncertain:
        return 'UNCERTAIN'
    if not exists:
        return 'NEW'
    return 'UNCHANGED' if before == after else 'CHANGED'


def readiness(row):
    if row.get('invalid') or row['classification'] == 'CONFLICT':
        return 'REJECTED'
    if row['classification'] in ('ALREADY_APPLIED', 'UNCHANGED') or row.get('reference_only'):
        return 'REFERENCE_ONLY'
    if row['classification'] in ('NEW', 'CHANGED') and all(row['gates'].get(g) is True for g in GATES):
        return 'AUTO_READY'
    return 'REVIEW_REQUIRED'


def propagate(rows):
    """Conflicting target or shared dependency holds only the connected bundle."""
    grouped = defaultdict(list)
    for row in rows:
        for group in row.get('dependencies', []):
            grouped[group].append(row)
    blocked = {g for g, members in grouped.items() if any(
        m.get('invalid') or m['classification'] == 'CONFLICT' for m in members)}
    # Transitive dependency propagation, including records in multiple groups.
    while True:
        more = {g for row in rows if blocked.intersection(row.get('dependencies', []))
                for g in row.get('dependencies', [])}
        if more <= blocked:
            break
        blocked |= more
    for row in rows:
        if blocked.intersection(row.get('dependencies', [])):
            row['gates']['no_conflict'] = False
            if 'shared_dependency_conflict' not in row['reasons']:
                row['reasons'].append('shared_dependency_conflict')
        row['readiness'] = readiness(row)


class Baseline:
    """Hash-pinned official overlay over immutable application baseline. Read-only."""
    def __init__(self, manifest=OFFICIAL, source=SOURCE, base=ROOT, expected_version='1.0.1'):
        self.manifest_path, self.source, self.base = map(project_path, (manifest, source, base))
        self.manifest = read(self.manifest_path)
        from game_data_online import validate_online_manifest
        validate_online_manifest(self.manifest, APP, 'beta')
        if expected_version and self.manifest['data_version'] != expected_version:
            raise UpdateError('Unexpected C-2 baseline data version')
        self.overlay = {f['path']: f for f in self.manifest['files']}
        for name, item in self.overlay.items():
            path = confined(self.source, name)
            if path.stat().st_size != item['size'] or digest(path) != item['sha256']:
                raise UpdateError('Official baseline SHA/size mismatch: ' + name)
        self.collected = read(self.resolve(COLLECTED))
        self.game = read(self.resolve(SKILLS))
        self.targets = {t['id']: t for t in read(self.resolve('nightly_collection/manifest.json'))['targets']}
        self.champions = {c['champion_id']: c for c in self.game['champions']}
        self.artifact_sets = read(self.resolve('data/bulk_stage11/artifact_sets_ui.json')).get('entries', {}) if (
            self.resolve('data/bulk_stage11/artifact_sets_ui.json').is_file()) else {}
        self.hero = defaultdict(set)
        self.links = set()
        for c in self.game['champions']:
            for v in c['game_variants']:
                self.hero[str(v['game_hero_id'])].add(c['champion_id'])
                for f in v['forms']:
                    for s in f['skills']:
                        self.links.add((c['champion_id'], str(v['game_hero_id']), str(f['form_index']), str(s['skill_id'])))

    def resolve(self, name):
        return confined(self.source if name in self.overlay else self.base, name, allow_links=True)

    def collected_row(self, cid):
        t = self.targets.get(cid, {})
        i = t.get('local_index')
        if type(i) is int and 0 <= i < len(self.collected['champions']):
            row = self.collected['champions'][i]
            # The stable ID/local_index is the join; this is a corruption guard.
            if row['name_en'] == t['name_en']:
                return i, row
        return None, None

    def seed(self, store):
        manager = DataUpdateManager(self.base, store, APP)
        result = manager.apply(self.manifest, package_dir=self.source)
        if not result.get('success') or not result.get('applied'):
            raise UpdateError('Cannot seed isolated official 1.0.1: ' + str(result))
        return manager


def normalize_champion(field, value):
    # Explicit source enum translations, never a champion-name identity join.
    aliases = {'role': {'atk': 'Attack', 'def': 'Defense', 'hp': 'HP', 'supp': 'Support'},
               'faction': {'undead-hordes': 'Undead Hordes', 'lizardmen': 'Lizardmen',
                           'banner-lords': 'Banner Lords', 'high-elves': 'High Elves',
                           'dark-elves': 'Dark Elves', 'sacred-order': 'Sacred Order',
                           'knights-revenant': 'Knights Revenant', 'ogryn-tribes': 'Ogryn Tribes',
                           'sylvan-watchers': 'Sylvan Watchers'}}
    if not isinstance(value, str):
        return value
    if field == 'name_en':
        return value
    low = value.lower()
    if low in aliases.get(field, {}):
        return aliases[field][low]
    return value.title()


def regressions(baseline, review=REVIEW):
    """Separate historical claims; never relabel a stale C-1 value as current."""
    result = []
    for claim in read(review)['applied']:
        if claim['slot'] != 'A3':
            continue
        cid, sid, hid = claim['champion_id'], claim['skill_id'], claim['game_hero_id']
        _, champion = baseline.collected_row(cid)
        skill = baseline.game['skills'][str(sid)]
        rows = [s for s in champion['skills'] if s['slot'] == claim['slot']]
        correct = len(rows) == 1 and all(rows[0].get(k) == v for k, v in claim['after'].items())
        correct &= skill['description_ko'] == claim['after']['description']
        update = skill.get('data_update', {})
        correct &= update.get('skill_id') == sid and update.get('game_hero_id') == hid
        correct &= update.get('verified_cooldown_unbooked') == claim['after']['cooldown_unbooked']
        correct &= any(t[:2] == (cid, str(hid)) and t[3] == str(sid) for t in baseline.links)
        result.append({'champion_id': cid, 'name_en': claim['name_en'], 'skill_id': sid,
                       'game_hero_id': hid, 'slot': 'A3', 'classification': 'ALREADY_APPLIED' if correct else 'CONFLICT',
                       'source': claim['source_url'], 'before': claim['before'], 'operating_value': claim['after'],
                       'verified_against_official_1_0_1': bool(correct), 'include_in_package': False})
    if len(result) != 3 or not all(r['verified_against_official_1_0_1'] for r in result):
        raise UpdateError('Known 1.0.1 regression mismatch; stop without packaging')
    return result


class Comparison:
    def __init__(self, baseline, records, c1=C1, assertions=None):
        self.baseline, self.records, self.c1 = baseline, records, project_path(c1)
        self.assertions = assertions or {}
        self.raw_cache = {}

    def raw(self, record):
        path = confined(self.c1, record['raw_file'])
        key = (str(path), record['raw_file_sha256'])
        if key not in self.raw_cache:
            if digest(path) != record['raw_file_sha256']:
                raise UpdateError('C-1 evidence SHA mismatch')
            self.raw_cache[key] = path.read_bytes()
        return self.raw_cache[key]

    def evidence(self, row, source_field, value):
        """Future C-4 extraction receipts reference existing C-1 records, not booleans.

        Require a cached official structured assertion, exact IDs/field/value and
        explicit equal game versions in the raw content. An external assertion
        alone cannot promote C-1's source_candidate_requires_review to verified.
        An HTML paragraph, collector timestamp or asserted verified=True cannot pass.
        """
        hosts, versions = set(), set()
        receipts = self.assertions.get(row['record_id'], [])
        for receipt in receipts:
            record = self.records[receipt['evidence_record_id']]
            host = urlsplit(record['source']).hostname
            if host not in TRUSTED_HOSTS or urlsplit(record['source']).scheme != 'https':
                raise UpdateError('Untrusted evidence source')
            raw = json_bytes(self.raw(record))
            obj = at(raw, receipt['object_pointer'])
            # All identity/value pointers stay within one source object.
            hero = at(obj, receipt['hero_pointer'])
            if str(hero) != str(row['game_hero_id']) or int(hero) <= 0:
                raise UpdateError('Evidence hero ID mismatch')
            if row.get('skill_id') is not None and str(at(obj, receipt['skill_pointer'])) != str(row['skill_id']):
                raise UpdateError('Evidence skill ID mismatch')
            if at(obj, receipt['field_pointer']) != source_field:
                raise UpdateError('Evidence field mismatch')
            if at(obj, receipt['value_pointer']) != value:
                raise UpdateError('Evidence value mismatch')
            game_version = at(raw, receipt['version_pointer'])
            if not isinstance(game_version, str) or not re.fullmatch(r'\d+\.\d+\.\d+', game_version):
                raise UpdateError('Source has no explicit game version')
            if record.get('game_version') != game_version:
                raise UpdateError('C-1/source version mismatch')
            versions.add(game_version)
            hosts.add(host)
        if not hosts & OFFICIAL_HOSTS or len(versions) != 1:
            return False
        baseline_versions = [self.baseline.game.get('game_data_version')]
        champion_skills = {t[3] for t in self.baseline.links if t[0] == row['champion_id']}
        baseline_versions += [v for v, overlay in self.baseline.game.get('patch_overlays', {}).items()
                              if champion_skills.intersection(map(str, overlay.get('skill_ids', [])))]
        known = [version(v) for v in baseline_versions if isinstance(v, str) and re.fullmatch(r'\d+\.\d+\.\d+', v)]
        return not known or version(next(iter(versions))) >= max(known)

    def row(self, rid, r):
        cid, hid, sid = r.get('champion_id'), r.get('game_hero_id'), r.get('skill_id')
        row = {'record_id': rid, 'kind': r['kind'], 'champion_id': cid, 'game_hero_id': hid,
               'skill_id': sid, 'source': r['source'], 'source_game_version': r.get('game_version'),
               'c1_classification': r['classification'], 'raw_file': r.get('raw_file'),
               'raw_file_sha256': r.get('raw_file_sha256'), 'collected_old_value': r.get('old_value'),
               'new_value': r['new_value'], 'operating_value': None, 'comparisons': [], 'operations': [],
               'gates': dict.fromkeys(GATES, False), 'reasons': [], 'dependencies': []}
        kind = r['kind']
        matched = (type(hid) is int and hid > 0 and cid in self.baseline.champions and
                   self.baseline.hero.get(str(hid)) == {cid})
        identity = r.get('identity', [])
        if kind in ('champion_field', 'skill'):
            matched &= isinstance(identity, list) and bool(identity) and str(identity[0]) == str(hid)
        if kind == 'skill':
            matched &= len(identity) == 3 and str(identity[1]) == str(sid) and str(identity[2]) == str(r.get('form'))
        if kind == 'champion_unlinked':
            row.update(classification='UNMATCHED', reference_only=False)
            row['reasons'].append('external_id_or_hero_0_is_not_a_game_identity')
        elif kind == 'champion_field':
            field = r['identity'][1]
            i, champion = self.baseline.collected_row(cid)
            if not matched or champion is None:
                row['classification'] = 'NEW' if type(hid) is int and hid > 0 and not cid and str(hid) not in self.baseline.hero else 'UNMATCHED'
                row['reasons'].append('new_source_hero_needs_stable_champion_id_and_complete_schema_bundle')
            elif field not in ('name_en', 'faction', 'rarity', 'affinity', 'role'):
                row['classification'] = 'UNCERTAIN'
                row['reasons'].append('unsupported_source_field')
            else:
                new = normalize_champion(field, r['new_value'])
                before = champion.get(field)
                row['operating_value'] = before
                row['normalized_new_value'] = new
                row['classification'] = classify(before, new, exists=field in champion)
                row['gates'].update(exact_ids=True, no_conflict=True)
                row['comparisons'].append({'field': field, 'operating': before, 'source': new})
                if field == 'name_en':
                    row['reasons'].append('rename_requires_coordinated_identity_maps')
                elif row['classification'] in ('CHANGED', 'NEW'):
                    row['operations'] = [{'path': COLLECTED, 'pointer': f'/champions/{i}/{field}',
                                          'before': before, 'after': new, 'existed': field in champion}]
                    try:
                        row['gates']['source_evidence'] = self.evidence(row, field, r['new_value'])
                    except (OSError, ValueError, KeyError, TypeError, IndexError) as exc:
                        row['invalid'] = True
                        row['reasons'].append('evidence_failed: ' + str(exc))
                    domains = {'role': {'Attack', 'Defense', 'HP', 'Support'},
                               'affinity': {'Magic', 'Force', 'Spirit', 'Void'},
                               'rarity': {'Common', 'Uncommon', 'Rare', 'Epic', 'Legendary', 'Mythical'}}
                    row['gates']['value_validation'] = (isinstance(new, str) and bool(new.strip()) and
                        (new in domains[field] if field in domains else new in {
                            c.get('faction') for c in self.baseline.collected['champions']}))
                row['dependencies'] = ['champion:' + cid]
        elif kind == 'skill':
            link = (cid, str(hid), str(r.get('form')), str(sid))
            skill = self.baseline.game['skills'].get(str(sid))
            row['dependencies'] = ['champion:' + str(cid), 'skill:' + str(sid)]
            if not matched:
                row['classification'] = 'UNMATCHED'
                row['reasons'].append('champion_game_id_not_bound')
            elif link not in self.baseline.links:
                row['classification'] = 'NEW' if skill is None else 'UNMATCHED'
                row['reasons'].append('new_skill_requires_verified_form_link_and_complete_display_bundle')
            else:
                row['gates'].update(exact_ids=True, no_conflict=True)
                fields = r.get('fields', {})
                update = skill.get('data_update', {})
                current_cd = update.get('verified_cooldown_unbooked', skill.get('raw_metadata', {}).get('c'))
                comparisons = row['comparisons']
                raw_cd = fields.get('cooldown_raw')
                if isinstance(raw_cd, str) and raw_cd.isdigit() and type(current_cd) is int:
                    comparisons.append({'field': 'cooldown_unbooked', 'operating': current_cd, 'source': int(raw_cd),
                                        'baseline_origin': 'verified_patch_overlay' if update else 'raw_game_cache'})
                en = skill.get('english', {})
                for field in ('name', 'description'):
                    if en.get(field) is not None and fields.get(field) is not None:
                        comparisons.append({'field': 'english.' + field, 'operating': en[field], 'source': fields[field]})
                row['operating_value'] = {'description_ko': skill.get('description_ko'),
                                          'english': en, 'cooldown_unbooked': current_cd,
                                          'data_update': update or None}
                differs = any(x['operating'] != x['source'] for x in comparisons)
                if update and any(x['field'] == 'cooldown_unbooked' and x['operating'] != x['source'] for x in comparisons):
                    row['classification'] = 'CONFLICT'
                    row['reasons'].append('source_disagrees_with_newer_applied_1_0_1_patch_do_not_roll_back')
                else:
                    row['classification'] = 'CHANGED' if differs else 'UNCERTAIN'
                    row['reasons'].append('external_effects_books_coefficients_and_target_enums_not_equivalent_to_operating_schema')
                row['uncompared_fields'] = ['Korean localization', 'abilities', 'books', 'multipliers_raw', 'hits_raw', 'targets']
                # Source facts cannot overwrite game-cache metadata or inferred combat fields.
                for x in comparisons:
                    if x['field'].startswith('english.') and x['operating'] != x['source']:
                        field = x['field'].split('.')[1]
                        try:
                            valid = self.evidence(row, field, fields[field])
                        except (OSError, ValueError, KeyError, TypeError, IndexError) as exc:
                            valid = False
                            row['invalid'] = True
                            row['reasons'].append('evidence_failed: ' + str(exc))
                        if valid:
                            row['operations'].append({'path': SKILLS, 'pointer': f'/skills/{sid}/english/{field}',
                                                      'before': x['operating'], 'after': x['source'], 'existed': True})
                # Partial skill comparisons cannot claim the whole skill AUTO_READY.
                row['reasons'].append('skill_bundle_requires_all_collected_fields_resolved')
        elif kind == 'skill_uncertainty':
            row['classification'] = 'UNCERTAIN'
            row['dependencies'] = ['skill:' + str(sid)]
            row['reasons'].append(r.get('new_value', {}).get('reason', 'missing_source_field'))
        else:
            row.update(classification='UNCERTAIN', reference_only=True)
            row['reasons'].append('source_document_or_external_namespace_has_no_verified_operating_field_adapter')
            if kind == 'artifact_set_review':
                entry = self.baseline.artifact_sets.get(r['identity'])
                row['operating_value'] = entry
                row['reasons'].append('existing_game_set_id_present' if entry else 'game_set_id_not_found')
        if row['classification'] in ('NEW', 'CHANGED') and not row['gates']['source_evidence']:
            row['reasons'].append('no_verified_official_id_value_and_explicit_patch_evidence')
        row['readiness'] = readiness(row)
        return row

    def run(self):
        rows = []
        for rid, record in sorted(self.records.items()):
            try:
                rows.append(self.row(rid, record))
            except (OSError, ValueError, KeyError, TypeError, IndexError) as exc:
                # An isolated bad record must not stop independent valid bundles.
                rows.append({'record_id': rid, 'kind': record.get('kind'), 'classification': 'UNCERTAIN',
                             'champion_id': record.get('champion_id'), 'skill_id': record.get('skill_id'),
                             'source': record.get('source'), 'invalid': True, 'comparisons': [], 'operations': [],
                             'gates': dict.fromkeys(GATES, False), 'readiness': 'REJECTED',
                             'dependencies': ([f"champion:{record['champion_id']}"] if record.get('champion_id') else []) +
                                             ([f"skill:{record['skill_id']}"] if record.get('skill_id') is not None else []),
                             'reasons': ['invalid_C1_record: ' + str(exc)]})
        # Detect contradictory values from different sources before either is staged.
        groups = defaultdict(list)
        for row in rows:
            for item in row['comparisons']:
                key = ('skill', str(row['skill_id']), item['field']) if row['skill_id'] is not None else (
                    'champion', row['champion_id'], item['field'])
                groups[key].append((row, item['source']))
            for op in row['operations']:
                groups[(op['path'], op['pointer'])].append((row, op['after']))
        for values in groups.values():
            if len({encoded(v) for _, v in values}) > 1:
                for row, _ in values:
                    row['classification'] = 'CONFLICT'
                    row['reasons'].append('contradictory_source_values_for_same_target')
        propagate(rows)
        return rows


def stage_operations(baseline, rows, source):
    docs, seen = {}, {}
    for row in rows:
        if not row['operations']:
            raise UpdateError('No materializable operations')
        for op in row['operations']:
            name, pointer = op['path'], op['pointer']
            if name not in (COLLECTED, SKILLS):
                raise UpdateError('No C adapter for path: ' + name)
            key = (name, pointer)
            if key in seen:
                if seen[key] != op:
                    raise UpdateError('Conflicting staged operation')
                continue
            seen[key] = op
            if name not in docs:
                docs[name] = read(baseline.resolve(name))
            replace(docs[name], pointer, op['after'], op['before'], op['existed'])
    for name, doc in docs.items():
        write(confined(source, name), doc)
        validate_payload(name, confined(source, name))
    return sorted(docs)


def exercise(baseline, doc, source, work):
    """Real existing B manager: 1.0.1 seed, interrupted commit, apply, repeat, recovery."""
    work = scratch_path(work)
    work.mkdir(parents=True, exist_ok=False)
    personal = work / 'personal'
    for name in ('teams.json', 'owned_champions.json', 'settings.json', 'personal_stats.json'):
        write(personal / name, {'isolated_sentinel': name, 'must_preserve': True})
    before = {p.name: digest(p) for p in personal.iterdir()}
    manager = baseline.seed(work / 'store')
    pointer = manager.store / 'active.json'
    old_pointer = pointer.read_bytes()
    pinned = manager.snapshot()

    def interrupt(point):
        if point == 'before_commit':
            raise UpdateError('C isolated injected interruption')
    failure = manager.apply(doc, package_dir=source, checkpoint=interrupt)
    if failure.get('success') or pointer.read_bytes() != old_pointer:
        raise UpdateError('Interrupted apply changed active baseline')
    applied = manager.apply(doc, package_dir=source)
    if not applied.get('success') or not applied.get('applied'):
        raise UpdateError('Isolated apply failed: ' + str(applied))
    candidate = manager.snapshot()
    for f in doc['files']:
        if digest(candidate.resolve(f['path'])) != f['sha256']:
            raise UpdateError('Applied file mismatch')
    for name, item in pinned.inventory.items():
        if name not in {f['path'] for f in doc['files']} and digest(candidate.resolve(name)) != item['sha256']:
            raise UpdateError('Unchanged overlay lost')
    repeat_pointer = pointer.read_bytes()
    repeated = manager.apply(doc, package_dir=source)
    if not repeated.get('success') or repeated.get('applied') or pointer.read_bytes() != repeat_pointer:
        raise UpdateError('Duplicate apply was not a no-op')
    # Corrupt only the isolated new generation; existing fallback must select 1.0.1.
    (candidate.generation / 'generation.json').write_text('{}', encoding='utf8')
    recovered = manager.snapshot()
    if recovered.data_version != baseline.manifest['data_version'] or not recovered.error:
        raise UpdateError('Previous-generation recovery failed')
    if {p.name: digest(p) for p in personal.iterdir()} != before:
        raise UpdateError('Isolated personal data changed')
    if pinned.data_version != baseline.manifest['data_version'] or any(digest(pinned.resolve(n)) != i['sha256'] for n, i in pinned.inventory.items()):
        raise UpdateError('Pinned baseline changed')
    return {'apply': True, 'duplicate_noop': True, 'interrupted_commit_preserved': True,
            'damaged_generation_fallback': True, 'pinned_reader_preserved': True,
            'personal_sentinels_preserved': True, 'scope': 'isolated_only', 'data_version': doc['data_version']}


def prepare(baseline, rows, work, *, test_data=False):
    """Validate each independent dependency bundle before giving AUTO_READY status."""
    work = scratch_path(work)
    work.mkdir(parents=True, exist_ok=False)
    possible = [r for r in rows if r['classification'] in ('NEW', 'CHANGED') and
                r['operations'] and all(r['gates'].get(g) is True for g in
                                       ('source_evidence', 'exact_ids', 'value_validation', 'no_conflict'))]
    groups = []
    for row in possible:
        touched = [g for g in groups if any(set(row['dependencies']) & set(x['dependencies']) for x in g)]
        merged = [row]
        for group in touched:
            merged.extend(group)
            groups.remove(group)
        groups.append(merged)
    next_version = version(baseline.manifest['data_version'])
    next_version = f'{next_version[0]}.{next_version[1]}.{next_version[2]+1}'
    # Nothing is written to a versioned publication folder unless there is a proven change.
    for i, group in enumerate(groups):
        try:
            source = work / f'bundle_{i}/source'
            paths = stage_operations(baseline, group, source)
            if not any(digest(confined(source, p)) != digest(baseline.resolve(p)) for p in paths):
                raise UpdateError('No actual changed bytes')
            out = work / f'bundle_{i}/validation_package'
            doc = build_online_package(source, out, paths, next_version, baseline.manifest['data_version'], APP, APP,
                                       'C-3 isolated data validation', test_data=True)
            validation = exercise(baseline, doc, source, work / f'bundle_{i}/apply_test')
            for row in group:
                row['gates'].update(schema_validation=True, compatibility=True, apply_recovery=True)
                row['validation'] = validation
        except (OSError, ValueError, KeyError, TypeError, IndexError) as exc:
            for row in group:
                row['invalid'] = True
                row['reasons'].append('bundle_validation_failed: ' + str(exc))
    propagate(rows)
    ready = [r for r in rows if r['readiness'] == 'AUTO_READY']
    if not ready:
        return {'status': 'NO_PACKAGE', 'data_version': baseline.manifest['data_version'],
                'version_incremented': False, 'packages': [], 'actual_changed_records': 0,
                'published': False, 'reason': 'no_AUTO_READY_material_changes'}
    source = work / 'merged_source'
    changed = stage_operations(baseline, ready, source)
    # Existing B cumulative semantics: preserve historical overlays for fresh 1.0.0 clients.
    # The field-level changelog contains only newly accepted operations.
    paths = sorted(set(changed) | set(baseline.overlay))
    for name in paths:
        target = confined(source, name)
        if not target.exists():
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(baseline.resolve(name).read_bytes())
    out = work / 'data-updates'
    doc = build_online_package(source, out, paths, next_version, '1.0.0', APP, APP,
                               f'C-3: {len(ready)} independently validated field changes',
                               test_data=test_data, cumulative_from_base=True)
    # Immutable index is derived from the exact official 1.0.1 manifest, never stale empty DEV4 index.
    prior = {}
    for f in baseline.manifest['files']:
        prior[f"files/{baseline.manifest['data_version']}/{f['path']}"] = {k: f[k] for k in ('size', 'sha256')}
    for p in baseline.manifest['packages']:
        prior[p['path']] = {k: p[k] for k in ('size', 'sha256')}
    index = work / 'published_index.json'
    write(index, {'files': prior, 'evidence': str(baseline.manifest_path), 'sha256': digest(baseline.manifest_path)})
    checked = preflight(out, out / 'beta/manifest.json', baseline.base, APP, index, allow_test_data=test_data)
    applied = exercise(baseline, doc, source, work / 'merged_apply_test')
    # Also validate the fresh application baseline via existing preflight above.
    write(work / 'package_validation.json', {'preflight': checked, 'isolated_update': applied})
    return {'status': 'LOCAL_VALIDATED', 'data_version': next_version, 'version_incremented': True,
            'manifest': str((out / 'beta/manifest.json').relative_to(ROOT)),
            'manifest_sha256': digest(out / 'beta/manifest.json'), 'packages': doc['packages'],
            'actual_changed_records': len(ready), 'changed_paths': changed,
            'historical_overlay_paths': sorted(set(paths) - set(changed)),
            'published': False, 'test_data': test_data, 'validation': applied,
            'validation_file': str((work / 'package_validation.json').relative_to(ROOT)),
            'validation_sha256': digest(work / 'package_validation.json'),
            'publish_first': checked['publish_first'], 'publish_last': 'beta/manifest.json'}


def protected_paths(baseline, c1):
    paths = {baseline.manifest_path, REVIEW, c1 / 'normalized/records.json', c1 / 'reports/summary.json',
             ROOT / 'game_data_update.py', ROOT / 'game_data_online.py', ROOT / 'application_update.py',
             ROOT / 'tools/data_update.py', ROOT / 'tools/data_update_release.py', Path(__file__),
             baseline.resolve('nightly_collection/manifest.json'),
             ROOT / COLLECTED, ROOT / SKILLS,
             ROOT / 'data/bulk_stage11/artifact_sets_ui.json',
             ROOT / 'scratch/auto_update_b/official_beta30_7/release_candidate/approval.json',
             ROOT / 'scratch/auto_update_b/official_beta30_7/before/program-updates/beta/approval.json'}
    assertions = c1 / 'normalized/c_value_assertions.json'
    if assertions.is_file():
        paths.add(assertions)
    paths.update(baseline.resolve(n) for n in baseline.overlay)
    for base in (ROOT / 'user_data', ROOT / 'ui_web_proof/user_data'):
        if base.exists():
            paths.update(base.glob('*.json'))
    for name in ('teams.json', 'owned_champions.json', 'settings.json'):
        if (ROOT / name).exists():
            paths.add(ROOT / name)
    return sorted(p for p in paths if p.is_file())


def run(c1=C1, output=None, work=None):
    c1 = project_path(c1)
    output = scratch_path(output or c1 / 'changes')
    baseline = Baseline()
    protected = {str(p.relative_to(ROOT)): digest(p) for p in protected_paths(baseline, c1)}
    records = read(c1 / 'normalized/records.json')
    if not isinstance(records, dict) or not all(isinstance(r, dict) for r in records.values()):
        raise UpdateError('C-1 normalized records must be an ID-keyed object')
    assertions_path = c1 / 'normalized/c_value_assertions.json'
    assertions = read(assertions_path) if assertions_path.is_file() else {}
    known = regressions(baseline)
    comparison = Comparison(baseline, records, c1, assertions)
    rows = comparison.run()
    for (name, sha), _raw in comparison.raw_cache.items():
        protected[str(project_path(name).relative_to(ROOT))] = sha
    run_id = hashlib.sha256(encoded({'inputs': protected, 'assertions': assertions})).hexdigest()
    if work is None:
        parent = ROOT / 'scratch/c_auto_collection/c3_runs'
        parent.mkdir(parents=True, exist_ok=True)
        work = Path(tempfile.mkdtemp(prefix=run_id[:12] + '_', dir=parent)) / 'validation'
    package = prepare(baseline, rows, work, test_data=c1 != C1.resolve())
    after = {name: digest(project_path(ROOT / name)) for name in protected}
    if protected != after:
        raise UpdateError('Protected input/official/personal file changed; discard run')
    counts = Counter(r['classification'] for r in rows)
    states = Counter(r['readiness'] for r in rows)
    totals = {'collected_records': len(records), 'classified_records': len(rows),
              'comparison_completed': sum(bool(r['comparisons']) for r in rows),
              'direct_operating_comparisons': sum(bool(r['comparisons']) for r in rows),
              'compared_field_values': sum(len(r['comparisons']) for r in rows),
              'not_directly_comparable': sum(not r['comparisons'] for r in rows),
              'classifications': {k: counts[k] for k in CLASSES},
              'readiness': {k: states[k] for k in STATES},
              'held_from_auto_apply': len(rows) - states['AUTO_READY'],
              'historical_regressions_already_applied': len(known)}
    common = {'format_version': 1, 'run_id': run_id, 'baseline_data_version': '1.0.1',
              'baseline_manifest_sha256': digest(baseline.manifest_path), 'published': False}
    write(output / 'c_diff_dry_run.json', dict(common, totals=totals, records=rows, historical_regressions=known,
                                             c1_summary=read(c1 / 'reports/summary.json')))
    write(output / 'c_auto_ready.json', dict(common, records=[r for r in rows if r['readiness'] == 'AUTO_READY'], package=package))
    write(output / 'c_review_queue.json', dict(common, records=[r for r in rows if r['readiness'] != 'AUTO_READY']))
    artifacts = {name: {'path': str((output / name).relative_to(ROOT)), 'sha256': digest(output / name),
                        'size': (output / name).stat().st_size}
                 for name in ('c_diff_dry_run.json', 'c_auto_ready.json', 'c_review_queue.json')}
    write(output / 'c4_result.json', dict(common, status=package['status'], totals=totals, package=package,
        inputs=protected, artifacts=artifacts, protected_unchanged=True,
        source_receipts_sha256=digest(assertions_path) if assertions_path.is_file() else None,
        execution={'stage': 'C2_C3', 'network_used': False, 'collector_run': False,
                   'official_publication_allowed': False, 'scheduler_enabled': False,
                   'requires_manual_approval_for_future_AUTO_READY': False,
                   'future_publication_requires': ['refresh_official_baseline_and_immutable_index', 'verify_run_and_payload_hashes',
                                                   'all_required_gates_true', 'publish_payloads_and_verify_before_manifest']},
        signing={'data': 'existing B data manifests use SHA-256; no new signature format',
                 'program': 'existing signed approval untouched; no program update'}))
    text = ['# C-2 / C-3 결과', '', 'C-1 재실행·네트워크·운영 반영·공식 게시 없음. 기준: 공식 데이터 1.0.1.', '',
            '집계 단위는 C-1 출처별 레코드이며 챔피언/스킬 고유 개수가 아닙니다.', '',
            '```json', json.dumps(totals, ensure_ascii=False, indent=2), '```', '',
            '## 이미 적용된 회귀 사례', '',
            'Big Un A3 / Brakus A3 / Rhazin A3: 공식 1.0.1 값·ID·오버레이와 일치, ALREADY_APPLIED.',
            '위 3건은 별도 과거 변경 확인입니다. C-1의 오래된 원문은 ALREADY_APPLIED로 위장하지 않고 CONFLICT로 보류합니다.', '',
            '## 패키지', '', json.dumps(package, ensure_ascii=False, indent=2), '',
            'AUTO_READY가 없으면 새 게임 데이터 버전과 실제 배포 패키지를 생성하지 않습니다.',
            '검증용 fixture 패키지는 별도 test_data=true이며 실제 배포 대상이 아닙니다.', '',
            '원문·외부 ID·번역·모델 계수는 운영 필드와 의미가 같다는 근거가 없으면 UNCERTAIN/REVIEW 또는 REFERENCE_ONLY입니다.',
            '상세 전후 값·출처·이유는 c_diff_dry_run.json, 보류 목록은 c_review_queue.json을 확인합니다.', '',
            '보호 대상 입력/공식 매니페스트/운영 JSON/프로젝트 내 개인 파일 SHA 불변. 실제 사용자 설치 환경은 읽거나 변경하지 않았습니다.',
            'C-4 연결 계약: c4_result.json. 무인 배포와 스케줄러는 비활성 상태이며 C 전체 완료를 뜻하지 않습니다.', '']
    report = output / 'C_READY_REPORT.md'
    report.parent.mkdir(parents=True, exist_ok=True)
    report.write_text('\n'.join(text), encoding='utf8')
    return dict(common, totals=totals, package=package, protected_unchanged=True)


def verify_result(path):
    """Read-only C-4 handoff check. Does not authorize/perform publication."""
    path = scratch_path(path)
    result = read(path)
    if result.get('format_version') != 1 or result.get('status') not in ('NO_PACKAGE', 'LOCAL_VALIDATED'):
        raise UpdateError('No current successful C-2/C-3 result')
    if result.get('published') is not False or result.get('protected_unchanged') is not True:
        raise UpdateError('Unexpected publication/protection state')
    for name, sha in result['inputs'].items():
        if digest(project_path(ROOT / name)) != sha:
            raise UpdateError('C input changed: ' + name)
    docs = {}
    for name, item in result['artifacts'].items():
        artifact = scratch_path(ROOT / item['path'])
        if artifact.stat().st_size != item['size'] or digest(artifact) != item['sha256']:
            raise UpdateError('C artifact size/SHA mismatch: ' + name)
        docs[name] = read(artifact)
        if docs[name].get('run_id') != result['run_id']:
            raise UpdateError('C artifact belongs to a different run')
    ready = docs['c_auto_ready.json']['records']
    queue = docs['c_review_queue.json']['records']
    diff = docs['c_diff_dry_run.json']
    if len(ready) + len(queue) != result['totals']['collected_records'] or len(diff['records']) != len(ready) + len(queue):
        raise UpdateError('C classification totals do not reconcile')
    if any(r['readiness'] != 'AUTO_READY' or readiness(r) != 'AUTO_READY' for r in ready):
        raise UpdateError('Incomplete AUTO_READY gates')
    if any(r['readiness'] == 'AUTO_READY' for r in queue):
        raise UpdateError('AUTO_READY item in hold queue')
    package = result['package']
    if docs['c_auto_ready.json']['package'] != package:
        raise UpdateError('Package/result mismatch')
    if result['status'] == 'NO_PACKAGE':
        if ready or package['packages'] or package['version_incremented'] or package['data_version'] != result['baseline_data_version']:
            raise UpdateError('No-op result contains a release')
    else:
        if not ready or len(ready) != package['actual_changed_records']:
            raise UpdateError('Package has no proven changes')
        manifest = scratch_path(ROOT / package['manifest'])
        if digest(manifest) != package['manifest_sha256']:
            raise UpdateError('C manifest changed')
        doc = read(manifest)
        from game_data_online import validate_online_manifest
        validate_online_manifest(doc, APP, 'beta')
        if doc['data_version'] != package['data_version'] or doc['packages'] != package['packages']:
            raise UpdateError('C package inventory changed')
        if bool(doc.get('test_data')) != bool(package.get('test_data')):
            raise UpdateError('C test-data status mismatch')
        for item in doc['packages']:
            payload = confined(manifest.parents[1], item['path'])
            if payload.stat().st_size != item['size'] or digest(payload) != item['sha256']:
                raise UpdateError('C ZIP changed')
        for item in doc['files']:
            sidecar = confined(manifest.parents[1], f"files/{doc['data_version']}/{item['path']}")
            if sidecar.stat().st_size != item['size'] or digest(sidecar) != item['sha256']:
                raise UpdateError('C raw sidecar changed')
        validation = scratch_path(ROOT / package['validation_file'])
        if digest(validation) != package['validation_sha256'] or not read(validation)['preflight']['preflight_pass']:
            raise UpdateError('C validation proof changed/failed')
    return {'format_version': 1, 'run_id': result['run_id'], 'verified': True, 'status': result['status'],
            'local_package_eligible': result['status'] == 'LOCAL_VALIDATED' and not package.get('test_data', False),
            'publication_enabled': False, 'scheduler_enabled': False,
            'requires_manual_approval_for_future_AUTO_READY': False}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--c1', type=Path, default=C1)
    p.add_argument('--output', type=Path)
    p.add_argument('--verify-result', type=Path, help='Read-only local C-4 contract/hash check')
    args = p.parse_args()
    try:
        result = verify_result(args.verify_result) if args.verify_result else run(args.c1, args.output)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    except (OSError, ValueError, KeyError, TypeError, IndexError) as exc:
        failure = {'format_version': 1, 'status': 'FAILED', 'published': False, 'error': str(exc)}
        if args.verify_result:
            print(json.dumps(failure, ensure_ascii=False))
            return 1
        output = scratch_path(args.output or args.c1 / 'changes')
        write(output / 'c4_failure.json', failure)
        # Invalidate an earlier success at the authoritative machine entry point.
        write(output / 'c4_result.json', failure)
        print(json.dumps(failure, ensure_ascii=False))
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
