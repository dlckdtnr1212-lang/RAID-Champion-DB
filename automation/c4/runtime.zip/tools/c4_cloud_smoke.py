"""Linux/Windows isolated replay of the real already-published 1.0.1 data only."""
from pathlib import Path
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from tools import c_data_pipeline as c
from tools.c4_github import TRUST, canonical_hash
from application_update import verify_approval
from game_data_update import DataUpdateManager
from tools.data_update import build_online_package
from tools.data_update_release import preflight


def smoke():
    base = c.Baseline()
    approval = c.read(ROOT / 'scratch/auto_update_b/official_beta30_7/before/program-updates/beta/approval.json')
    payload = verify_approval(approval, c.read(TRUST), 'beta')
    assert payload['data_manifest_canonical_sha256'] == canonical_hash(base.manifest)
    assert all(r['verified_against_official_1_0_1'] for r in c.regressions(base))
    parent = ROOT / 'scratch/c4_cloud_smoke'
    parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(dir=parent) as tmp:
        tmp = Path(tmp)
        personal = tmp / 'personal'
        for name in ('teams.json', 'owned_champions.json', 'final_stats.json', 'equipment.json'):
            c.write(personal / name, {'isolated': True, 'retain': name})
        original = {p.name: c.digest(p) for p in personal.iterdir()}
        out = tmp / 'package'
        doc = build_online_package(base.source, out, sorted(base.overlay), '1.0.1', '1.0.0', c.APP, c.APP,
                                   'C4 historical replay - never publish', test_data=True, cumulative_from_base=True)
        checked = preflight(out, out / 'beta/manifest.json', ROOT, c.APP, allow_test_data=True)
        manager = DataUpdateManager(ROOT, tmp / 'store', c.APP)
        pinned = manager.snapshot()
        applied = manager.apply(doc, package_dir=base.source)
        assert applied.get('applied') and manager.snapshot().data_version == '1.0.1'
        pointer = (manager.store / 'active.json').read_bytes()
        repeat = manager.apply(doc, package_dir=base.source)
        assert repeat['success'] and not repeat['applied']
        broken = dict(doc, data_version='1.0.2', base_data_version='1.0.1')
        broken['files'] = [dict(f, sha256='0' * 64) for f in doc['files']]
        assert not manager.apply(broken, package_dir=base.source)['success']
        assert pointer == (manager.store / 'active.json').read_bytes()
        assert original == {p.name: c.digest(p) for p in personal.iterdir()}
        assert pinned.data_version == '1.0.0'
    return {'actual_historical_1_0_1': True, 'already_applied_A3': 3, 'signature_valid': True,
            'B_packaging_preflight': checked['preflight_pass'], 'isolated_apply': True,
            'duplicate_noop': True, 'bad_manifest_preserved_active': True,
            'personal_preserved': True, 'pinned_reader': True, 'published': False}


if __name__ == '__main__':
    import json
    print(json.dumps(smoke()))
