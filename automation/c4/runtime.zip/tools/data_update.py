"""Developer-only data update CLI. No automatic checks, builds or publishing."""
from pathlib import Path
import argparse
import json
import shutil
import hashlib
import zipfile
import sys

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from game_data_update import (DataUpdateManager, MANIFEST_URL, BASE_DATA_VERSION,
                              allowed_path, confined, digest, json_bytes, validate_manifest,
                              validate_payload, version, UpdateError)


def build_package(source, output, paths, data_version, base_version, min_app, max_app, description, url_base):
    """Explicit changed-file list; never crawl user/developer folders or zip extracts."""
    source, output = Path(source).resolve(), Path(output).resolve()
    if output.exists():
        raise UpdateError("Output already exists; choose a fresh package directory")
    files = []
    for name in paths:
        allowed_path(name)
        path = confined(source, name)
        validate_payload(name, path)
        files.append({"path": name, "url": url_base.rstrip('/') + '/' + name,
                      "size": path.stat().st_size, "sha256": digest(path)})
    manifest = {"manifest_format_version": 1, "data_version": data_version,
                "base_data_version": base_version,
                "compatible_app_versions": {"min": min_app, "max": max_app},
                "description": description, "files": files}
    validate_manifest(manifest, min_app)
    output.mkdir(parents=True)
    for item in files:
        target = confined(output, item['path'])
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(confined(source, item['path']), target)
        if target.stat().st_size != item['size'] or digest(target) != item['sha256']:
            raise UpdateError("Source changed while building package")
    (output / 'manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf8')
    return manifest


def build_online_package(source, output, paths=None, data_version=None, base_version=BASE_DATA_VERSION,
                         min_app='1.0.0-beta.29', max_app='1.0.0-beta.29', description='',
                         channel='beta', url_base=None, against=None, test_data=False, cumulative_from_base=False,
                         reuse_packages=None):
    """Reuse DEV1 builder; one deterministic ZIP per changed file avoids unchanged downloads."""
    from game_data_online import URL_ROOT, DATA_SCHEMA_VERSION, validate_online_manifest
    source, output = Path(source).resolve(), Path(output).resolve()
    if paths is None:
        if source == ROOT:
            raise UpdateError('For a project-root source, explicitly select --files; no full image scan')
        # Developer supplies a small staging folder. Unknown files are rejected,
        # rather than accidentally including stores or executable build output.
        paths = [p.relative_to(source).as_posix() for p in source.rglob('*') if p.is_file()]
    selected = []
    for name in paths:
        allowed_path(name)
        path = confined(source, name)
        if against and not cumulative_from_base:
            prior = confined(against, name, allow_links=True)
            if prior.is_file() and prior.stat().st_size == path.stat().st_size and digest(prior) == digest(path):
                continue
        selected.append(name)
    if not selected:
        raise UpdateError('No changed data files to package')
    base = version(base_version)
    data_version = data_version or f'{base[0]}.{base[1]}.{base[2]+1}'
    if version(data_version) <= base:
        raise UpdateError('Data version must be newer than base version')
    if output.exists():
        raise UpdateError('Output already exists; select a fresh distribution directory')
    url_base = (url_base or URL_ROOT).rstrip('/')
    # Keep DEV1-compatible raw sidecars at their truthful URLs; online clients
    # fetch ZIPs only. Both contain only the explicitly selected changed data.
    payload_relative = f'files/{data_version}'
    manifest = build_package(source, output/payload_relative, selected, data_version, base_version,
                             min_app, max_app, description, url_base+'/'+payload_relative)
    (output/payload_relative/'manifest.json').unlink()  # generated metadata, not a game file
    packages = []
    for entry in manifest['files']:
        key = hashlib.sha256((entry['path']+entry['sha256']).encode()).hexdigest()
        name = f'packages/data_{data_version}_{key}.zip'
        path = confined(output, name); path.parent.mkdir(parents=True, exist_ok=True)
        info = zipfile.ZipInfo(entry['path'])
        info.create_system = 3; info.external_attr = 0o100644 << 16
        info.compress_type = zipfile.ZIP_DEFLATED
        if reuse_packages is not None:
            # Previously validated immutable payloads keep their exact bytes.
            # The caller's existing publication preflight validates their contents.
            shutil.copyfile(confined(Path(reuse_packages), name), path)
        else:
            with zipfile.ZipFile(path, 'x', compression=zipfile.ZIP_DEFLATED) as archive:
                archive.writestr(info, confined(output/payload_relative, entry['path']).read_bytes())
        packages.append({'path': name, 'url': url_base+'/'+name, 'size': path.stat().st_size,
                         'sha256': digest(path), 'files': [entry['path']]})
    manifest.update(channel=channel, data_schema_version=DATA_SCHEMA_VERSION, packages=packages)
    if test_data:
        manifest['test_data'] = True
    if cumulative_from_base:
        manifest['cumulative_from_base'] = True
    validate_online_manifest(manifest, min_app, channel)
    target = confined(output, f'{channel}/manifest.json'); target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf8')
    return manifest


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--base', type=Path, default=ROOT)
    p.add_argument('--store', type=Path, default=ROOT / 'game_data_updates')
    p.add_argument('--app-version', default=json.loads((ROOT/'ui_web_proof/packaging_manifest.json').read_text(encoding='utf-8-sig'))['application']['version'])
    sub = p.add_subparsers(dest='command', required=True)
    sub.add_parser('status')
    check = sub.add_parser('check')
    check.add_argument('--manifest', type=Path, help='Omit for explicit official GitHub check')
    for command in ('online-check', 'online-apply'):
        online = sub.add_parser(command)
        online.add_argument('--channel', choices=['beta', 'stable'], default='beta')
        if command == 'online-apply':
            online.add_argument('--confirm-version', required=True, help='Explicitly confirm the displayed data version')
    apply = sub.add_parser('apply')
    apply.add_argument('--manifest', type=Path, required=True)
    apply.add_argument('--package', type=Path, help='Local package root; omit to download listed files')
    build = sub.add_parser('build')
    build.add_argument('--source', type=Path, required=True)
    build.add_argument('--output', type=Path, required=True)
    build.add_argument('--files', nargs='+', required=True)
    build.add_argument('--data-version', required=True)
    build.add_argument('--base-data-version', default=BASE_DATA_VERSION)
    build.add_argument('--min-app', required=True)
    build.add_argument('--max-app', required=True)
    build.add_argument('--description', required=True)
    build.add_argument('--url-base', required=True, help='Official repo raw URL or data Release asset URL prefix')
    online_build = sub.add_parser('build-online')
    online_build.add_argument('--source', type=Path, required=True, help='Small developer staging folder')
    online_build.add_argument('--output', type=Path, required=True)
    online_build.add_argument('--files', nargs='+')
    online_build.add_argument('--against', type=Path, help='Compare selected files only; skip unchanged files')
    online_build.add_argument('--data-version', help='Default: increment base-data-version patch number')
    online_build.add_argument('--base-data-version', default=BASE_DATA_VERSION)
    online_build.add_argument('--min-app', default='1.0.0-beta.29')
    online_build.add_argument('--max-app', default='1.0.0-beta.29')
    online_build.add_argument('--description', required=True)
    online_build.add_argument('--channel', choices=['beta', 'stable'], default='beta')
    online_build.add_argument('--url-base')
    online_build.add_argument('--test-data', action='store_true', help='Mark fixtures as ineligible for publication')
    preflight = sub.add_parser('preflight')
    preflight.add_argument('--directory', type=Path, required=True)
    preflight.add_argument('--manifest', type=Path, required=True)
    preflight.add_argument('--published-index', type=Path)
    preflight.add_argument('--installed-store', type=Path, help='Read-only prior game update store for sequential releases')
    preflight.add_argument('--report', type=Path, required=True, help='Write report outside publication directory')
    preflight.add_argument('--allow-test-data', action='store_true', help='Engineering validation only; publication remains unapproved')
    prepare = sub.add_parser('prepare-release', help='Approved change list -> existing builder -> existing preflight; local only')
    prepare.add_argument('--plan', type=Path, required=True)
    prepare.add_argument('--output', type=Path, required=True)
    prepare.add_argument('--report', type=Path, required=True)
    draft = sub.add_parser('draft-release', help='Generate unapproved review plan/hashes from an explicit change list')
    draft.add_argument('--source', type=Path, required=True)
    draft.add_argument('--files', nargs='+', required=True)
    draft.add_argument('--evidence', type=Path, required=True)
    draft.add_argument('--output', type=Path, required=True)
    draft.add_argument('--installed-store', type=Path)
    draft.add_argument('--channel', choices=['beta','stable'], default='beta')
    args = p.parse_args()
    try:
        manager = DataUpdateManager(args.base, args.store, args.app_version)
        if args.command == 'draft-release':
            from tools.data_update_prepare import draft_release
            result = draft_release(args.source,args.base,args.files,args.evidence,args.output,args.app_version,args.installed_store,args.channel)
        elif args.command == 'prepare-release':
            from tools.data_update_prepare import prepare_release
            result = prepare_release(args.plan,args.output,args.report)
        elif args.command == 'preflight':
            from tools.data_update_release import preflight
            if args.report.resolve().is_relative_to(args.directory.resolve()):
                raise UpdateError('Preflight report must be outside the publication directory')
            result = preflight(args.directory,args.manifest,args.base,args.app_version,args.published_index,args.allow_test_data,args.installed_store)
            args.report.parent.mkdir(parents=True,exist_ok=True)
            args.report.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8')
        elif args.command == 'build-online':
            result = build_online_package(args.source, args.output, args.files, args.data_version, args.base_data_version,
                args.min_app, args.max_app, args.description, args.channel, args.url_base, args.against,args.test_data)
            publish_first = sorted(p.relative_to(args.output).as_posix() for p in args.output.rglob('*')
                                   if p.is_file() and p.name != 'manifest.json')
            result = {'success': True, 'data_version': result['data_version'], 'changed_files': [f['path'] for f in result['files']],
                      'publish_first': publish_first, 'publish_last': args.channel+'/manifest.json',
                      'published': False, 'instruction': 'Upload immutable payloads first; verify availability; replace channel manifest LAST. Approval required for publication.'}
        elif args.command in ('online-check', 'online-apply'):
            from game_data_online import OnlineDataClient
            client = OnlineDataClient(manager, args.channel)
            result, doc = client.check()
            if args.command == 'online-apply' and result.get('success') and result.get('available'):
                if args.confirm_version != doc['data_version']:
                    raise UpdateError('Confirmed version does not match the current online manifest')
                result = client.apply(doc)
        elif args.command == 'build':
            result = build_package(args.source, args.output, args.files, args.data_version, args.base_data_version,
                                   args.min_app, args.max_app, args.description, args.url_base)
        elif args.command == 'status':
            result = manager.status()
        else:
            manifest = json_bytes(args.manifest.read_bytes()) if args.manifest else None
            result = manager.check(manifest) if args.command == 'check' else manager.apply(manifest, args.package)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0 if result.get('success', True) or result.get('publication_status') == 'not_published' else 1
    except (OSError, ValueError) as exc:
        print(json.dumps({'success': False, 'error': str(exc)}, ensure_ascii=False))
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
