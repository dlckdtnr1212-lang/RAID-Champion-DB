"""C4.1-4.3: PC evidence producer, independent cloud validator, single publisher.

Only reviewed game-source JSON/raw receipts cross the PC/cloud boundary. Remote
checkpoints are untrusted input: never load code, keys, or a local ready flag.
"""
from __future__ import annotations

import argparse
from collections import Counter
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from tools import c_data_pipeline as c
from tools import c4_auto_update as runner
from tools import c4_github as gh
from tools.c4_sources import Sources, fingerprint

BRANCH = 'c4-automation-state'
CLOUD = ROOT / 'scratch/c4_cloud'
MAX_ZIP = 25 * 1024 * 1024
MAX_EXPANDED = 200 * 1024 * 1024


def archive(files):
    out = io.BytesIO()
    with zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for name, data in sorted(files.items()):
            safe_name(name)
            info = zipfile.ZipInfo(name, (2026, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            z.writestr(info, data)
    raw = out.getvalue()
    if len(raw) > MAX_ZIP or sum(map(len, files.values())) > MAX_EXPANDED:
        raise gh.Blocked('Shared checkpoint storage limit exceeded')
    return raw


def safe_name(name):
    if not isinstance(name, str) or not re.fullmatch(r'[A-Za-z0-9_./-]+', name) or (
        PurePosixPath(name).is_absolute() or any(p in ('', '.', '..') for p in name.split('/'))):
        raise gh.Blocked('Unsafe shared archive member')


def unpack(raw, allowed):
    if len(raw) > MAX_ZIP:
        raise gh.Blocked('Oversized shared archive')
    output = {}
    with zipfile.ZipFile(io.BytesIO(raw)) as z:
        if sum(i.file_size for i in z.infolist()) > MAX_EXPANDED or len(z.infolist()) > 4000:
            raise gh.Blocked('Expanded checkpoint limit exceeded')
        for item in z.infolist():
            safe_name(item.filename)
            if item.filename in output or not allowed(item.filename) or (item.external_attr >> 16) & 0o170000 == 0o120000:
                raise gh.Blocked('Unapproved shared archive member')
            output[item.filename] = z.read(item)
    return output


class SharedBranch(gh.GitHub):
    """Separate state branch, optimistic non-forced writes; never updates main."""
    def api(self, path, method='GET', body=None):
        path = path.replace('/git/refs/heads/main', '/git/refs/heads/' + BRANCH)
        return super().api(path, method, body)

    def state_snapshot(self):
        refs = self.api(gh.API + '/git/matching-refs/heads/' + BRANCH)
        refs = [r for r in refs if r['ref'] == 'refs/heads/' + BRANCH]
        if not refs:
            return None
        head = refs[0]['object']['sha']
        commit = self.api(gh.API + '/git/commits/' + head)
        tree = self.api(gh.API + '/git/trees/' + commit['tree']['sha'] + '?recursive=1')
        if tree.get('truncated'):
            raise gh.Blocked('Incomplete checkpoint tree')
        return {'head': head, 'tree': commit['tree']['sha'],
                'files': {i['path']: i for i in tree['tree'] if i['type'] == 'blob'}}

    def get_shared(self, name):
        if name not in ('cloud.zip', 'local.zip'):
            raise gh.Blocked('Shared file boundary')
        snapshot = self.state_snapshot()
        if snapshot and name in snapshot['files']:
            if snapshot['files'][name].get('size', MAX_ZIP + 1) > MAX_ZIP:
                raise gh.Blocked('Remote checkpoint size limit')
            return self.blob(snapshot['files'][name]['sha'])
        return None

    def put_shared(self, name, raw):
        if name not in ('cloud.zip', 'local.zip') or len(raw) > MAX_ZIP:
            raise gh.Blocked('Shared file boundary/limit')
        for attempt in range(3):
            before = self.state_snapshot()
            if before is None:
                head = super().api(gh.API + '/git/ref/heads/main')['object']['sha']
                try:
                    self.api(gh.API + '/git/refs', 'POST', {'ref': 'refs/heads/' + BRANCH, 'sha': head})
                except gh.Blocked:
                    if not self.state_snapshot():
                        raise
                before = self.state_snapshot()
            if before['files'].get(name, {}).get('sha') == gh.git_sha(raw):
                return {'changed': False, 'commit': before['head']}
            try:
                commit = self.commit_files(before, {name: raw}, 'C4 checkpoint: ' + name)
                return {'changed': True, 'commit': commit}
            except gh.Blocked:
                if attempt == 2:
                    raise


def candidate_files(root):
    """Select fields, not a whole local report/profile. No caller readiness flags."""
    report = c.read(root / 'last_comparison.json')
    # NO_PACKAGE reports also retain the source bundle alongside comparison.json.
    comparison = c.read(root / 'latest.json').get('comparison')
    if comparison:
        path = ROOT / comparison
    else:
        candidates = sorted((root / 'runs').glob('*/comparison.json'), key=lambda p: p.stat().st_mtime)
        if not candidates:
            return None
        path = candidates[-1]
    bundle = c.read(path.parent / 'source_bundle.json')
    state = c.read(root / 'state.json')
    record_keys = ('record_id', 'kind', 'identity', 'source', 'raw_file', 'raw_file_sha256', 'game_hero_id',
                   'champion_id', 'skill_id', 'form_index', 'new_value', 'old_value', 'source_anchor',
                   'game_version', 'collected_at', 'form', 'fields')
    records = {rid: {k: value for k, value in row.items() if k in record_keys}
               for rid, row in bundle['records'].items() if row['kind'] in ('champion_field', 'champion_form', 'skill')}
    for row in records.values():
        row['classification'] = 'UNCERTAIN'  # Historical flag is informational only; C-2 recalculates.
    files = {}
    source_root = c.scratch_path(ROOT / bundle['source_root'])
    for row in records.values():
        if not re.fullmatch(r'raw/[a-f0-9]{64}\.bin', row['raw_file']):
            raise gh.Blocked('Candidate raw path not content-addressed')
        source = c.confined(source_root, row['raw_file'])
        if c.digest(source) != row['raw_file_sha256']:
            raise gh.Blocked('Candidate raw receipt changed')
        files[row['raw_file']] = source.read_bytes()
    # Documents are deliberately excluded: cloud fetches official announcements itself.
    coverage = complete_coverage(records).intersection(bundle.get('coverage_hero_ids', []))
    files['candidates.json'] = c.encoded({'format_version': 1, 'records': records,
        'source_fingerprint': bundle.get('source_fingerprint', state.get('observed')),
        'baseline_version': report['package']['data_version'], 'coverage': sorted(coverage)})
    return files


def complete_coverage(records):
    """Source-complete hero forms/skill refs only; not game-schema approval."""
    coverage = set()
    heroes = {r.get('game_hero_id') for r in records.values() if r['kind'] == 'champion_form'}
    for hid in heroes:
        rows = [r for r in records.values() if r.get('game_hero_id') == hid]
        forms = [r for r in rows if r['kind'] == 'champion_form']
        skill_links = {(str(r.get('form')), str(r.get('skill_id'))) for r in rows if r['kind'] == 'skill'}
        fields = {r['identity'][1] for r in rows if r['kind'] == 'champion_field'}
        if fields != {'name_en', 'rarity', 'role', 'affinity', 'faction'}:
            continue
        if all(r['new_value'].get('skills') and all((str(r['new_value']['form']), sid) in skill_links
            for sid in str(r['new_value']['skills']).split(',')) for r in forms):
            coverage.add(hid)
    return coverage


def validate_candidates(raw):
    files = unpack(raw, lambda n: n == 'candidates.json' or bool(re.fullmatch(r'raw/[a-f0-9]{64}\.bin', n)))
    doc = c.json_bytes(files['candidates.json'])
    if set(doc) != {'format_version', 'records', 'source_fingerprint', 'baseline_version', 'coverage'} or doc['format_version'] != 1:
        raise gh.Blocked('Unknown shared candidate schema')
    if not isinstance(doc['records'], dict) or len(doc['records']) > 500 or not isinstance(doc['coverage'], list) or len(doc['coverage']) > 8:
        raise gh.Blocked('Candidate record limit/unsupported coverage')
    allowed_record_keys = {'record_id', 'kind', 'identity', 'source', 'raw_file', 'raw_file_sha256', 'game_hero_id',
        'champion_id', 'skill_id', 'form_index', 'new_value', 'old_value', 'source_anchor',
        'game_version', 'collected_at', 'form', 'fields', 'classification'}
    for rid, row in doc['records'].items():
        if set(row) - allowed_record_keys or row.get('kind') not in ('champion_field', 'champion_form', 'skill'):
            raise gh.Blocked('Candidate field/kind boundary')
        if row.get('source', '').split('/')[2:3] != ['hellhades.com']:
            raise gh.Blocked('Candidate source boundary')
        data = files.get(row.get('raw_file'))
        if data is None or hashlib.sha256(data).hexdigest() != row['raw_file_sha256']:
            raise gh.Blocked('Shared candidate SHA mismatch')
        from tools.c_night_collect import sha, encoded
        if rid != sha(encoded([row['kind'], row['identity'], row['source']])):
            raise gh.Blocked('Shared candidate record identity hash mismatch')
        if row['kind'] == 'champion_form':
            hid = row['game_hero_id']
            expected_url = 'https://hellhades.com/wp-json/hh-api/v3/raid/forms/' + str(hid - hid % 10)
            objects = c.json_bytes(data)
            matched = [o for o in objects if str(o.get('heroid')) == str(hid) and
                str(o.get('form')) == str(row['identity'][1])] if isinstance(objects, list) else []
            if row['source'] != expected_url or len(matched) != 1 or matched[0] != row['new_value']:
                raise gh.Blocked('Shared form raw identity/value mismatch')
    if any(type(hid) is not int or hid <= 0 for hid in doc['coverage']) or not set(doc['coverage']) <= complete_coverage(doc['records']):
        raise gh.Blocked('Shared coverage lacks complete exact form/skill references')
    return doc, files


class HybridSources(Sources):
    def __init__(self, root, shared=None):
        super().__init__(root)
        self.shared = shared
        self.review_revision = hashlib.sha256(shared).hexdigest() if shared else 'no_local_receipt'
        self.discovery = None

    def discover(self):
        self.discovery = super().discover()
        return self.discovery

    def seed_shared(self):
        doc, files = validate_candidates(self.shared)
        for name, data in files.items():
            if name.startswith('raw/'):
                target = c.confined(self.root, name)
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(data)
        return doc

    def initial_candidates(self):
        records = super().initial_candidates()
        # Shared candidates seed a review only; fresh metadata and all source gates
        # run again. Never skip detail collection on incomplete local coverage.
        if self.shared:
            doc = self.seed_shared()
            records.update(doc['records'])
        return records

    def collect(self, baseline, targets, batch_id):
        if self.shared:
            doc = self.seed_shared()
            wanted = {t['heroId'] for t in targets}
            if self.discovery and doc['source_fingerprint'] == self.discovery['fingerprint'] and wanted <= set(doc['coverage']):
                records = {k: r for k, r in doc['records'].items() if r['game_hero_id'] in wanted}
                return self.refresh_metadata(records, self.discovery, baseline)
        return super().collect(baseline, targets, batch_id)


class LocalSources(Sources):
    def __init__(self, root, shared):
        super().__init__(root)
        self.cloud_state = self.cloud_latest = None
        if shared:
            files = unpack(shared, checkpoint_allowed)
            for name, attribute in (('state.json', 'cloud_state'), ('latest.json', 'cloud_latest')):
                raw = files.get('scratch/c4_cloud/' + name)
                if raw:
                    setattr(self, attribute, c.json_bytes(raw))

    def shared_processed(self, discovery, baseline):
        state, latest = self.cloud_state, self.cloud_latest
        return bool(state and latest and not state.get('pending') and state.get('initial_review_complete')
            and state.get('observed') == discovery['fingerprint'] and not state.get('backlog')
            and latest.get('data_version') == baseline.manifest['data_version']
            and state.get('official_manifest_hash') == gh.canonical_hash(baseline.manifest)
            and latest['status'] in ('NO_CHANGE', 'NO_UPDATE', 'PUBLISHED'))


def checkpoint_allowed(name):
    if not name.startswith('scratch/c4_cloud/'):
        return False
    relative = name[len('scratch/c4_cloud/'):]
    return relative in ('state.json', 'last_comparison.json', 'latest.json') or (
        relative.startswith(('sources/', 'official/', 'runs/')) and
        (relative.endswith('.json') or bool(re.search(r'/raw/[a-f0-9]{64}\.bin$', relative)))) or (
        '/c3/data-updates/' in relative and relative.endswith('.zip'))


def restore_checkpoint(shared):
    if not shared:
        return
    files = unpack(shared, checkpoint_allowed)
    for name, raw in files.items():
        target = c.scratch_path(ROOT / name)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(raw)


def cloud_checkpoint():
    state = c.read(CLOUD / 'state.json')
    refs = {state.get('pending', {}).get('comparison')} if state.get('pending') else set()
    latest = c.read(CLOUD / 'latest.json')
    refs.add(latest.get('comparison'))
    run_ids = {Path(p).parent.name for p in refs if p}
    # Keep latest comparison source receipts for a later local consumer/review.
    if (CLOUD / 'last_comparison.json').is_file():
        run_ids.add(c.read(CLOUD / 'last_comparison.json')['run_id'])
    files = {}
    # Retain only active official data and bounded recent HTTP cache. Exact
    # evidence for saved/unfinished comparisons survives cache aging separately.
    cache_path = CLOUD / 'sources/checkpoints/http.json'
    cache = c.read(cache_path) if cache_path.is_file() else {}
    recent = sorted(cache, key=lambda u: cache[u].get('collected_at', ''), reverse=True)[:128]
    sentinel = ('https://hellhades.com/wp-json/hh-api/v3/champions?mode=full',
                'https://forum.plarium.com/raid-shadow-legends/843_news/')
    cache = {u: v for u, v in cache.items() if u in recent or u in sentinel}
    raw_names = {v['path'] for v in cache.values()}
    def evidence_names(value):
        if isinstance(value, dict):
            for k, v in value.items():
                if k in ('raw_file', 'path') and isinstance(v, str) and re.fullmatch(r'raw/[a-f0-9]{64}\.bin', v):
                    raw_names.add(v)
                else:
                    evidence_names(v)
        elif isinstance(value, list):
            for v in value:
                evidence_names(v)
    for path in (CLOUD / 'sources/normalized').glob('*.json'):
        evidence_names(c.read(path))
    for run_id in run_ids:
        path = CLOUD / 'runs' / run_id / 'source_bundle.json'
        if path.is_file():
            evidence_names(c.read(path))
    for path in CLOUD.rglob('*'):
        if not path.is_file():
            continue
        name = path.relative_to(ROOT).as_posix()
        rel = path.relative_to(CLOUD).parts
        if rel[0] == 'official' and rel[1] != state.get('official_manifest_hash'):
            continue
        if rel[:2] == ('sources', 'raw') and '/'.join(rel[1:]) not in raw_names:
            continue
        if checkpoint_allowed(name) and (rel[0] != 'runs' or rel[1] in run_ids):
            files[name] = c.encoded(cache) if path == cache_path else path.read_bytes()
    return archive(files)


def review_summary(root):
    path = root / 'last_comparison.json'
    if not path.is_file():
        return {}
    report = c.read(path)
    rows = report['records']
    skills = [r for r in rows if r.get('skill_validation')]
    return {'totals': report['totals'], 'review_reasons': dict(Counter(reason for row in rows
        if row['readiness'] == 'REVIEW_REQUIRED' for reason in row['reasons'])),
        'skills': [{'record_id': r['record_id'], 'target': r.get('target'),
                    'comparisons': r['comparisons'], 'validation': r['skill_validation']} for r in skills],
        'historical_already_applied': report.get('historical_already_applied'),
        'publication_policy': 'GitHub_only; first_activation_requires_GUI_review'}


def local():
    # This producer cannot sign/publish even if --publish is passed to the old CLI.
    branch = SharedBranch(ROOT / 'scratch/c4_hybrid/github')
    shared = branch.get_shared('cloud.zip')
    sources = LocalSources(runner.HOME / 'sources', shared)
    pipeline = runner.Pipeline(sources=sources, publishing=False)
    result = pipeline.execute()
    files = candidate_files(runner.HOME) if (runner.HOME / 'last_comparison.json').is_file() else None
    if files:
        raw = archive(files)
        validate_candidates(raw)
        result['candidate_share'] = branch.put_shared('local.zip', raw)
    workflows = branch.api(gh.API + '/actions/workflows')
    result['cloud_workflows'] = [{k: w.get(k) for k in ('name', 'state', 'html_url')}
                                for w in workflows['workflows'] if w['path'] == '.github/workflows/c4-data.yml']
    result['schedule_recovery'] = 'gh workflow enable c4-data.yml; gh workflow run c4-data.yml (no dummy commit)'
    c.write(ROOT / 'scratch/c4_hybrid/local_result.json', result)
    return result


def cloud():
    if os.environ.get('GITHUB_ACTIONS') != 'true' or os.environ.get('GITHUB_REPOSITORY') != gh.REPO:
        raise gh.Blocked('Cloud coordinator requires the expected GitHub Actions repository')
    branch = SharedBranch(ROOT / 'scratch/c4_shared_api')
    restore_checkpoint(branch.get_shared('cloud.zip'))
    state_path = CLOUD / 'state.json'
    before = c.digest(state_path) if state_path.is_file() else None
    publishing = os.environ.get('C4_ENABLE_PUBLISH') == 'true'
    if publishing:
        secret = os.environ.pop('C4_SIGNING_KEY', '')
        if not secret:
            raise gh.Blocked('Enabled publisher requires existing Ed25519 GitHub environment secret')
        gh.KEY.parent.mkdir(parents=True, exist_ok=True)
        fd = os.open(gh.KEY, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
        with os.fdopen(fd, 'w', encoding='ascii') as out:
            out.write(secret)
        secret = None
        if not runner.signer_health():
            gh.KEY.unlink(missing_ok=True)
            raise gh.Blocked('Signing secret does not match existing public trust')
    try:
        sources = HybridSources(CLOUD / 'sources', branch.get_shared('local.zip'))
        pipeline = runner.Pipeline(CLOUD, sources=sources, publishing=publishing)
        result = pipeline.execute()
        summary = review_summary(CLOUD)
        c.write(ROOT / 'scratch/c4_cloud_summary.json', {'result': result, 'validation': summary,
            'independent_cloud': True, 'standard_runner': os.environ.get('RUNNER_OS'),
            'publisher_enabled': publishing, 'program_version': '1.0.0-beta.30.7'})
        if state_path.is_file() and c.digest(state_path) != before:
            result['shared_checkpoint'] = branch.put_shared('cloud.zip', cloud_checkpoint())
        summary_path = os.environ.get('GITHUB_STEP_SUMMARY')
        if summary_path:
            with open(summary_path, 'a', encoding='utf8') as out:
                out.write('## C4 data automation\n\n```json\n' + json.dumps({'status': result['status'],
                    'data_version': result.get('data_version'), 'auto_ready': summary.get('totals', {}).get('AUTO_READY', 0),
                    'publisher_enabled': publishing, 'independent_cloud': True,
                    'reason': result.get('reason', result.get('error'))}, ensure_ascii=False, indent=2) + '\n```\n')
        return result
    finally:
        # Only a short-lived cloud runtime receives a key, never checkpoint it.
        gh.KEY.unlink(missing_ok=True)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('mode', choices=('local', 'cloud'))
    args = p.parse_args()
    try:
        result = local() if args.mode == 'local' else cloud()
    except Exception as exc:
        result = {'status': 'FAILED', 'error': type(exc).__name__ + ': ' + str(exc)}
    # Only deliberately selected operational fields enter public logs.
    print(json.dumps({k: result[k] for k in ('status', 'data_version', 'auto_ready', 'reason', 'error',
        'detail_collection_requests', 'candidate_share', 'cloud_workflows', 'shared_checkpoint') if k in result}, ensure_ascii=False))
    return int(result['status'] in ('FAILED', 'BLOCKED'))


if __name__ == '__main__':
    raise SystemExit(main())
