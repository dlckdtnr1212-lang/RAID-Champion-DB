"""Bounded, resumable C-plan collector. Standard library; no AI/account/game access.

All outputs are confined to scratch/c_auto_collection. Existing collector HTML
parsers are imported without running their entry point. No operating data writes.
Run c_night_collect.cmd (8h ceiling), --smoke, --offline, --status or --self-test.
Completed tasks resume without downloading; --refresh revalidates HTTP caches.
"""
from __future__ import annotations

import argparse
import ast
import ctypes
import gzip
import hashlib
import http.client
import importlib.util
import json
import logging
import os
from pathlib import Path
import re
import shutil
import signal
import sys
import time
import urllib.parse as up
import urllib.robotparser
from collections import Counter
from datetime import datetime, timezone

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "scratch/c_auto_collection"
UA = "RAIDChampionDBCResearch/1.0"
LIMIT = 24 * 1024 * 1024
RESERVE = 5 * 1024**3
PATCH = "https://forum.plarium.com/raid-shadow-legends/843_news/43851_new-update-version-11-90-0/"
NEWS = "https://forum.plarium.com/raid-shadow-legends/843_news/"
INDEX = "https://hellhades.com/wp-json/hh-api/v3/champions?mode=full"
ALLOWED = {"forum.plarium.com", "hellhades.com", "ayumilove.net", "deadwoodjedi.com",
           "raidcodex.com", "raid.tf-gaming.com", "api.github.com", "raw.githubusercontent.com",
           "raid-support.plarium.com"}
STOP = False
LOG = logging.getLogger("c-collection")


def now():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def sha(data):
    return hashlib.sha256(data).hexdigest()


def encoded(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")


def read(path, default=None):
    return json.loads(Path(path).read_text(encoding="utf-8-sig")) if Path(path).exists() else default


def safe(path):
    path = Path(path).resolve()
    if path == OUT.resolve() or OUT.resolve() not in path.parents:
        raise ValueError("Output outside isolated collection: " + str(path))
    return path


def atomic(path, data):
    path = safe(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    with temp.open("wb") as f:
        f.write(data)
        f.flush()
        os.fsync(f.fileno())
    os.replace(temp, path)


def save(path, value):
    atomic(path, encoded(value) + b"\n")


def legacy():
    spec = importlib.util.spec_from_file_location("raid_existing_html_parser", ROOT / "nightly_collection/collector.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


OLD = legacy()


def text(value):
    return OLD.DOM(str(value or "")).root.text()


def literal_catalog(name):
    """Read an existing literal catalogue without importing any combat engine."""
    p = ROOT / "ui_web_proof/combat_gear_mastery_catalog.py"
    for node in ast.parse(p.read_text(encoding="utf-8-sig")).body:
        if isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id == name for t in node.targets):
            return ast.literal_eval(node.value)
    return None


class Finished(Exception):
    pass


class Skip(Exception):
    pass


class RunLock:
    """OS file lock releases after a crash; no stale PID lock removal required."""
    def __enter__(self):
        p = safe(OUT / "checkpoints/run.lock")
        p.parent.mkdir(parents=True, exist_ok=True)
        self.file = p.open("a+b")
        self.file.seek(0)
        if p.stat().st_size == 0:
            self.file.write(b"0")
            self.file.flush()
        self.file.seek(0)
        try:
            if os.name == "nt":
                import msvcrt
                msvcrt.locking(self.file.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(self.file, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError:
            self.file.close()
            raise Skip("Another C collector is running")
        return self

    def __exit__(self, *args):
        self.file.close()


class Awake:
    def __enter__(self):
        self.active = False
        if os.name == "nt":
            self.active = bool(ctypes.windll.kernel32.SetThreadExecutionState(0x80000001))
            if not self.active:
                LOG.warning("Windows sleep prevention unavailable")
        return self

    def __exit__(self, *args):
        if self.active:
            ctypes.windll.kernel32.SetThreadExecutionState(0x80000000)


class Client:
    def __init__(self, run):
        self.run = run
        self.cache = read(OUT / "checkpoints/http.json", {})
        self.connections, self.robots, self.last = {}, {}, {}
        self.downloaded = self.hits = 0

    def close(self):
        for c in self.connections.values():
            c.close()

    def request(self, url, conditional=True, policy=False, redirects=0):
        self.run.check()
        p = up.urlsplit(url)
        if p.scheme != "https" or p.hostname not in ALLOWED or p.username or p.port not in (None, 443):
            raise Skip("Unapproved origin: " + url)
        host = p.hostname
        if self.run.state["halted"].get(host):
            raise Skip("Source halted: " + host)
        if not policy:
            self.check_robots(url)
        delay = max(3.0, self.robots.get(host, (None, 0))[1])
        self.run.pause(max(0, self.last.get(host, 0) + delay - time.monotonic()))
        old = self.cache.get(url, {})
        headers = {"User-Agent": UA, "Accept-Encoding": "identity", "Accept": "*/*"}
        if conditional and old.get("path") and (OUT / old["path"]).exists():
            for h, key in (("If-None-Match", "etag"), ("If-Modified-Since", "last_modified")):
                if old.get(key):
                    headers[h] = old[key]
        timeout = min(25, max(0.1, self.run.deadline - time.monotonic()))
        c = self.connections.get(host)
        if c is None:
            c = self.connections[host] = http.client.HTTPSConnection(host, timeout=timeout)
        else:
            c.timeout = timeout
            if c.sock:
                c.sock.settimeout(timeout)
        try:
            self.last[host] = time.monotonic()
            c.request("GET", up.urlunsplit(("", "", p.path or "/", p.query, "")), headers=headers)
            resp = c.getresponse()
            status, rh = resp.status, dict((k.lower(), v) for k, v in resp.getheaders())
            parts, size = [], 0
            while True:
                self.run.check()
                b = resp.read(65536)
                if not b:
                    break
                size += len(b)
                if size > LIMIT:
                    raise Skip("Response exceeds 24MiB limit: " + url)
                parts.append(b)
            data = b"".join(parts)
        except BaseException:
            self.connections.pop(host, None)
            c.close()
            raise
        if status in (403, 429, 503):
            self.run.state["halted"][host] = {"status": status, "at": now(), "url": url,
                                               "retry_after": rh.get("retry-after")}
            self.run.checkpoint()
            raise Skip(f"Source stopped after HTTP {status}: {host}")
        if status in (301, 302, 303, 307, 308):
            target = up.urljoin(url, rh.get("location", ""))
            if up.urlsplit(target).hostname != host or redirects >= 3:
                raise Skip("Redirect requires review: " + target)
            result = self.request(target, conditional, policy, redirects + 1)
            self.cache[url] = {**result[1], "requested_url": url}
            save(OUT / "checkpoints/http.json", self.cache)
            return result
        if status == 304:
            b = (OUT / old["path"]).read_bytes()
            if sha(b) != old["sha256"]:
                raise Skip("Corrupt cached response: " + url)
            self.hits += 1
            return b, old
        if status == 404 and policy:
            data = b"User-agent: *\nDisallow:\n"
        elif status != 200:
            raise Skip(f"HTTP {status}: {url}")
        content_type = rh.get("content-type", "")
        if status == 200 and not policy and not any(v in content_type for v in ("text/", "json", "xml", "javascript")):
            raise Skip("Non-text content rejected: " + content_type)
        digest = sha(data)
        path = "raw/" + digest + ".bin"
        if not (OUT / path).exists():
            atomic(OUT / path, data)
        meta = {"source": url, "collected_at": now(), "sha256": digest, "path": path,
                "etag": rh.get("etag"), "last_modified": rh.get("last-modified"),
                "content_type": content_type, "bytes": len(data), "http_status": status,
                "game_version": None, "origin_kind": "public_http", "policy_document": policy}
        self.cache[url] = meta
        save(OUT / "checkpoints/http.json", self.cache)
        if not policy:
            self.downloaded += 1
        return data, meta

    def check_robots(self, url):
        p = up.urlsplit(url)
        if p.hostname not in self.robots:
            b, _ = self.request(f"https://{p.hostname}/robots.txt", policy=True)
            robot = urllib.robotparser.RobotFileParser()
            robot.parse(b.decode("utf-8", "replace").splitlines())
            delay = robot.crawl_delay(UA) or robot.crawl_delay("*") or 0
            rr = robot.request_rate(UA) or robot.request_rate("*")
            if rr:
                delay = max(delay, rr.seconds / rr.requests)
            self.robots[p.hostname] = robot, delay
        if not self.robots[p.hostname][0].can_fetch(UA, url):
            raise Skip("robots.txt disallows: " + url)

    def fetch(self, url):
        old = self.cache.get(url)
        if self.run.args.offline or (old and not self.run.args.refresh):
            if old and (OUT / old["path"]).exists():
                b = (OUT / old["path"]).read_bytes()
                if sha(b) == old["sha256"]:
                    self.hits += 1
                    return b, old
                self.cache.pop(url, None)
            if self.run.args.offline:
                raise Skip("Offline cache miss: " + url)
        # Reuse exact old static/reference URLs, but always refresh newly targeted
        # champion APIs/pages and official patches through this run's own cache.
        if not self.run.args.refresh and not any(s in url for s in ("wp-json/", "/raid/champions/", "forum.plarium")):
            for folder in (ROOT / "nightly_collection/cache", ROOT / "night_development_output/combat_20261025/network/cache"):
                key = sha(url.encode())
                mp, bp = folder / (key + ".json"), folder / (key + ".html.gz")
                if mp.exists() and bp.exists():
                    m = read(mp, {})
                    b = gzip.decompress(bp.read_bytes())
                    if sha(b) != m.get("sha256"):
                        continue
                    path = "raw/" + sha(b) + ".bin"
                    atomic(OUT / path, b)
                    meta = {"source": url, "collected_at": m.get("collected_at"), "sha256": sha(b),
                            "path": path, "game_version": None, "bytes": len(b),
                            "origin_kind": "reused_existing_local_cache", "baseline_metadata": m}
                    self.cache[url] = meta
                    save(OUT / "checkpoints/http.json", self.cache)
                    self.hits += 1
                    return b, meta
        return self.request(url)


def protect():
    # Snapshot only application/user baselines touched by comparison, not a corpus audit.
    paths = [ROOT / "data/champions_collected.json", ROOT / "data/bulk_stage11/champion_skills_ko_game.json",
             ROOT / "data/bulk_stage11/artifact_sets_ui.json"]
    for base in (ROOT / "user_data", ROOT / "ui_web_proof/user_data"):
        if base.exists():
            paths.extend(base.rglob("*.json"))
    for name in ("teams.json", "owned_champions.json", "settings.json"):
        if (ROOT / name).exists():
            paths.append(ROOT / name)
    return {str(p.relative_to(ROOT)): sha(p.read_bytes()) for p in paths if p.is_file()}


def comparison(old, new, matched=True, uncertain=False):
    if not matched:
        return "UNMATCHED"
    if uncertain:
        return "UNCERTAIN"
    if old is None:
        return "NEW"
    return "UNCHANGED" if old == new else "CHANGED"


class Collector:
    def __init__(self, args):
        self.args = args
        self.started = now()
        self.deadline = time.monotonic() + min(8, max(0.0001, args.max_hours)) * 3600
        self.state = read(OUT / "checkpoints/state.json", {"tasks": {}, "halted": {}, "created_at": now()})
        if args.refresh:
            self.state["tasks"] = {}
        if args.retry_failed:
            self.state["halted"] = {}
            self.state["tasks"] = {k: v for k, v in self.state["tasks"].items() if v["status"] == "done"}
        self.client = Client(self)
        self.records = read(OUT / "normalized/records.json", {})
        self.records = {k: r for k, r in self.records.items() if r.get("game_hero_id") != 0
                        and not (r["kind"] == "blessing" and "description_and_awakening_raw" in r["new_value"]
                                 and not r.get("source_anchor"))}
        self.selected = []
        self.before = protect()
        self.champs = {}
        manifest = read(ROOT / "nightly_collection/manifest.json", {})
        self.manifest = {str(t["id"]): t for t in manifest.get("targets", [])}
        for c in read(ROOT / "data/champions_collected.json", {}).get("champions", []):
            if c.get("champion_id") or c.get("id"):
                self.champs[str(c.get("champion_id") or c["id"])] = c
        # Existing manifest's local_index is an explicit stable identity, not a name join.
        collected = read(ROOT / "data/champions_collected.json", {}).get("champions", [])
        for cid, t in self.manifest.items():
            i = t.get("local_index")
            if cid not in self.champs and isinstance(i, int) and 0 <= i < len(collected):
                if collected[i].get("name_en") == t.get("name_en"):
                    self.champs[cid] = collected[i]
        self.game = read(ROOT / "data/bulk_stage11/champion_skills_ko_game.json", {})
        self.hero_map = {}
        for c in self.game.get("champions", []):
            for v in c.get("game_variants", []):
                self.hero_map.setdefault(str(v["game_hero_id"]), set()).add(c["champion_id"])
        self.skill_old = {}
        csi = ROOT / "night_development_output/combat_20261025/linked_candidates/combat_skill_inputs.json"
        for r in read(csi, {}).get("records", []):
            sid = r.get("skill_id") or r.get("source_skill_id")
            if sid is not None:
                self.skill_old[(str(r.get("game_hero_id")), str(sid))] = r
        self.gear = read(ROOT / "data/bulk_stage11/artifact_sets_ui.json", {}).get("entries", {})
        self.blessings = literal_catalog("OFFICIAL_BLESSINGS_RAW") or []
        self.patch_texts = []

    def check(self):
        if STOP or time.monotonic() >= self.deadline:
            raise Finished("interrupted" if STOP else "deadline")
        if shutil.disk_usage(OUT).free < RESERVE:
            raise Finished("disk_reserve_5GiB")

    def pause(self, seconds):
        until = time.monotonic() + seconds
        while time.monotonic() < until:
            self.check()
            time.sleep(min(.25, max(0, until - time.monotonic())))

    def checkpoint(self):
        self.state.update(updated_at=now(), pid=os.getpid())
        save(OUT / "checkpoints/state.json", self.state)

    def emit(self, kind, identity, value, meta, old=None, matched=True, uncertain=False, **extra):
        self.check()
        key = sha(encoded([kind, identity, meta["source"]]))
        rec = {"kind": kind, "identity": identity, "classification": comparison(old, value, matched, uncertain),
               "source": meta["source"], "collected_at": meta["collected_at"],
               "game_version": meta.get("game_version"), "raw_value": value, "old_value": old,
               "new_value": value, "champion_id": None, "skill_id": None,
               "verification": "source_candidate_requires_review" if not uncertain else "unconfirmed",
               "raw_file_sha256": meta["sha256"], "raw_file": meta["path"], **extra}
        self.records[key] = rec

    def persist(self):
        # Records first, task completion second: crash recovery can only repeat idempotent parsing.
        save(OUT / "normalized/records.json", self.records)

    def task(self, name, action, replay=False):
        self.check()
        task = self.state["tasks"].get(name, {})
        if task.get("status") == "done":
            if not replay:
                return
            task = {}
        if task.get("attempts", 0) >= 3:
            return
        if task.get("status") == "blocked":
            return
        for attempt in range(task.get("attempts", 0), 3):
            self.check()
            self.state["current_task"] = name
            self.state["tasks"][name] = {"status": "running", "attempts": attempt + 1, "at": now()}
            self.checkpoint()
            LOG.info("%s", name)
            try:
                action()
                self.persist()
                self.state["tasks"][name].update(status="done", finished_at=now())
                self.checkpoint()
                return
            except Finished:
                # Deadline/interrupt must not spend a failure attempt or lose resume eligibility.
                self.state["tasks"][name].update(status="pending", attempts=attempt)
                raise
            except Skip as e:
                self.state["tasks"][name].update(status="blocked", error=str(e))
                LOG.warning("%s", e)
                self.persist()
                self.checkpoint()
                return
            except Exception as e:
                self.state["tasks"][name].update(status="failed", error=f"{type(e).__name__}: {e}")
                LOG.exception("Task failed: %s", name)
                self.persist()
                self.checkpoint()
                if attempt < 2:
                    self.pause(2 ** (attempt + 1))

    def document(self, url):
        b, meta = self.client.fetch(url)
        return OLD.DOM(b.decode("utf-8", "replace")), meta

    def patch(self, url):
        doc, meta = self.document(url)
        headings = [n for n in doc.nodes if n.tag in ("h2", "h3", "h4") and n.text()]
        title = next((n.text() for n in headings if n.tag == "h2"), "")
        ver = re.search(r"(?:Version|Update)\s+(\d+\.\d+(?:\.\d+)?)", title, re.I)
        meta = {**meta, "game_version": ver[1] if ver else None}
        # Main announcement only: never mix forum comments into patch facts.
        h = next((n for n in headings if n.tag == "h3"), None)
        if not h:
            raise Skip("Patch article headings unavailable: " + url)
        container = h.parent
        content = container.text()
        self.patch_texts.append(content)
        dates = [{"field": n.attrs, "value": n.attrs.get("content")}
                 for n in doc.nodes if n.tag == "meta" and re.search("publish|modified", str(n.attrs), re.I)]
        self.emit("patch_document", url, {"title": title, "text": content, "announcement_dates": dates,
                  "application_date": None, "date_status": "not_inferred_from_announcement",
                  "announced_ai_count": 21 if url == PATCH else None,
                  "ai_21_details_verified": False}, meta)
        nodes = container.all()
        hs = [n for n in nodes if n.tag in ("h3", "h4")]
        for i, heading in enumerate(hs):
            end = hs[i+1].order if i+1 < len(hs) else float("inf")
            paragraphs = [n.text() for n in nodes if heading.order < n.order < end and n.tag in ("p", "li")]
            paragraphs = list(dict.fromkeys(p for p in paragraphs if p))
            if not paragraphs:
                continue
            body = "\n".join(paragraphs)
            self.emit("patch_section", [url, heading.text()], {"heading": heading.text(), "text": body,
                      "announcement_date": dates or None, "application_date": None}, meta)
        save(OUT / "normalized/patch_targets.json", self.patch_targets())

    def patch_targets(self):
        joined = "\n".join(r["new_value"].get("text", "") for r in self.records.values()
                           if r["kind"] == "patch_document")
        return {"text": joined, "identity_rule": "Only explicit source hero IDs; names are selection hints only"}

    def news(self, url):
        doc, _ = self.document(url)
        links = {}
        for n in doc.nodes:
            if n.tag != "a":
                continue
            u = up.urljoin(url, n.attrs.get("href", ""))
            if not u.startswith(NEWS) or not n.text():
                continue
            if re.search(r"new-update|update-highlights|smoother|champions|coalition|rebalance|raid-digest", u, re.I):
                links[u] = n.text()
        for u, title in list(links.items())[:18]:
            self.task("patch:" + u, lambda u=u: self.patch(u))

    def repository(self, repo):
        b, meta = self.client.fetch("https://api.github.com/repos/" + repo)
        x = json.loads(b)
        info = {k: x.get(k) for k in ("full_name", "pushed_at", "updated_at", "default_branch", "license")}
        info.update(game_version=None, data_recency="unknown_do_not_treat_as_current",
                    license_status="not_declared" if not x.get("license") else "inspect_license_before_reuse")
        self.emit("repository_metadata", repo, info, meta)
        # Both nominated repositories are historical. Metadata is useful; do not
        # download hundreds of old individual champions already covered locally.
        pushed = (x.get("pushed_at") or "")[:10]
        if not pushed or pushed < "2026-10-01":
            return
        branch = x["default_branch"]
        b, tree_meta = self.client.fetch(f"https://api.github.com/repos/{repo}/git/trees/{branch}?recursive=1")
        tree = json.loads(b)
        save(OUT / "normalized" / (repo.replace("/", "_") + "_tree.json"), {"metadata": info, "tree": tree})
        for item in tree.get("tree", []):
            p = item["path"]
            if item.get("type") == "blob" and "/" not in p and p.endswith((".json", ".csv", ".ini")) and item.get("size", LIMIT) < LIMIT:
                self.task("repository_file:" + repo + "/" + p,
                          lambda p=p: self.repo_file(repo, branch, p, info))

    def repo_file(self, repo, branch, path, info):
        b, meta = self.client.fetch(f"https://raw.githubusercontent.com/{repo}/{branch}/" + up.quote(path))
        # Unknown public schema/version/license stays an explicitly uncertain candidate.
        value = json.loads(b) if path.endswith(".json") else b.decode("utf-8", "replace")
        self.emit("repository_data", [repo, path], {"data": value, "repository": info}, meta, uncertain=True)

    def champion_index(self):
        b, meta = self.client.fetch(INDEX)
        x = json.loads(b)
        rows = x.get("champions") if isinstance(x, dict) else x
        if not isinstance(rows, list) or not rows:
            raise ValueError("Unexpected public champion index schema")
        patch_text = self.patch_targets()["text"].casefold()
        priority = {"big un", "big 'un", "big ‘un", "brakus the shifter", "rhazin scarhide", "the primogenitor"}
        selected = {}
        for row in rows:
            self.check()
            hid = str(row.get("heroId", ""))
            if not hid.isdigit() or not row.get("champion"):
                continue
            if int(hid) <= 0:
                self.emit("champion_unlinked", [row.get("id"), row["champion"]],
                          {k: row.get(k) for k in ("id", "heroId", "champion", "url")}, meta,
                          matched=False, reason="placeholder_hero_id_no_automatic_merge")
                continue
            linked = self.hero_map.get(hid, set())
            name = OLD.norm(row["champion"])
            reason = []
            if not linked:
                reason.append("new_source_hero_id")
            if name in priority or (len(name) >= 6 and name in patch_text):
                reason.append("patch_named")
            if len(linked) == 1:
                old = self.champs.get(next(iter(linked)), {})
                for key, src in (("rarity", "rarity"), ("role", "role"), ("affinity", "affinity_index")):
                    if old.get(key) and row.get(src) and OLD.canonical_basic(key, old[key]) != OLD.canonical_basic(key, row[src]):
                        reason.append("identity_field_changed")
            if reason:
                selected.setdefault(hid, {"row": row, "reasons": reason})
        targets = sorted(selected.values(), key=lambda v: ("patch_named" not in v["reasons"],
                         OLD.norm(v["row"]["champion"]) not in priority,
                         str(v["row"]["heroId"]) != "976",
                         "new_source_hero_id" not in v["reasons"], str(v["row"]["heroId"])))
        # A hard guard explicitly prevents turning index discovery into a 1,049 crawl.
        self.selected = targets[:self.args.max_champions]
        save(OUT / "normalized/selected_champions.json", {"targets": self.selected,
             "total_candidates": len(targets), "deferred": targets[self.args.max_champions:], "index_provenance": meta})

    def champion(self, target):
        row = target["row"]
        hid = str(row["heroId"])
        ids = self.hero_map.get(hid, set())
        cid = next(iter(ids)) if len(ids) == 1 else None
        old = self.champs.get(cid, {})
        new = {"name_en": text(row["champion"]), "name_ko": old.get("name_ko") or None,
               "rarity": row.get("rarity"), "affinity": row.get("affinity_index"),
               "faction": row.get("faction_index"), "role": row.get("role"), "game_hero_id": int(hid)}
        im = self.client.cache[INDEX]
        for field, value in new.items():
            if value is None or field in ("name_ko", "game_hero_id"):
                continue
            prior = old.get(field)
            if field in ("role", "faction", "rarity", "affinity"):
                prior = OLD.canonical_basic(field, prior) if prior else None
                value = OLD.canonical_basic(field, value)
            self.emit("champion_field", [hid, field], value, im, prior,
                      uncertain=field == "name_en" and bool(cid) and value != prior, champion_id=cid,
                      game_hero_id=int(hid), identity_status="verified_game_id" if cid else "new_external_id_unmapped")
        # Source supplies exact hero ID; new source IDs are retained without inventing local champ IDs.
        model = int(hid) - int(hid) % 10
        b, meta = self.client.fetch(f"https://hellhades.com/wp-json/hh-api/v3/raid/forms/{model}")
        forms = json.loads(b)
        forms = [f for f in forms if str(f.get("heroid")) == hid]
        if not forms:
            raise ValueError("No exact hero ID in forms response")
        for form in forms:
            self.emit("champion_form", [hid, form.get("form")], form, meta,
                      champion_id=cid, game_hero_id=int(hid),
                      numerical_scope="unscaled_model_coefficients_not_max_level_stats")
            query = up.urlencode({"skills": form["skills"], "model": form["model"], "heroid": hid})
            url = "https://hellhades.com/wp-json/hh-api/v3/skills?" + query
            self.task("skills:" + url, lambda url=url, form=form: self.skills(url, hid, cid, form))

    def skills(self, url, hid, cid, form):
        b, meta = self.client.fetch(url)
        rows = json.loads(b)
        if not isinstance(rows, list) or not rows:
            raise ValueError("Unexpected skills schema")
        expected = set(str(form["skills"]).split(","))
        for s in rows:
            sid = str(s.get("id", ""))
            if sid not in expected or not sid.isdigit():
                self.emit("skill_unlinked", [hid, sid], s, meta, matched=False, game_hero_id=int(hid))
                continue
            prior_raw = self.skill_old.get((hid, sid), {}).get("raw_source_skill")
            fields = ("id", "name", "description", "type", "cooldown", "books", "multiplier", "abilities", "unity")
            prior = {k: prior_raw.get(k) for k in fields} if prior_raw else None
            value = {k: s.get(k) for k in fields}
            # Compare the same raw public schema; Korean vs English is not a value delta.
            self.emit("skill", [hid, sid, form.get("form")], value, meta, prior,
                      champion_id=cid, skill_id=int(sid), game_hero_id=int(hid),
                      skill_id_link="exact_id_in_source_hero_form", form=form.get("form"),
                      fields={"name": s.get("name"), "description": text(s.get("description")),
                              "type": s.get("type"), "cooldown_raw": s.get("cooldown"),
                              "books": s.get("books"), "multipliers_raw": s.get("multiplier"),
                              "abilities": s.get("abilities"),
                              "hits_raw": [m.get("attacks") for m in (s.get("multiplier") or []) if isinstance(m, dict)]},
                      engine_use="prohibited_until_review")
            if not s.get("damage") and not s.get("multiplier") and s.get("type") != "Passive":
                self.emit("skill_uncertainty", [hid, sid, "multiplier"], {"field": "multiplier", "value": None,
                          "reason": "No explicit damage coefficient in this source response"}, meta,
                          uncertain=True, champion_id=cid, skill_id=int(sid), game_hero_id=int(hid))

    def champion_page(self, row, cid, old):
        doc, meta = self.document(row["url"])
        parsed = OLD.parse_hellhades(doc, [row])
        for field in ("base_stats", "aura"):
            if parsed.get(field):
                self.emit("champion_" + field, [row["heroId"], field], parsed[field], meta,
                          old.get("stats") if field == "base_stats" else old.get("aura"),
                          uncertain=field == "base_stats", champion_id=cid, game_hero_id=row["heroId"])

    def aegis(self, url, category):
        doc, meta = self.document(url)
        page = next((n.attrs["data-page"] for n in doc.nodes if "data-page" in n.attrs), None)
        if not page:
            raise ValueError("Public embedded data-page absent")
        props = json.loads(page).get("props", {})
        lists = [(k, v) for k, v in props.items() if isinstance(v, list) and v and isinstance(v[0], dict)
                 and re.search("relic|gem|stone|bless|set", k, re.I)]
        if not lists:
            raise ValueError("No expected structured equipment records")
        for key, rows in lists:
            for row in rows:
                if row.get("id") is None:
                    continue
                self.emit(category, [key, row["id"]], row, meta,
                          source_updated_at=(row.get("guide") or {}).get("updated_at"), source_id_namespace="raid_aegis")

    def catalogue(self, url, category):
        doc, meta = self.document(url)
        if category == "gemstone_detail":
            cards = [n for n in doc.nodes if n.has_class("rl-stone-body")]
            if not cards:
                raise ValueError("Gemstone source cards missing")
            for card in cards:
                h = card.all("h3")
                if h:
                    self.emit(category, h[0].text(), {"name": h[0].text(), "source_text": card.text(),
                              "explanation_status": "includes_site_explanation_not_battle_verified"}, meta)
            return
        prefix = up.urlsplit(url).path
        targets = {}
        skipped_existing = []
        for n in doc.nodes:
            if n.tag != "a":
                continue
            href = n.attrs.get("href", "")
            if href.startswith(prefix) and href != prefix and n.has_class("rl-card"):
                u = up.urljoin(url, href)
                targets[u] = n.text()
        if not targets:
            # Other catalogues expose detail links with a card class or nested heading.
            for n in doc.nodes:
                if n.tag == "a" and n.attrs.get("href", "").startswith(prefix):
                    href = n.attrs["href"]
                    if re.fullmatch(re.escape(prefix) + r"[^/]+/", href) and href != prefix and n.text():
                        # Existing bilingual set descriptions need no full redownload.
                        # Keep the single fetched index's current summary for review.
                        names = [c.text() for c in n.all() if c.has_class("gx-card-name")]
                        known = [g for g in self.gear.values() if names and g.get("name_en") == names[0]]
                        if category == "artifact_set" and len(known) == 1:
                            skipped_existing.append({"source_name": names[0], "source_summary": n.text(),
                                                     "game_set_id": known[0]["game_set_id"], "detail_downloaded": False})
                            self.emit("artifact_set_review", known[0]["game_set_id"], {"source_summary": n.text()}, meta,
                                      known[0], uncertain=True, reason="cross_language_effect_requires_review")
                        else:
                            targets[up.urljoin(url, href)] = n.text()
        save(OUT / "normalized" / (category + "_targets.json"), {"targets": targets,
             "existing_details_skipped": skipped_existing, "provenance": meta})
        if not targets and not skipped_existing:
            raise ValueError("Catalogue has no usable detail links")
        processed = 0
        for u, label in list(targets.items())[:160]:
            if category == "boss" and not re.search("demon|clan.boss|hydra|chimera", u + " " + label, re.I):
                continue
            self.task(category + ":" + u, lambda u=u: self.detail(u, category))
            processed += 1
            if self.args.smoke and processed >= 1:
                break

    def reference_article(self, url, category):
        doc, meta = self.document(url)
        main = next((n for n in doc.nodes if n.has_class("entry-content")), None)
        if not main:
            raise ValueError("Reference entry-content missing")
        if category == "blessing":
            count = 0
            for h in main.all("h4"):
                anchor = h.attrs.get("id")
                cell = h.ancestor(lambda n: n.tag == "td")
                if not anchor or cell is None or len(cell.text()) < 30:
                    continue
                name = h.text()
                body = cell.text().split("Who should use this blessing?")[0].strip()
                known = [b for b in getattr(self, "blessings", []) if b.get("name_en") == name]
                self.emit("blessing", anchor, {"name": name, "description_and_awakening_raw": body,
                          "numeric_conversion": "none"}, meta, source_id_namespace="ayumilove_exact_anchor",
                          source_anchor=anchor, existing_exact_label_metadata=known,
                          scope="new_source_description_candidate_not_a_new_blessing_type")
                count += 1
            if not count:
                raise ValueError("No blessing table records parsed")
            return
        # Retain combat headings and their text, never convert team stat
        # recommendations into boss base stats.
        nodes = main.all()
        hs = [n for n in nodes if n.tag in ("h2", "h3", "h4")]
        count = 0
        for i, h in enumerate(hs):
            if not re.search("skill|affinity|damage|buff|debuff|immun|mechanic|turn", h.text(), re.I):
                continue
            end = hs[i+1].order if i+1 < len(hs) else float("inf")
            parts = list(dict.fromkeys(n.text() for n in nodes if h.order < n.order < end
                                      and n.tag in ("p", "li") and n.text()))
            if parts:
                self.emit("boss_rule", [url, h.text()], {"heading": h.text(), "text": parts}, meta,
                          uncertain=True, numerical_scope="source_claims_no_boss_stat_inference")
                count += 1
        if not count:
            raise ValueError("No scoped combat rules parsed")

    def detail(self, url, category):
        doc, meta = self.document(url)
        main = next((n for n in doc.nodes if n.tag == "main"), None)
        if not main:
            raise ValueError("Article main container missing")
        hs = [n for n in main.all() if n.tag in ("h1", "h2", "h3") and n.text()]
        title = next((n.text() for n in hs if n.tag == "h1"), None)
        if not title:
            raise ValueError("Article title missing")
        tables = []
        for table in main.all("table"):
            rows = [[c.text() for c in tr.children if isinstance(c, OLD.Node) and c.tag in ("th", "td")]
                    for tr in table.all("tr")]
            tables.append({"caption": " ".join(n.text() for n in table.all("caption")), "rows": rows})
        sections = []
        nodes = main.all()
        for i, h in enumerate(hs):
            end = hs[i+1].order if i+1 < len(hs) else float("inf")
            parts = list(dict.fromkeys(n.text() for n in nodes if h.order < n.order < end
                                      and n.tag in ("p", "li", "dd") and n.text()))
            if parts:
                sections.append({"heading": h.text(), "paragraphs": parts})
        if not tables and not sections:
            raise ValueError("No useful tables or article sections")
        identity = up.urlsplit(url).path
        prior = None
        if category == "artifact_set":
            exact = [g for g in self.gear.values() if g.get("name_en") == title]
            if len(exact) == 1:
                prior = exact[0]
        # Source path IDs are kept in their own namespace. No guessed enum/name merge.
        self.emit(category, identity, {"title": title, "tables": tables, "sections": sections}, meta,
                  prior, uncertain=bool(prior), numerical_status="source_claims_not_independently_verified",
                  boss_scope="tainted_and_normal_demon_lord_must_remain_separate" if category == "boss" else None)

    def run(self):
        self.task("official_11.90", lambda: self.patch(PATCH))
        if not self.args.smoke:
            for page in (NEWS, NEWS + "2/", NEWS + "3/"):
                self.task("news:" + page, lambda page=page: self.news(page), replay=True)
        # Re-read cached index when its discovery task is complete; selection is durable.
        self.task("champion_index", self.champion_index, replay=True)
        if not self.selected:
            self.selected = read(OUT / "normalized/selected_champions.json", {}).get("targets", [])
        for target in self.selected[:1 if self.args.smoke else self.args.max_champions]:
            hid = str(target["row"]["heroId"])
            self.task("champion:" + hid, lambda target=target: self.champion(target), replay=True)
            if not self.args.smoke and target["row"].get("url", "").startswith("https://hellhades.com/raid/champions/"):
                ids = self.hero_map.get(hid, set())
                cid = next(iter(ids)) if len(ids) == 1 else None
                self.task("champion_page:" + hid, lambda target=target, cid=cid:
                          self.champion_page(target["row"], cid, self.champs.get(cid, {})))
        if self.args.smoke:
            self.task("aegis_relics", lambda: self.aegis("https://raid.tf-gaming.com/relics", "relic"))
            self.task("representative_relic_detail", lambda: self.detail("https://raidcodex.com/relics/andromedas-diadem/", "relic_detail"))
            self.task("representative_boss", lambda: self.detail("https://raidcodex.com/modes/demon-lord/", "boss"))
            self.task("representative_blessings", lambda: self.reference_article("https://ayumilove.net/raid-shadow-legends-champion-blessings-guide/", "blessing"))
            self.task("representative_gems", lambda: self.aegis("https://raid.tf-gaming.com/relics/gemstones", "gemstone"))
            return
        for repo in ("raidchamps/static-data", "PatPat1567/RaidShadowLegendsData"):
            self.task("repository:" + repo, lambda repo=repo: self.repository(repo), replay=True)
        for url, category in (("https://raid.tf-gaming.com/relics", "relic"),
                              ("https://raid.tf-gaming.com/relics/gemstones", "gemstone")):
            self.task("aegis:" + url, lambda url=url, category=category: self.aegis(url, category))
        for url, category in (("https://raidcodex.com/relics/", "relic_detail"),
                              ("https://raidcodex.com/relics/stones/", "gemstone_detail"),
                              ("https://raidcodex.com/sets/", "artifact_set"),
                              ("https://raidcodex.com/modes/", "boss")):
            self.task("catalogue:" + url, lambda url=url, category=category: self.catalogue(url, category), replay=True)
        for url, category in (("https://ayumilove.net/raid-shadow-legends-champion-blessings-guide/", "blessing"),
                              ("https://ayumilove.net/raid-shadow-legends-champion-ranking-in-clan-boss/", "boss_rule"),
                              ("https://ayumilove.net/raid-shadow-legends-hydra-clan-boss-guide/", "boss_rule")):
            self.task(category + ":" + url, lambda url=url, category=category: self.reference_article(url, category))

    def summarize(self, status):
        self.persist()
        records = list(self.records.values())
        for name, subset in (("changes", [r for r in records if r["classification"] in ("NEW", "CHANGED")]),
                             ("unmatched", [r for r in records if r["classification"] == "UNMATCHED"]),
                             ("uncertain", [r for r in records if r["classification"] == "UNCERTAIN"])):
            folder = "unmatched" if name == "unmatched" else "changes"
            atomic(OUT / folder / (name + ".jsonl"), b"".join(encoded(r) + b"\n" for r in subset))
        skills = [r for r in records if r["kind"] in ("skill", "skill_unlinked")]
        linked = sum(r["skill_id"] is not None for r in skills)
        useful = [r for r in records if r["classification"] in ("NEW", "CHANGED") and r["kind"] not in
                  ("repository_metadata", "repository_data", "champion_form", "patch_document")]
        champs_new = {r.get("game_hero_id") for r in records if r["kind"] == "champion_field" and r["classification"] == "NEW" and r.get("champion_id") is None}
        champs_changed = {r.get("game_hero_id") for r in records if r["kind"].startswith("champion_") and r["classification"] == "CHANGED" and r.get("champion_id")}
        for r in skills:
            if r["classification"] == "CHANGED" and r.get("champion_id"):
                champs_changed.add(r.get("game_hero_id"))
        after = protect()
        preserved = self.before == after
        summary = {"started_at": self.started, "finished_at": now(), "status": status,
                   "mode": "smoke" if self.args.smoke else "night", "max_hours": min(8, self.args.max_hours),
                   "A_raw_downloaded_this_run": self.client.downloaded,
                   "A_unique_cached_payloads": len({m["sha256"] for u, m in self.client.cache.items() if not m.get("policy_document") and "/robots.txt" not in u}),
                   "B_new_or_changed_useful_candidate_records": len(useful),
                   "C_new_external_champion_ids": len(champs_new),
                   "D_changed_linked_champions": len(champs_changed),
                   "E_new_changed_skills": len({(r.get("game_hero_id"), r["skill_id"]) for r in skills if r["classification"] in ("NEW", "CHANGED")}),
                   "F_exact_source_skill_id_link": {"linked": linked, "total": len(skills), "rate": linked / len(skills) if skills else None},
                   "G_equipment_records": dict(Counter(r["kind"] for r in useful if r["kind"] in ("relic", "relic_detail", "gemstone", "gemstone_detail", "artifact_set", "blessing"))),
                   "G_blessing_scope": "Source description/awakening detail candidates; existing 30-type catalogue is preserved. No claim of 30 new blessing types.",
                   "H_boss_records": sum(r["kind"] in ("boss", "boss_rule") for r in records),
                   "H_confirmed_new_boss_numeric_stats": 0,
                   "I_uncertain_records": sum(r["classification"] == "UNCERTAIN" for r in records),
                   "I_source_version_unconfirmed_records": sum(r.get("game_version") is None for r in records),
                   "J_restricted_failed_tasks": {k: v for k, v in self.state["tasks"].items() if v["status"] in ("failed", "blocked")},
                   "J_halted_sources": self.state["halted"],
                   "K_outputs": ["normalized/records.json", "changes/changes.jsonl", "changes/uncertain.jsonl", "unmatched/unmatched.jsonl"],
                   "classification_counts": dict(Counter(r["classification"] for r in records)),
                   "protected_baselines_unchanged": preserved, "protected_file_count": len(self.before),
                   "http_cache_hits_this_run": self.client.hits,
                   "record_scope": "Review candidates only. No operating DB application. Unknown source versions remain null; IDs use source namespaces.",
                   "limitations": ["No claim of complete 11.90 AI21 details until a dated exact source is found",
                                   "New source hero ID is not automatically a new playable champion; review required",
                                   "No fuzzy merge, max-stat scaling guesses or unverified numeric conversion",
                                   "Fixed finite queue; finishes early when exhausted; source blocks require explicit --retry-failed"]}
        save(OUT / "reports/summary.json", summary)
        if self.args.smoke:
            save(OUT / "reports/smoke_result.json", summary)
        save(OUT / "reports/protection.json", {"before": self.before, "after": after, "unchanged": preserved})
        self.state.update(status=status, current_task=None)
        self.checkpoint()
        LOG.info("Saved %s | useful candidates=%d | skills=%d | protected=%s", OUT / "reports/summary.json", len(useful), summary["E_new_changed_skills"], preserved)
        return 0 if preserved and (useful or status in ("deadline", "interrupted")) else 2


def self_test():
    assert comparison(None, 4) == "NEW"
    assert comparison(4, 5) == "CHANGED"
    assert comparison(4, 4) == "UNCHANGED"
    assert comparison(None, 4, matched=False) == "UNMATCHED"
    assert comparison(None, None, uncertain=True) == "UNCERTAIN"
    for p in (ROOT / "data/champions.json", OUT / "../bad.json"):
        try:
            safe(p)
        except ValueError:
            pass
        else:
            raise AssertionError("Write guard failed")
    assert OLD.norm("Big 'Un") != OLD.norm("Big Un")
    assert OLD.DOM("<p>HP <b>1,000</b></p>").root.text() == "HP 1,000"
    # A recommendation/stat table must never become a blessing record.
    from types import SimpleNamespace
    doc = OLD.DOM('<div class="entry-content"><table><tr><td>Rare</td><td>Epic</td><td>HP 1000</td></tr>'
                  '<tr><td></td><td><h4 id="miracle-heal">Miracle Heal</h4><p>Restores destroyed HP.</p>'
                  '<h4>Awakening Level</h4><p>1 star: 5%</p><h4>Who should use this blessing?</h4><p>Opinion</p>'
                  '</td></tr></table></div>')
    emitted = []
    fake = SimpleNamespace(document=lambda url: (doc, {}), emit=lambda *a, **kw: emitted.append((a, kw)))
    Collector.reference_article(fake, "https://example.invalid", "blessing")
    assert len(emitted) == 1 and emitted[0][0][1] == "miracle-heal"
    assert "Opinion" not in emitted[0][0][2]["description_and_awakening_raw"]
    expired = Collector.__new__(Collector)
    expired.deadline = time.monotonic() - 1
    try:
        expired.check()
    except Finished as e:
        assert str(e) == "deadline"
    else:
        raise AssertionError("Deadline guard failed")
    # A completed parent must still replay its child discovery during resume.
    parent = Collector.__new__(Collector)
    parent.state = {"tasks": {"parent": {"status": "done", "attempts": 1}}}
    parent.check = parent.checkpoint = parent.persist = lambda: None
    calls = []
    parent.task("parent", lambda: calls.append("replayed"), replay=True)
    assert calls == ["replayed"]
    print("PASS: classification, IDs, write guard, HTML/blessing parser, deadline, nested resume")


def main():
    global STOP
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--max-hours", type=float, default=8)
    ap.add_argument("--max-champions", type=int, default=100)
    for flag in ("smoke", "offline", "status", "self-test", "refresh", "retry-failed"):
        ap.add_argument("--" + flag, action="store_true")
    args = ap.parse_args()
    if not 0 < args.max_hours <= 8 or not 1 <= args.max_champions <= 150:
        ap.error("max-hours must be (0,8], max-champions must be [1,150]")
    if args.self_test:
        self_test()
        return 0
    if args.status:
        print(json.dumps(read(OUT / "reports/summary.json", {"status": "not_started"}), ensure_ascii=False, indent=2))
        return 0
    OUT.mkdir(parents=True, exist_ok=True)
    for folder in ("raw", "normalized", "changes", "unmatched", "checkpoints", "logs", "reports"):
        (OUT / folder).mkdir(exist_ok=True)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s",
                        handlers=[logging.StreamHandler(sys.stdout), logging.FileHandler(OUT / "logs/collector.log", encoding="utf-8")])
    def stop(*_):
        global STOP
        STOP = True
    signal.signal(signal.SIGINT, stop)
    signal.signal(signal.SIGTERM, stop)
    try:
        with RunLock(), Awake():
            run = Collector(args)
            status = "completed"
            try:
                run.run()
            except Finished as e:
                status = str(e)
            except Exception:
                LOG.exception("Unexpected runner error; saving completed work")
                status = "runner_error"
            finally:
                run.client.close()
            result = run.summarize(status)
            return 2 if status == "runner_error" else result
    except Skip as e:
        LOG.error("%s", e)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
