"""GitHub transport/ZIP adapter for DEV1. Applying data remains DEV1's job."""
from __future__ import annotations

from copy import deepcopy
import hashlib
import io
import json
import os
from pathlib import Path
import re
import shutil
import stat
import struct
import threading
import time
from urllib.error import HTTPError
from urllib.request import Request, build_opener, HTTPRedirectHandler
import uuid
import zipfile

from game_data_update import (UpdateError, MAX_FILE, MAX_TOTAL, MAX_MANIFEST,
                              approved_url, allowed_path, confined, digest, json_bytes,
                              validate_manifest, _write_json)

DATA_SCHEMA_VERSION = 1
MAX_ZIP = 128 * 1024 * 1024
URL_ROOT = 'https://raw.githubusercontent.com/dlckdtnr1212-lang/RAID-Champion-DB/main/data-updates'


def manifest_url(channel):
    if channel not in ('beta', 'stable'):
        raise UpdateError('Unsupported update channel')
    return f'{URL_ROOT}/{channel}/manifest.json'


def validate_online_manifest(doc, app_version, channel):
    validate_manifest(doc, app_version)  # Preserve DEV1's version, file and URL policy.
    if doc.get('channel') != channel or channel not in ('beta', 'stable'):
        raise UpdateError('Update channel mismatch')
    if type(doc.get('data_schema_version')) is not int or doc['data_schema_version'] != DATA_SCHEMA_VERSION:
        raise UpdateError('Unsupported data schema version')
    packages = doc.get('packages')
    if not isinstance(packages, list) or not 1 <= len(packages) <= 4096:
        raise UpdateError('Invalid package list')
    files = {f['path']: f for f in doc['files']}
    covered, names, urls, total = set(), set(), set(), 0
    for item in packages:
        if not isinstance(item, dict) or set(item) != {'path', 'url', 'size', 'sha256', 'files'}:
            raise UpdateError('Invalid package entry')
        name = item['path']
        if (not isinstance(name, str) or not re.fullmatch(r'packages/[A-Za-z0-9_-][A-Za-z0-9_.-]*\.zip', name)
                or '..' in name):
            raise UpdateError('Invalid package path')
        approved_url(item['url'])
        if name.lower() in names or item['url'] in urls:
            raise UpdateError('Duplicate package')
        names.add(name.lower()); urls.add(item['url'])
        if type(item['size']) is not int or not 0 < item['size'] <= MAX_ZIP:
            raise UpdateError('Invalid package size')
        if not re.fullmatch('[0-9a-f]{64}', str(item['sha256'])):
            raise UpdateError('Invalid package SHA-256')
        members = item['files']
        if not isinstance(members, list) or not members or any(not isinstance(n, str) for n in members):
            raise UpdateError('Invalid package file list')
        if len(set(members)) != len(members) or covered.intersection(members) or not set(members) <= files.keys():
            raise UpdateError('Duplicate or unlisted package member')
        covered.update(members)
        total += item['size']
    if covered != files.keys() or total > MAX_TOTAL:
        raise UpdateError('Package coverage or total size invalid')
    return doc


class _Redirect(HTTPRedirectHandler):
    def __init__(self, expires):
        super().__init__()
        self.expires, self.count = expires, 0

    def redirect_request(self, req, fp, code, msg, headers, newurl):
        self.count += 1
        if self.count > 3 or time.monotonic() > self.expires:
            raise UpdateError('Redirect/time limit exceeded')
        approved_url(newurl, redirect=True)
        return super().redirect_request(req, fp, code, msg, headers, newurl)


class GitHubTransport:
    """No credentials, retries or startup activity; TLS verification is urllib's default."""
    def _open(self, url, headers, expires):
        return build_opener(_Redirect(expires)).open(Request(url, headers=headers), timeout=10)

    def fetch(self, url, target, limit, etag=None, progress=None, timeout=60):
        approved_url(url)
        headers = {'User-Agent': 'RAID-Champion-DB-Data/2', 'Accept-Encoding': 'identity'}
        if etag and isinstance(etag, str) and len(etag) < 512 and not any(c in etag for c in '\r\n'):
            headers['If-None-Match'] = etag
        expires = time.monotonic() + timeout
        try:
            response = self._open(url, headers, expires)
        except HTTPError as exc:
            if exc.code == 304 and etag:
                exc.close()
                return {'not_modified': True, 'etag': etag, 'bytes': 0}
            exc.close()
            raise
        with response:
            approved_url(response.url, redirect=True)
            size = response.headers.get('Content-Length')
            if size and (not size.isdigit() or int(size) > limit):
                raise UpdateError('HTTP response exceeds size limit')
            count = 0
            read = getattr(response, 'read1', response.read)
            while True:
                if time.monotonic() > expires:
                    raise UpdateError('Download time limit exceeded')
                chunk = read(min(65536, limit + 1 - count))
                if not chunk:
                    break
                count += len(chunk)
                if count > limit:
                    raise UpdateError('Download exceeds declared size')
                target.write(chunk)
                if progress:
                    progress(count)
            return {'not_modified': False, 'etag': response.headers.get('ETag'), 'bytes': count}


def extract_package(archive, package, file_entries, destination):
    """Strict preflight; no extractall, directory entries, links or extra members."""
    expected = set(package['files'])
    # Bound the central directory before ZipFile allocates its member objects.
    # Format 1 never needs split archives or ZIP64 (each file <=64 MiB).
    with Path(archive).open('rb') as stream:
        stream.seek(0, 2); length = stream.tell()
        stream.seek(max(0, length-65557)); tail = stream.read()
    pos = tail.rfind(b'PK\x05\x06')
    if pos < 0 or len(tail)-pos < 22:
        raise UpdateError('Missing ZIP end record')
    _, disk, start_disk, count_disk, count, directory_size, offset, comment = struct.unpack('<4s4H2LH', tail[pos:pos+22])
    if (disk or start_disk or count_disk != count or count != len(expected) or count > 4096
            or directory_size > 2*1024*1024 or offset+directory_size > length
            or len(tail)-pos != 22+comment):
        raise UpdateError('Unsupported or excessive ZIP directory')
    with zipfile.ZipFile(archive) as zipped:
        infos = zipped.infolist()
        if len(infos) != len(expected) or len(infos) > 4096:
            raise UpdateError('ZIP member count mismatch')
        seen, total = set(), 0
        for member in infos:
            name = allowed_path(member.filename)
            mode = member.external_attr >> 16
            if (name not in expected or name.lower() in seen or member.is_dir()
                    or stat.S_IFMT(mode) not in (0, stat.S_IFREG)
                    or member.external_attr & 0x10 or member.flag_bits & 1
                    or member.compress_type not in (zipfile.ZIP_STORED, zipfile.ZIP_DEFLATED)):
                raise UpdateError('Unsafe or unexpected ZIP member')
            seen.add(name.lower())
            if member.file_size != file_entries[name]['size'] or member.file_size > MAX_FILE:
                raise UpdateError('ZIP member size mismatch')
            total += member.file_size
            if total > MAX_TOTAL or member.file_size > max(1024, member.compress_size * 200):
                raise UpdateError('ZIP expansion limit exceeded')
        if {m.filename for m in infos} != expected:
            raise UpdateError('ZIP missing required members')
        for member in infos:
            path = confined(destination, member.filename)
            path.parent.mkdir(parents=True, exist_ok=True)
            count, sha = 0, hashlib.sha256()
            with zipped.open(member) as source, path.open('xb') as out:
                while chunk := source.read(65536):
                    count += len(chunk)
                    if count > member.file_size:
                        raise UpdateError('ZIP data exceeds declared size')
                    sha.update(chunk); out.write(chunk)
            if count != member.file_size or sha.hexdigest() != file_entries[member.filename]['sha256']:
                raise UpdateError('Extracted file size/SHA-256 mismatch')


class OnlineDataClient:
    def __init__(self, manager, channel='beta', transport=None):
        self.manager, self.channel = manager, channel
        self.url = manifest_url(channel)
        self.transport = transport or GitHubTransport()
        self.cache = confined(manager.store, 'online_cache')

    def _manifest(self):
        key = hashlib.sha256(self.url.encode()).hexdigest()
        cache_file = confined(self.cache, key + '.json')
        cached = None
        try:
            if cache_file.stat().st_size <= MAX_MANIFEST * 2:
                cached = json_bytes(cache_file.read_bytes())
                if not isinstance(cached, dict) or cached.get('url') != self.url:
                    cached = None
                elif len(json.dumps(cached.get('manifest')).encode()) > MAX_MANIFEST:
                    cached = None
                else:
                    validate_online_manifest(cached['manifest'], self.manager.app_version, self.channel)
        except (OSError, ValueError, TypeError, KeyError):
            cached = None
        out = io.BytesIO()
        response = self.transport.fetch(self.url, out, MAX_MANIFEST, etag=cached.get('etag') if cached else None, timeout=15)
        if response['not_modified']:
            if not cached:
                raise UpdateError('304 response without valid cached manifest')
            return cached['manifest'], True
        doc = json_bytes(out.getvalue())
        validate_online_manifest(doc, self.manager.app_version, self.channel)
        try:
            self.cache.mkdir(parents=True, exist_ok=True)
            temp = confined(self.cache, key + '-' + uuid.uuid4().hex + '.tmp')
            _write_json(temp, {'url': self.url, 'etag': response.get('etag'), 'manifest': doc})
            os.replace(temp, cache_file)
        except OSError:
            pass  # Optional HTTP cache cannot make a valid online check fail.
        return doc, False

    def check(self):
        try:
            doc, cached = self._manifest()
            result = self.manager.check(doc)
            if not result['success']:
                return result, None
            needed = {f['path'] for f in result['files'] if f['download_required']}
            packages = [p for p in doc['packages'] if needed.intersection(p['files'])] if result['available'] else []
            result.update(channel=self.channel, data_schema_version=doc['data_schema_version'],
                          download_size=sum(p['size'] for p in packages), packages=len(packages),
                          manifest_cached=cached, publication_status='published')
            return result, doc
        except HTTPError as exc:
            exc.close()
            # An absent channel is a normal bootstrap state, not proof that
            # installed data is latest. Never resurrect a previously cached
            # version or confirmation token after a real 404 response.
            if exc.code == 404:
                return {'success': False, 'available': False,
                        'publication_status': 'not_published', 'error_code': 'MANIFEST_NOT_PUBLISHED',
                        'current_version': self.manager.snapshot().data_version,
                        'latest_version': None, 'download_size': 0, 'packages': 0, 'description': '',
                        'manifest_cached': False,
                        'error': 'HTTP 404: channel manifest is not published'}, None
            return {'success': False, 'available': False, 'publication_status': 'unavailable',
                    'error': str(exc)}, None
        except (OSError, ValueError, TypeError, KeyError) as exc:
            return {'success': False, 'available': False, 'error': str(exc)}, None

    def apply(self, manifest, progress=None, checkpoint=None):
        stage = None
        emit = progress or (lambda **state: None)
        try:
            validate_online_manifest(manifest, self.manager.app_version, self.channel)
            # Reuse DEV1's OS writer lock while preparing downloads. The DEV1
            # apply call reacquires it and checks prerequisites before commit.
            with self.manager._lock():
                checked = self.manager.check(manifest)
                if not checked['success']:
                    raise UpdateError(checked['error'])
                if not checked['available']:
                    return {'success': True, 'applied': False, 'message': 'Data is already current'}
                needed = {f['path'] for f in checked['files'] if f['download_required']}
                packages = [p for p in manifest['packages'] if needed.intersection(p['files'])]
                total, completed = sum(p['size'] for p in packages), 0
                stage = confined(self.manager.store, 'online_staging/' + uuid.uuid4().hex)
                stage.mkdir(parents=True)
                files = stage / 'files'; files.mkdir()
                entries = {f['path']: f for f in manifest['files']}
                emit(stage='downloading', bytes_downloaded=0, total_bytes=total)
                for package in packages:
                    cache = confined(self.cache, package['sha256'] + '.zip')
                    cache.parent.mkdir(parents=True, exist_ok=True)
                    good = cache.is_file() and cache.stat().st_size == package['size'] and digest(cache) == package['sha256']
                    if not good:
                        partial = confined(self.cache, package['sha256'] + '.part')
                        try:
                            with partial.open('wb') as out:
                                self.transport.fetch(package['url'], out, package['size'],
                                    progress=lambda n: emit(stage='downloading', bytes_downloaded=completed+n, total_bytes=total))
                                out.flush(); os.fsync(out.fileno())
                            emit(stage='verifying', bytes_downloaded=completed+package['size'], total_bytes=total)
                            if partial.stat().st_size != package['size'] or digest(partial) != package['sha256']:
                                raise UpdateError('Package size/SHA-256 mismatch')
                            os.replace(partial, cache)
                        finally:
                            if partial.exists():
                                partial.unlink()
                    extract_package(cache, package, entries, files)
                    completed += package['size']
                    emit(stage='verifying', bytes_downloaded=completed, total_bytes=total)
                # DEV1 accepts a local package directory. Reuse the already
                # installed file for entries not included in downloaded ZIPs.
                current = self.manager.snapshot()
                for name in entries:
                    target = confined(files, name)
                    if not target.exists():
                        if name in needed:
                            raise UpdateError('Required file not downloaded')
                        target.parent.mkdir(parents=True, exist_ok=True)
                        shutil.copyfile(current.resolve(name), target)
            emit(stage='applying', bytes_downloaded=completed, total_bytes=total)
            return self.manager.apply(manifest, package_dir=files, checkpoint=checkpoint)
        except (OSError, ValueError, TypeError, KeyError, zipfile.BadZipFile, RuntimeError) as exc:
            return {'success': False, 'applied': False, 'error': str(exc)}
        finally:
            if stage is not None and stage.exists():
                try:
                    shutil.rmtree(confined(self.manager.store, stage.relative_to(self.manager.store)))
                except OSError:
                    pass  # Crash leftovers are never selected by DEV1.


class OnlineUpdateService:
    """One explicit check followed by one explicit confirmation; workers keep GUI responsive."""
    def __init__(self, client):
        self.client, self._lock = client, threading.RLock()
        self._manifest, self._token, self._thread = None, None, None
        self._state = {'stage': 'idle', 'busy': False, 'available': False, 'error': None,
                       'bytes_downloaded': 0, 'total_bytes': 0, 'channel': client.channel}

    def status(self):
        with self._lock:
            return deepcopy(self._state)

    def _update(self, **values):
        with self._lock:
            self._state.update(values)

    def _start(self, action):
        with self._lock:
            if self._state['busy']:
                return {'success': False, 'error': 'An update operation is already running'}
            self._state.update(busy=True, error=None)
            self._thread = threading.Thread(target=action, daemon=True, name='RAID data update')
            self._thread.start()
            return {'success': True, 'started': True}

    def start_check(self):
        def check():
            try:
                self._update(stage='checking', available=False, confirmation_token=None)
                result, doc = self.client.check()
                with self._lock:
                    self._manifest = deepcopy(doc) if result.get('success') else None
                    self._token = uuid.uuid4().hex if result.get('success') and result.get('available') else None
                    self._state.update(result, stage=('available' if result.get('available') else 'up_to_date') if result.get('success') else 'failed',
                                       confirmation_token=self._token, total_bytes=result.get('download_size', 0), bytes_downloaded=0)
            except Exception as exc:
                self._manifest, self._token = None, None
                self._update(stage='failed', success=False, available=False, error=str(exc), confirmation_token=None)
            finally:
                self._update(busy=False)
        return self._start(check)

    def start_apply(self, confirmation_token):
        with self._lock:
            if (self._state['busy'] or not self._token or confirmation_token != self._token
                    or self._manifest is None):
                return {'success': False, 'error': 'Check and confirm the displayed update first'}
            doc = deepcopy(self._manifest)
            self._token = None
            self._state['confirmation_token'] = None
            def apply():
                try:
                    result = self.client.apply(doc, progress=self._update)
                    state = dict(result, stage='succeeded' if result.get('success') else 'failed',
                                 available=False, restart_required=bool(result.get('applied')))
                    self._update(**state)
                except Exception as exc:
                    self._update(stage='failed', success=False, available=False, error=str(exc))
                finally:
                    self._update(busy=False)
            return self._start(apply)

    def cancel_pending(self):
        with self._lock:
            if self._state['busy']:
                return {'success': False, 'error': 'An update operation is already running'}
            self._manifest, self._token = None, None
            self._state.update(stage='cancelled', available=False, confirmation_token=None, error=None)
            return {'success': True, 'cancelled': True}

    def wait(self, timeout=30):
        """Tests/CLI only; GUI polls status without waiting on the UI thread."""
        if self._thread:
            self._thread.join(timeout)
        return self.status()


def public_update_error(detail):
    """Translate known failure categories; never echo paths, tracebacks or URLs."""
    value = str(detail or '').lower()
    if '404' in value:
        return '업데이트 정보가 아직 게시되지 않았습니다. 현재 게임 데이터를 계속 사용할 수 있습니다.'
    if '429' in value or '403' in value:
        return '업데이트 서버가 요청을 제한하고 있습니다. 잠시 후 다시 확인하세요.'
    if 'incompatible application' in value:
        return '이 데이터에는 더 새로운 프로그램 버전이 필요합니다. 프로그램 업데이트를 먼저 확인하세요.'
    if 'schema' in value or 'channel' in value or 'prerequisite' in value:
        return '현재 프로그램 또는 설치 데이터와 호환되는 업데이트가 아닙니다.'
    if any(s in value for s in ('sha-256', 'hash', 'damaged', 'mismatch', 'zip', 'crc')):
        return '다운로드한 데이터가 손상되었거나 업데이트 정보와 일치하지 않아 적용하지 않았습니다.'
    if any(s in value for s in ('path', 'allowlist', 'outside', 'unsafe', 'forbidden', 'url')) and 'urlopen' not in value:
        return '허용되지 않은 업데이트 파일이나 다운로드 주소가 포함되어 있어 차단했습니다.'
    if 'limit' in value or 'exceeds' in value or 'size' in value:
        return '업데이트 파일이 허용된 크기 또는 처리 시간을 초과했습니다.'
    if any(s in value for s in ('permission', 'denied', 'access', 'disk', 'space')):
        return '업데이트 저장 폴더의 쓰기 권한과 디스크 여유 공간을 확인하세요.'
    if any(s in value for s in ('urlopen', 'offline', 'connection', 'timed out', 'network', 'getaddrinfo', 'resolve')):
        return '업데이트 서버에 연결하지 못했습니다. 인터넷 연결을 확인한 후 다시 시도하세요.'
    if 'already running' in value:
        return '업데이트 작업이 진행 중입니다. 완료될 때까지 기다려 주세요.'
    if 'confirm' in value:
        return '최신 데이터 확인 후 표시된 업데이트를 선택해 주세요.'
    return '업데이트를 완료하지 못했습니다. 현재 게임 데이터는 유지되며 잠시 후 다시 시도할 수 있습니다.'
