"""Startup policy and approved feeds around DEV1 data updates and Velopack.

Velopack alone owns program delta reconstruction, process handoff, replacement
and rollback. This module never writes executable files in the running app.
"""
import base64
from copy import deepcopy
import hashlib
import io
import json
import os
from pathlib import Path
import re
import threading
import time
import uuid
from urllib.error import HTTPError

from game_data_update import DataUpdateManager, UpdateError, approved_url, digest, json_bytes, version
from game_data_online import GitHubTransport, OnlineDataClient, public_update_error

APP_ID = 'JYrun.RAIDChampionDB'
REPO = 'https://raw.githubusercontent.com/dlckdtnr1212-lang/RAID-Champion-DB/main'
DEFAULTS = {'check_on_startup': True, 'auto_data': True, 'auto_program': True,
            'restart_after_program_update': True, 'channel': 'beta'}
CHECK_INTERVAL = 6 * 60 * 60
MAX_PROGRAM_PACKAGE = 2 * 1024 ** 3


def canonical(doc):
    return json.dumps(doc, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False).encode('utf8')


def canonical_hash(doc):
    return hashlib.sha256(canonical(doc)).hexdigest()


def atomic_json(path, doc):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name + '.' + uuid.uuid4().hex + '.tmp')
    try:
        with temp.open('x', encoding='utf8') as stream:
            json.dump(doc, stream, ensure_ascii=False, indent=2, allow_nan=False)
            stream.flush(); os.fsync(stream.fileno())
        os.replace(temp, path)
    finally:
        temp.unlink(missing_ok=True)


def bootstrap():
    """Run before importing the GUI/resource snapshot, including fast callbacks."""
    import sys
    if getattr(sys, 'frozen', False):
        import velopack
        # Pending packages only apply through our approved/settings-aware handoff.
        velopack.App().set_auto_apply_on_startup(False).run()


def verify_approval(envelope, trust, channel, *, allow_local_proof=False):
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
    if not isinstance(envelope, dict) or set(envelope) != {'payload', 'signature', 'key_id'}:
        raise UpdateError('Invalid approval envelope')
    key = trust.get('keys', {}).get(envelope['key_id'])
    if not key: raise UpdateError('Unknown approval signing key')
    try:
        Ed25519PublicKey.from_public_bytes(base64.b64decode(key, validate=True)).verify(
            base64.b64decode(envelope['signature'], validate=True), canonical(envelope['payload']))
    except Exception as exc:
        raise UpdateError('Approval signature verification failed') from exc
    payload = envelope['payload']
    if payload.get('local_proof_only') and not allow_local_proof:
        raise UpdateError('Local proof metadata is not a public update')
    if (payload.get('format_version') != 1 or payload.get('channel') != channel
            or channel not in ('beta', 'stable') or type(payload.get('sequence')) is not int
            or payload['sequence'] < 1 or not 0 < payload.get('expires_at', 0) - time.time() <= 366 * 86400):
        raise UpdateError('Approval channel, expiry or format incompatible')
    data_hash = payload.get('data_manifest_canonical_sha256')
    if data_hash is not None and not re.fullmatch('[0-9a-f]{64}', str(data_hash)):
        raise UpdateError('Invalid approved data hash')
    program = payload.get('program')
    if program is not None:
        version(program.get('app_version'), True)
        if channel == 'stable' and '-' in program['package_version']:
            raise UpdateError('Prerelease package cannot enter stable channel')
        if program.get('data_schema_version') != 1:
            raise UpdateError('Incompatible program data schema')
        limits = program['supported_data_versions']
        if version(limits['min']) > version(limits['max']): raise UpdateError('Invalid data compatibility')
        assets = program.get('feed', {}).get('Assets')
        if not isinstance(assets, list) or not 1 <= len(assets) <= 128:
            raise UpdateError('Invalid approved Velopack feed')
        names = set(); full_target = False
        for asset in assets:
            name = asset.get('FileName')
            if (not isinstance(name, str) or not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.-]{0,180}\.nupkg', name)
                    or '..' in name or name.lower() in names or asset.get('PackageId') != APP_ID
                    or asset.get('Type') not in ('Full', 'Delta')
                    or type(asset.get('Size')) is not int or not 0 < asset['Size'] <= MAX_PROGRAM_PACKAGE
                    or not re.fullmatch('[0-9a-fA-F]{64}', str(asset.get('SHA256')))):
                raise UpdateError('Unsafe or invalid approved program asset')
            names.add(name.lower())
            url = program['urls'][name]; approved_url(url)
            if not url.endswith('/' + name): raise UpdateError('Program URL does not match approved name')
            full_target |= asset['Type'] == 'Full' and asset.get('Version') == program['package_version']
        if not full_target: raise UpdateError('Approved target full package missing')
    return payload


class AutoUpdateCoordinator:
    def __init__(self, manager, *, transport=None, control=None, allow_local_proof=False):
        self.manager = manager
        self.transport = transport or GitHubTransport()
        self.allow_local_proof = allow_local_proof
        self.root = Path(control) if control else manager.store.parent
        self.path = self.root/'update_control.json'
        self.cache = self.root/'program_update_cache'
        self._lock = threading.RLock()
        self._thread = None; self._stop = threading.Event()
        self._pending = None; self._program_manager = None
        self._restart_requested = False
        self._checked_data = None
        self._state = {'busy': False, 'stage': 'idle', 'program': {}, 'data': {}, 'error': None}
        try:
            import velopack
            self._state['program'] = {'current_version': velopack.UpdateManager().get_current_version()}
        except Exception:
            pass  # Source/legacy portable runs are still valid for data updates.
        self._control = self._read_control()
        saved = self._control.get('data_checks', {}).get(self._control['settings']['channel'])
        if saved:
            self._state['data'] = dict(saved, stage='up_to_date' if saved.get('latest_version') == manager.snapshot().data_version else 'available')
            if self._state['data']['stage'] == 'up_to_date':
                self._state['data']['download_size'] = 0
        program = self._control.get('program_checks', {}).get(self._control['settings']['channel'], {})
        if program.get('current_version') == self._state['program'].get('current_version'):
            self._state['program'].update(program)
        self.trust = json_bytes((manager.base/'release_tools/update_trust.json').read_bytes())

    def _read_control(self):
        if not self.path.exists(): return {'settings': dict(DEFAULTS), 'last_checks': {}, 'sequences': {}}
        doc = json_bytes(self.path.read_bytes())
        if not isinstance(doc, dict): raise UpdateError('Invalid update settings; original preserved')
        doc['settings'] = self._settings(dict(DEFAULTS, **doc.get('settings', {})))
        doc.setdefault('last_checks', {}); doc.setdefault('sequences', {})
        return doc

    @staticmethod
    def _settings(settings):
        if set(settings) != set(DEFAULTS) or settings['channel'] not in ('beta', 'stable'):
            raise UpdateError('Invalid update settings/channel')
        if any(type(settings[name]) is not bool for name in DEFAULTS if name != 'channel'):
            raise UpdateError('Update switches must be boolean')
        return settings

    def save_settings(self, settings):
        with self._lock:
            if self._state['busy']: raise UpdateError('Wait for the current update before changing settings')
            previous_channel = self._control['settings']['channel']
            self._control['settings'] = self._settings(settings)
            if previous_channel != settings['channel']:
                (self.root/'pending_program.json').unlink(missing_ok=True)
                self._state.update(data={}, program={'current_version': self._state['program'].get('current_version')}, stage='idle', error=None)
                self._checked_data = None
            atomic_json(self.path, self._control)
            # A channel switch cannot apply a previously prepared package.
            self._pending = None
            return self.status()

    def _update(self, **values):
        with self._lock: self._state.update(values)

    def status(self):
        with self._lock:
            return dict(deepcopy(self._state), settings=dict(self._control['settings']),
                        app_version=self.manager.app_version, framework='Velopack 1.2.161',
                        restart_on_exit=bool(self._pending), last_check=self._control['last_checks'].get(self._control['settings']['channel']))

    def request_restart(self):
        """An explicit in-app safe-point; no executable replacement here."""
        with self._lock:
            if self._state['busy']:
                raise UpdateError('업데이트 준비가 끝난 후 다시 시도하세요.')
            self._restart_requested = True
            self._control['restart_request'] = {'pid': os.getpid(), 'time': time.time()}
            atomic_json(self.path, self._control)

    def start(self, automatic=True, *, check_only=False):
        with self._lock:
            settings = dict(self._control['settings']); channel = settings['channel']
            if self._state['busy']: return {'success': True, 'already_running': True}
            if automatic and not settings['check_on_startup']:
                self._state.update(stage='disabled')
                return {'success': True, 'skipped': True}
            restore = automatic and settings['auto_program'] and (self.root/'pending_program.json').is_file()
            if automatic and not restore and time.time()-self._control['last_checks'].get(channel, 0) < CHECK_INTERVAL:
                self._state.update(stage='cached')
                return {'success': True, 'skipped': True}
            self._control['last_checks'][channel] = time.time()
            atomic_json(self.path, self._control)
            self._state.update(busy=True, stage='checking', error=None)
            self._checked_data = None
            self._state['data']['confirmation_token'] = None
            self._stop.clear()
            self._thread = threading.Thread(target=self._run, args=(settings, automatic, restore, check_only), daemon=True, name='approved-updates')
            self._thread.start()
            return {'success': True, 'started': True}

    def _cancelled(self, *_):
        if self._stop.is_set(): raise UpdateError('Update interrupted before installation')

    def _fetch_approval(self, channel):
        out = io.BytesIO()
        self.transport.fetch(f'{REPO}/program-updates/{channel}/approval.json', out, 2*1024*1024, timeout=10)
        envelope = json_bytes(out.getvalue())
        payload = verify_approval(envelope, self.trust, channel, allow_local_proof=self.allow_local_proof)
        if payload['sequence'] < self._control['sequences'].get(channel, 0):
            raise UpdateError('Older approval sequence refused')
        self._control['sequences'][channel] = payload['sequence']
        atomic_json(self.path, self._control)
        return envelope, payload

    def _run(self, settings, automatic, restore=False, check_only=False):
        try:
            if restore:
                envelope = json_bytes((self.root/'pending_program.json').read_bytes())
                payload = verify_approval(envelope, self.trust, settings['channel'], allow_local_proof=self.allow_local_proof)
                if payload['sequence'] < self._control['sequences'].get(settings['channel'], 0):
                    raise UpdateError('Older approval sequence refused')
            else:
                envelope, payload = self._fetch_approval(settings['channel'])
            if not restore and payload.get('data_manifest_canonical_sha256'):
                client = OnlineDataClient(self.manager, settings['channel'], self.transport)
                checked, doc = client.check()
                if not checked.get('success'): raise UpdateError(checked.get('error'))
                if canonical_hash(doc) != payload['data_manifest_canonical_sha256']:
                    raise UpdateError('Data manifest differs from signed approval')
                self._control.setdefault('data_checks', {})[settings['channel']] = {
                    k: checked[k] for k in ('latest_version', 'download_size', 'description', 'channel') if k in checked}
                atomic_json(self.path, self._control)
                token = uuid.uuid4().hex if checked['available'] else None
                self._checked_data = (client, doc, token) if token else None
                self._update(data=dict(checked, confirmation_token=token, busy=False,
                                      stage='available' if checked['available'] else 'up_to_date'))
                if checked['available'] and settings['auto_data'] and not check_only:
                    self._apply_data(client, doc, checked)
            program = payload.get('program')
            if program and not check_only:
                self._prepare_program(envelope, payload, settings, automatic)
            self._update(stage='ready' if self._pending else 'checked')
        except HTTPError as exc:
            if exc.code == 404:
                self._update(stage='not_published', error=None)
            else:
                self._update(stage='failed', error=public_update_error(str(exc)), diagnostic=str(exc))
        except Exception as exc:
            self._update(stage='failed', error=public_update_error(str(exc)), diagnostic=str(exc))
        finally:
            program = self._state['program']
            if program.get('latest_version'):
                self._control.setdefault('program_checks', {})[settings['channel']] = deepcopy(program)
                atomic_json(self.path, self._control)
            self._update(busy=False)

    def _apply_data(self, client, doc, checked):
        self._checked_data = None
        self._cancelled()
        self._update(stage='data_update')
        installed = client.apply(doc, progress=lambda **v: (self._cancelled(), self._update(data=dict(checked, **v, confirmation_token=None))))
        if not installed.get('success'): raise UpdateError(installed.get('error'))
        self._update(data=dict(checked, **installed, available=False, download_size=0,
                               confirmation_token=None, stage='succeeded'))

    def start_apply(self, token):
        """Manual confirmation uses the same approved manifest and worker state."""
        with self._lock:
            if self._state['busy'] or not self._checked_data or self._checked_data[2] != token:
                return {'success': False, 'error': 'Check and confirm the displayed update first'}
            client, doc, _ = self._checked_data
            checked = deepcopy(self._state['data'])
            self._state.update(busy=True, stage='data_update', error=None)
            def apply():
                try:
                    self._apply_data(client, doc, checked)
                    self._update(stage='ready' if self._pending else 'checked')
                except Exception as exc:
                    self._update(stage='failed', error=public_update_error(str(exc)), diagnostic=str(exc))
                finally:
                    self._update(busy=False)
            self._thread = threading.Thread(target=apply, daemon=True, name='approved-data-confirmation')
            self._thread.start()
            return {'success': True, 'started': True}

    def cancel_pending(self):
        with self._lock:
            if self._state['busy']: return {'success': False, 'error': 'An update operation is already running'}
            self._checked_data = None
            self._state['data'].update(confirmation_token=None, available=False, stage='cancelled')
            return {'success': True, 'cancelled': True}

    def resume_prepared_before_gui(self):
        """Settings-aware native handoff of an already SDK-verified package only.

        No network or GUI close is performed here. Invalid/incomplete caches fall
        through to the normal background check and keep the current app usable.
        """
        import sys
        settings = dict(self._control['settings'])
        if not getattr(sys, 'frozen', False) or not settings['auto_program']:
            return False
        if not (self.root/'pending_program.json').is_file():
            return False  # An ordinary/latest launch has no prepared update.
        try:
            envelope = json_bytes((self.root/'pending_program.json').read_bytes())
            payload = verify_approval(envelope, self.trust, settings['channel'], allow_local_proof=self.allow_local_proof)
            if payload['sequence'] < self._control['sequences'].get(settings['channel'], 0):
                return False
            program = payload['program']
            current = self._state['program'].get('current_version')
            if current == program['package_version']:
                (self.root/'pending_program.json').unlink(missing_ok=True)
                self._state['program'].update(stage='up_to_date', latest_version=current,
                                               description=program.get('description', ''))
                self._control.setdefault('program_checks', {})[settings['channel']] = deepcopy(self._state['program'])
                atomic_json(self.path, self._control)
                return False
            attempt = self._control.get('program_attempt', {})
            if attempt.get('from') == current and attempt.get('approval_hash') == canonical_hash(envelope):
                return False
            full = next(a for a in program['feed']['Assets'] if a['Type'] == 'Full' and a['Version'] == program['package_version'])
            receipt = json_bytes((self.root/'pending_program_receipt.json').read_bytes())
            cache = Path(sys.executable).parent.parent/'packages'/full['FileName']
            if (receipt.get('file') != full['FileName'] or receipt.get('source_sha256') != full['SHA256'].lower()
                    or not cache.is_file() or cache.stat().st_size != receipt.get('size') or digest(cache) != receipt.get('sha256')):
                return False
            self._prepare_program(envelope, payload, settings, True)
            if self._pending:
                self._restart_requested = True
                self.after_exit()
                return True
        except Exception as exc:
            self._update(stage='failed', error=public_update_error(str(exc)), diagnostic=str(exc))
        return False

    def _program_compatible(self, program):
        current = self.manager.snapshot()
        limits = program['supported_data_versions']
        if not version(limits['min']) <= version(current.data_version) <= version(limits['max']):
            raise UpdateError('Program prerequisite data version incompatible')
        target = DataUpdateManager(self.manager.base, self.manager.store, program['app_version']).snapshot()
        if target.error or target.data_version != current.data_version:
            raise UpdateError('Current game overlay is incompatible with the new program')

    def _prepare_program(self, envelope, payload, settings, automatic):
        import velopack
        program = payload['program']; channel = settings['channel']
        self.cache.mkdir(parents=True, exist_ok=True)
        mirror = self.cache/canonical_hash(program)
        mirror.mkdir(exist_ok=True)
        atomic_json(mirror/f'releases.{channel}.json', program['feed'])
        try:
            pm = velopack.UpdateManager(str(mirror), velopack.UpdateOptions(False, 12, channel))
            current = pm.get_current_version()
        except Exception:
            self._update(program={'stage': 'requires_install', 'message': '최초 업데이트 지원 설치본으로 한 번 전환하세요.'})
            return
        info = pm.check_for_updates()
        self._update(program={'stage': 'available' if info else 'up_to_date', 'current_version': current,
                              'latest_version': program['package_version'], 'description': program.get('description', '')})
        if not info:
            (self.root/'pending_program.json').unlink(missing_ok=True)
            return
        if not settings['auto_program']: return
        if info.TargetFullRelease.Version != program['package_version'] or info.IsDowngrade:
            raise UpdateError('Program target/version mismatch or downgrade')
        self._program_compatible(program)
        attempt = self._control.get('program_attempt', {})
        approval_hash = canonical_hash(envelope)
        if automatic and attempt.get('approval_hash') == approval_hash and attempt.get('from') == current:
            self._update(program={'stage': 'held_after_failure', 'current_version': current,
                                  'message': '이전 적용이 완료되지 않아 자동 재시도를 보류합니다. 수동 확인으로 다시 시도할 수 있습니다.'})
            return
        def download(asset):
            self._cancelled()
            name = asset.FileName; target = mirror/name
            if target.is_file() and target.stat().st_size == asset.Size and digest(target).lower() == asset.SHA256.lower(): return
            part = mirror/(name+'.partial')
            try:
                with part.open('wb') as out:
                    self.transport.fetch(program['urls'][name], out, asset.Size, progress=self._cancelled, timeout=600)
                    out.flush(); os.fsync(out.fileno())
                if part.stat().st_size != asset.Size or digest(part).lower() != asset.SHA256.lower():
                    raise UpdateError('Program SHA-256/size mismatch')
                os.replace(part, target)
            finally: part.unlink(missing_ok=True)
        self._update(stage='program_download')
        # Velopack's delta reconstruction preserves file contents, not the
        # original NuGet ZIP's byte layout. Pin the SDK-validated local result,
        # rather than comparing that ZIP with the server's full-download hash.
        import sys
        cached_full = Path(sys.executable).parent.parent/'packages'/info.TargetFullRelease.FileName
        receipt_path = self.root/'pending_program_receipt.json'
        receipt = json_bytes(receipt_path.read_bytes()) if receipt_path.exists() else {}
        receipt_valid = (receipt.get('source_sha256') == info.TargetFullRelease.SHA256.lower()
                         and receipt.get('file') == info.TargetFullRelease.FileName
                         and cached_full.is_file() and cached_full.stat().st_size == receipt.get('size')
                         and digest(cached_full) == receipt.get('sha256'))
        if cached_full.is_file() and not receipt_valid:
            cached_full.unlink()  # Only an unapplied future package, never current files.
        if receipt_valid:
            pending = pm.get_update_pending_restart()
            if pending is None or pending.Version != info.TargetFullRelease.Version:
                raise UpdateError('SDK pending program target mismatch')
            self._pending = (pm, pending, envelope, receipt)
            self._update(program={'stage': 'ready', 'current_version': current,
                                  'latest_version': program['package_version'], 'description': program.get('description', '')})
            return
        selected = info.DeltasToTarget if info.BaseRelease and info.DeltasToTarget else [info.TargetFullRelease]
        for asset in selected: download(asset)
        try:
            pm.download_updates(info)
        except Exception:
            self._cancelled(); download(info.TargetFullRelease)
            info = velopack.UpdateInfo(info.TargetFullRelease, [], False)
            pm.download_updates(info)
        self._cancelled()
        pending = pm.get_update_pending_restart()
        if pending is None or pending.Version != info.TargetFullRelease.Version or pending.FileName != cached_full.name or not cached_full.is_file():
            raise UpdateError('SDK did not prepare the approved program target')
        receipt = {'file': cached_full.name, 'version': pending.Version,
                   'source_sha256': info.TargetFullRelease.SHA256.lower(),
                   'size': cached_full.stat().st_size, 'sha256': digest(cached_full)}
        atomic_json(receipt_path, receipt)
        atomic_json(self.root/'pending_program.json', envelope)
        self._pending = (pm, pending, envelope, receipt)
        self._update(program={'stage': 'ready', 'current_version': current, 'latest_version': program['package_version'],
                              'description': program.get('description', ''), 'download_size': sum(a.Size for a in selected)})

    def after_exit(self):
        """GUI has closed; let external Update.exe wait for this process to exit."""
        try:
            self._handoff_after_exit()
        except Exception as exc:
            self._control['last_apply_error'] = {'time': time.time(), 'message': public_update_error(str(exc))}
            atomic_json(self.path, self._control)
            raise

    def _handoff_after_exit(self):
        self._stop.set()
        with self._lock:
            pending = self._pending; settings = dict(self._control['settings'])
        if not pending or not settings['auto_program']:
            if self._restart_requested:
                import subprocess, sys
                updater = Path(sys.executable).parent.parent/'Update.exe'
                if not getattr(sys, 'frozen', False) or not updater.is_file():
                    raise UpdateError('설치된 Windows 프로그램에서 재실행하세요.')
                args = sys.argv[1:] if '--auto-review-profile' in sys.argv else []
                subprocess.Popen([str(updater), 'start', '--waitPid', str(os.getpid()), '--', *args],
                                 creationflags=subprocess.CREATE_NO_WINDOW)
            return
        pm, asset, envelope, receipt = pending
        payload = verify_approval(envelope, self.trust, settings['channel'], allow_local_proof=self.allow_local_proof)
        self._program_compatible(payload['program'])
        import sys
        cached_full = Path(sys.executable).parent.parent/'packages'/asset.FileName
        if (not cached_full.is_file() or cached_full.stat().st_size != receipt['size']
                or digest(cached_full) != receipt['sha256']):
            raise UpdateError('Cached program SHA-256/size mismatch before handoff')
        self._control.pop('last_apply_error', None)
        self._control['program_attempt'] = {'from': pm.get_current_version(), 'target': asset.Version,
                                            'approval_hash': canonical_hash(envelope), 'time': time.time()}
        atomic_json(self.path, self._control)
        # Preserve explicit local-review arguments across the external restart.
        restart_args = sys.argv[1:] if '--auto-review-profile' in sys.argv else []
        pm.wait_exit_then_apply_updates(asset, silent=True, restart=settings['restart_after_program_update'] or self._restart_requested, restart_args=restart_args)
