"""Data-only, immutable generations. No network or writes during construction/read.

Format 1 replaces complete allowlisted JSON/image files, never executable code or
user stores. A single atomic pointer commits the complete generation. Readers pin
one generation until restart; orphan staging/generations are deliberately inert.
"""
from __future__ import annotations

from contextlib import contextmanager
import hashlib
import io
import json
import math
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import uuid
from urllib.parse import urlsplit
from urllib.request import Request, build_opener, HTTPRedirectHandler

BASE_DATA_VERSION = "1.0.0"  # distribution baseline, NOT a claim about the live game patch
MANIFEST_URL = "https://raw.githubusercontent.com/dlckdtnr1212-lang/RAID-Champion-DB/main/data-updates/manifest.json"
MAX_FILE = 64 * 1024 * 1024
MAX_TOTAL = 256 * 1024 * 1024
MAX_MANIFEST = 2 * 1024 * 1024
JSON_FILES = frozenset({
    "data/champions.json", "data/champions_collected.json",
    "data/bulk_stage11/champion_names_ko_game.json",
    "data/bulk_stage11/champion_names_ko_verified.json",
    "data/bulk_stage11/champion_skills_ko_game.json",
    "data/bulk_stage11/champion_stats_game.json",
    "data/bulk_stage11/champion_stats_reference.json",
    "data/bulk_stage11/skill_display_schema_game.json",
    "data/bulk_stage11/ui_champion_portraits.json",
    "data/bulk_stage11/ui_localization_game.json",
    "data/bulk_stage11/artifact_sets_ui.json",
    "data/bulk_stage11/champion_recommendations_source.json",
    "nightly_collection/manifest.json",
    "ui_web_proof/gear_rules_v2.json", "ui_web_proof/mastery_66_full.json",
})
IMAGE_DIRS = ("assets/champion_portraits/", "assets/ui_icons/", "assets/mastery_references/",
              "ui_web_proof/frontend/assets/champions/", "ui_web_proof/frontend/assets/all_champions/",
              "ui_web_proof/frontend/assets/icons/")


class UpdateError(ValueError):
    pass


def allowed_path(value):
    if not isinstance(value, str) or not value or len(value) > 240:
        raise UpdateError("Invalid data path")
    parts = value.split("/")
    if (any(not p or p in (".", "..") or p.endswith((".", " ")) for p in parts)
            or any(re.fullmatch(r'(?:CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])(?:\..*)?', p, re.I) for p in parts)
            or not re.fullmatch(r"[A-Za-z0-9_./-]+", value)
            or PurePosixPath(value).is_absolute()):
        raise UpdateError("Unsafe data path")
    if value in JSON_FILES:
        return value
    if value.startswith(IMAGE_DIRS) and Path(value).suffix in (".png", ".jpg", ".jpeg", ".webp"):
        return value
    raise UpdateError("Data path is not allowlisted: " + value)


def confined(root, relative, allow_links=False):
    root = Path(root).resolve()
    result = root / relative
    if not result.resolve().is_relative_to(root):
        raise UpdateError("Path escapes data root")
    # Reject junctions/symlinks as well as traversal, including existing ancestors.
    for part in (() if allow_links else (result, *result.parents)):
        if part == root:
            break
        if part.is_symlink() or getattr(part, "is_junction", lambda: False)():
            raise UpdateError("Linked update paths are forbidden")
    return result


def digest(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def json_bytes(raw):
    def pairs(items):
        obj = {}
        for key, value in items:
            if key in obj:
                raise UpdateError("Duplicate JSON key: " + key)
            obj[key] = value
        return obj
    def invalid(value):
        raise UpdateError("Nonfinite JSON value: " + value)
    def number(value):
        parsed = float(value)
        if not math.isfinite(parsed):
            raise UpdateError("Nonfinite JSON number")
        return parsed
    try:
        return json.loads(raw, object_pairs_hook=pairs, parse_constant=invalid, parse_float=number)
    except (UnicodeError, json.JSONDecodeError, RecursionError) as exc:
        raise UpdateError("Invalid JSON") from exc


def version(value, app=False):
    pattern = r"(\d+)\.(\d+)\.(\d+)(?:-beta\.(\d+))?" if app else r"(\d+)\.(\d+)\.(\d+)"
    match = re.fullmatch(pattern, str(value))
    if not match:
        raise UpdateError("Unsupported version: " + str(value))
    nums = match.groups()
    return tuple(int(n) for n in nums[:3]) + ((0, int(nums[3])) if app and nums[3] else ((1, 0) if app else ()))


def compatible(manifest, app_version):
    limits = manifest.get("compatible_app_versions", {})
    if not isinstance(limits, dict):
        raise UpdateError("Invalid application compatibility range")
    try:
        lo, hi = version(limits["min"], True), version(limits["max"], True)
    except (KeyError, TypeError) as exc:
        raise UpdateError("Missing application compatibility range") from exc
    if not lo <= version(app_version, True) <= hi:
        raise UpdateError("Incompatible application version")


def approved_url(url, redirect=False):
    p = urlsplit(url)
    if p.scheme != "https" or p.username or p.password or p.port not in (None, 443) or p.fragment:
        raise UpdateError("HTTPS official GitHub URLs required")
    repo = "/dlckdtnr1212-lang/RAID-Champion-DB/"
    if (p.hostname in ("raw.githubusercontent.com", "github.com") and p.path.startswith(repo)
            and all(s not in (".", "..") for s in p.path.split("/")) and "%" not in p.path):
        return url
    if redirect and p.hostname == "release-assets.githubusercontent.com":
        return url
    raise UpdateError("URL outside official repository")


class _Redirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        approved_url(newurl, redirect=True)
        return super().redirect_request(req, fp, code, msg, headers, newurl)


def download(url, target, limit):
    approved_url(url)
    opener = build_opener(_Redirect())
    with opener.open(Request(url, headers={"User-Agent": "RAID-Champion-DB-Data/1"}), timeout=15) as response:
        approved_url(response.url, redirect=True)
        count = 0
        while chunk := response.read(min(65536, limit + 1 - count)):
            count += len(chunk)
            if count > limit:
                raise UpdateError("Download exceeds declared size")
            target.write(chunk)


def validate_manifest(doc, app_version):
    if not isinstance(doc, dict) or type(doc.get("manifest_format_version")) is not int or doc.get("manifest_format_version") != 1:
        raise UpdateError("Unsupported manifest format")
    version(doc.get("data_version"))
    version(doc.get("base_data_version"))
    if 'cumulative_from_base' in doc:
        if (doc['cumulative_from_base'] is not True or doc['base_data_version'] != BASE_DATA_VERSION
                or version(doc['data_version']) <= version(BASE_DATA_VERSION)):
            raise UpdateError('Invalid cumulative baseline manifest')
    compatible(doc, app_version)
    if not isinstance(doc.get("description"), str) or len(doc["description"]) > 8000:
        raise UpdateError("Missing update description")
    files = doc.get("files")
    if not isinstance(files, list) or not 1 <= len(files) <= 4096:
        raise UpdateError("Invalid file list")
    seen, total = set(), 0
    for item in files:
        if not isinstance(item, dict) or set(item) != {"path", "url", "size", "sha256"}:
            raise UpdateError("Invalid file entry (delete/code operations unsupported)")
        name = allowed_path(item["path"])
        if name.lower() in seen:
            raise UpdateError("Duplicate update path")
        seen.add(name.lower())
        if type(item["size"]) is not int or not 0 < item["size"] <= MAX_FILE:
            raise UpdateError("Invalid file size")
        if not re.fullmatch(r"[0-9a-f]{64}", str(item["sha256"])):
            raise UpdateError("Invalid SHA-256")
        approved_url(item["url"])
        total += item["size"]
    if total > MAX_TOTAL:
        raise UpdateError("Update exceeds size limit")
    return doc


def _unique(rows, field):
    if not isinstance(rows, list) or any(not isinstance(r, dict) or not r.get(field) for r in rows):
        raise UpdateError("Invalid ID collection: " + field)
    keys = [str(row[field]).strip().lower() for row in rows]
    if len(keys) != len(set(keys)):
        raise UpdateError("Duplicate identity: " + field)


def validate_payload(name, path):
    if name not in JSON_FILES:
        from PIL import Image
        try:
            with Image.open(path) as image:
                if image.format not in {"PNG", "JPEG", "WEBP"} or image.width * image.height > 40_000_000:
                    raise UpdateError("Unsupported image content")
                expected = {".png": "PNG", ".jpg": "JPEG", ".jpeg": "JPEG", ".webp": "WEBP"}
                if image.format != expected[path.suffix]:
                    raise UpdateError("Image extension/content mismatch")
                image.verify()
        except Image.DecompressionBombError as exc:
            raise UpdateError("Image dimensions exceed safety limit") from exc
        return
    doc = json_bytes(path.read_bytes())
    if not isinstance(doc, dict):
        raise UpdateError("Game JSON must be an object")
    if name in ("data/champions.json", "data/champions_collected.json"):
        _unique(doc.get("champions"), "name_en")
        ids = [r["id"] for r in doc["champions"] if r.get("id")]
        if len(ids) != len(set(ids)):
            raise UpdateError("Duplicate champion ID")
        for row in doc["champions"]:
            if not isinstance(row.get("stats", {}), dict) or not isinstance(row.get("skills", []), list):
                raise UpdateError("Invalid champion stats/skills")
            if any(not isinstance(row.get(k, ""), str) for k in ("name_en", "name_ko", "faction", "rarity", "affinity", "role")):
                raise UpdateError("Invalid champion text field")
            if any(not isinstance(s, dict) for s in row.get("skills", [])):
                raise UpdateError("Invalid skill row")
            if any(value is not None and type(value) not in (int, float) for value in row.get('stats', {}).values()):
                raise UpdateError("Invalid numeric champion stat")
    elif name == "nightly_collection/manifest.json":
        _unique(doc.get("targets"), "id")
        _unique(doc["targets"], "name_en")
    elif name.endswith("champion_names_ko_game.json"):
        _unique(doc.get("entries"), "champion_id")
        _unique(doc["entries"], "name_en")
    elif name.endswith(("champion_stats_game.json", "champion_skills_ko_game.json")):
        _unique(doc.get("champions"), "champion_id")
        if name.endswith("champion_skills_ko_game.json"):
            if not isinstance(doc.get("skills"), dict):
                raise UpdateError("Invalid skill dictionary")
            for c in doc["champions"]:
                for variant in c.get("game_variants", []):
                    for form in variant.get("forms", []):
                        _unique(form.get("skills", []), "skill_id")
                        if any(str(s["skill_id"]) not in doc["skills"] for s in form.get("skills", [])):
                            raise UpdateError("Dangling skill ID")
    elif name.endswith(("champion_stats_reference.json", "ui_champion_portraits.json")):
        if not isinstance(doc.get("entries"), dict):
            raise UpdateError("Invalid reference dictionary")
        if name.endswith("ui_champion_portraits.json"):
            for entry in doc['entries'].values():
                if not isinstance(entry, dict):
                    raise UpdateError("Invalid portrait mapping")
                if entry.get('image_path'):
                    image_path = allowed_path(entry['image_path'])
                    if not image_path.startswith('assets/champion_portraits/'):
                        raise UpdateError("Portrait outside approved image directory")
    elif name.endswith("gear_rules_v2.json"):
        if doc.get("schema_version") != 2 or not isinstance(doc.get("sets"), dict):
            raise UpdateError("Unsupported gear schema")
        if any(not isinstance(v, dict) for v in doc["sets"].values()):
            raise UpdateError("Invalid gear rule")
        for rule in doc['sets'].values():
            if 'pieces' in rule and (type(rule['pieces']) is not int or rule['pieces'] < 1):
                raise UpdateError("Invalid gear piece count")
            if 'variable' in rule and type(rule['variable']) is not bool:
                raise UpdateError("Invalid gear variable flag")
            if 'stat_bonuses' in rule and not isinstance(rule['stat_bonuses'], dict):
                raise UpdateError("Invalid gear bonus mapping")
    elif name.endswith("mastery_66_full.json"):
        all_ids = []
        for tree in ("offense", "defense", "support"):
            _unique(doc.get(tree), "id")
            if any(not isinstance(row.get('position', ''), str) for row in doc[tree]):
                raise UpdateError("Invalid mastery position")
            all_ids.extend(row['id'] for row in doc[tree])
        if len(set(all_ids)) != len(all_ids):
            raise UpdateError("Duplicate mastery ID across trees")


def _write_json(path, doc):
    with path.open("w", encoding="utf8", newline="\n") as stream:
        json.dump(doc, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.flush()
        os.fsync(stream.fileno())


class DataSnapshot:
    def __init__(self, base, generation=None, inventory=None, data_version=BASE_DATA_VERSION, error=None):
        self.base, self.generation = Path(base).resolve(), generation
        self.inventory, self.data_version, self.error = inventory or {}, data_version, error

    def resolve(self, relative):
        relative = str(relative).replace("\\", "/")
        if relative in self.inventory:
            return confined(self.generation / "files", relative)
        # The existing Python frontend uses an in-project junction to
        # images_collected. Preserve it; resolved targets must stay in base.
        return confined(self.base, relative, allow_links=True)

    def names(self, relative):
        folder = self.resolve(relative)
        names = {p.name for p in folder.iterdir()} if folder.is_dir() else set()
        prefix = relative.rstrip("/") + "/"
        names.update(p[len(prefix):] for p in self.inventory if p.startswith(prefix) and "/" not in p[len(prefix):])
        return sorted(names)


class DataUpdateManager:
    def __init__(self, base, store, app_version, downloader=download):
        self.base, self.store = Path(base).resolve(), Path(store).resolve()
        self.app_version, self.downloader = app_version, downloader
        if self.store == self.base or self.base.is_relative_to(self.store):
            raise UpdateError("Update store must be separate from base resources")

    def snapshot(self):
        errors = []
        try:
            pointer = json_bytes((self.store / "active.json").read_bytes())
        except FileNotFoundError:
            return DataSnapshot(self.base)
        except (OSError, ValueError) as exc:
            return DataSnapshot(self.base, error=str(exc))
        for descriptor in (pointer.get("active"), pointer.get("previous")) if isinstance(pointer, dict) else ():
            if not descriptor:
                continue
            try:
                key = descriptor["generation"]
                if not re.fullmatch(r"[0-9a-f]{32}", key):
                    raise UpdateError("Invalid generation")
                generation = confined(self.store, "generations/" + key)
                metadata = generation / "generation.json"
                if digest(metadata) != descriptor["sha256"]:
                    raise UpdateError("Generation metadata damaged")
                doc = json_bytes(metadata.read_bytes())
                compatible(doc, self.app_version)
                version(doc["data_version"])
                inventory = doc["inventory"]
                if not isinstance(inventory, dict) or len(inventory) > 8192:
                    raise UpdateError("Invalid generation inventory")
                for name, item in inventory.items():
                    path = confined(generation / "files", allowed_path(name))
                    if path.stat().st_size != item["size"] or digest(path) != item["sha256"]:
                        raise UpdateError("Active data damaged: " + name)
                return DataSnapshot(self.base, generation, inventory, doc["data_version"], "; ".join(errors) or None)
            except (OSError, ValueError, KeyError, TypeError) as exc:
                errors.append(str(exc))
        return DataSnapshot(self.base, error="; ".join(errors) or "No valid generation")

    def status(self):
        snapshot = self.snapshot()
        return {"data_version": snapshot.data_version, "base_data_version": BASE_DATA_VERSION,
                "app_version": self.app_version, "generation": snapshot.generation.name if snapshot.generation else None,
                "override_files": len(snapshot.inventory), "error": snapshot.error,
                "automatic_updates": False, "activation": "restart", "manifest_url": MANIFEST_URL}

    def check(self, manifest=None):
        try:
            if manifest is None:
                buffer = io.BytesIO()
                self.downloader(MANIFEST_URL, buffer, MAX_MANIFEST)
                manifest = json_bytes(buffer.getvalue())
            validate_manifest(manifest, self.app_version)
            current = self.snapshot()
            newer = version(manifest["data_version"]) > version(current.data_version)
            cumulative = manifest.get('cumulative_from_base') is True
            if newer and cumulative and not current.inventory.keys() <= {f['path'] for f in manifest['files']}:
                raise UpdateError('Cumulative update omits installed game overrides')
            if newer and manifest["base_data_version"] != current.data_version:
                if not (cumulative and version(manifest['base_data_version']) <= version(current.data_version)
                        < version(manifest['data_version'])):
                    raise UpdateError("Missing prerequisite data version")
            changes = []
            for item in manifest["files"]:
                path = current.resolve(item["path"])
                needs = not path.is_file() or path.stat().st_size != item["size"] or digest(path) != item["sha256"]
                changes.append(dict(item, download_required=needs))
            return {"success": True, "available": newer, "current_version": current.data_version,
                    "latest_version": manifest["data_version"], "description": manifest["description"], "files": changes}
        except (OSError, ValueError, TypeError, KeyError) as exc:
            return {"success": False, "available": False, "error": str(exc)}

    @contextmanager
    def _lock(self):
        self.store.mkdir(parents=True, exist_ok=True)
        lock_path = confined(self.store, "update.lock")
        with lock_path.open("a+b") as stream:
            stream.seek(0)
            if os.name == "nt":
                import msvcrt
                stream.write(b"\0"); stream.flush(); stream.seek(0)
                try:
                    msvcrt.locking(stream.fileno(), msvcrt.LK_NBLCK, 1)
                except OSError as exc:
                    raise UpdateError("Another data update is running") from exc
            else:
                import fcntl
                fcntl.flock(stream.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
            try:
                yield
            finally:
                stream.seek(0)
                if os.name == "nt":
                    msvcrt.locking(stream.fileno(), msvcrt.LK_UNLCK, 1)
                else:
                    fcntl.flock(stream.fileno(), fcntl.LOCK_UN)

    def apply(self, manifest, package_dir=None, checkpoint=None):
        """Explicit developer action only. Checkpoint is a crash-test injection hook."""
        stage = None
        try:
            validate_manifest(manifest, self.app_version)
            with self._lock():
                result = self.check(manifest)
                if not result["success"]:
                    raise UpdateError(result["error"])
                if not result["available"]:
                    return dict(result, applied=False)
                current = self.snapshot()
                key = uuid.uuid4().hex
                stage = confined(self.store, "staging/" + key)
                files = stage / "files"
                files.mkdir(parents=True)
                inventory = dict(current.inventory)
                for name in inventory:
                    target = confined(files, name)
                    target.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copyfile(current.resolve(name), target)
                for item in result["files"]:
                    name = item["path"]
                    target = confined(files, name)
                    target.parent.mkdir(parents=True, exist_ok=True)
                    if not item["download_required"]:
                        shutil.copyfile(current.resolve(name), target)
                    else:
                        with target.open("wb") as stream:
                            if package_dir is not None:
                                source = confined(package_dir, name)
                                if source.stat().st_size != item["size"]:
                                    raise UpdateError("Local file size mismatch: " + name)
                                with source.open("rb") as src:
                                    shutil.copyfileobj(src, stream, 65536)
                            else:
                                self.downloader(item["url"], stream, item["size"])
                            stream.flush(); os.fsync(stream.fileno())
                    if target.stat().st_size != item["size"] or digest(target) != item["sha256"]:
                        raise UpdateError("File size/SHA-256 mismatch: " + name)
                    validate_payload(name, target)
                    inventory[name] = {k: item[k] for k in ("size", "sha256")}
                # Verify inherited overlays too, so concurrent damage cannot be
                # committed as a successful update. Never revalidate baseline DB.
                for name, item in inventory.items():
                    path = confined(files, name)
                    if path.stat().st_size != item['size'] or digest(path) != item['sha256']:
                        raise UpdateError("Prepared generation damaged: " + name)
                candidate = DataSnapshot(self.base, stage, inventory, manifest["data_version"])
                self._validate_identities(current, candidate, {f["path"] for f in manifest["files"]})
                _write_json(stage / "generation.json", {
                    "data_version": manifest["data_version"], "compatible_app_versions": manifest["compatible_app_versions"],
                    "inventory": inventory, "description": manifest["description"]})
                if checkpoint:
                    checkpoint("prepared")
                generation = confined(self.store, "generations/" + key)
                generation.parent.mkdir(parents=True, exist_ok=True)
                os.replace(stage, generation)
                stage = None
                if checkpoint:
                    checkpoint("before_commit")
                descriptor = {"generation": key, "sha256": digest(generation / "generation.json")}
                previous = ({"generation": current.generation.name, "sha256": digest(current.generation / "generation.json")}
                            if current.generation else None)
                pointer_temp = confined(self.store, "pointer-" + key + ".tmp")
                _write_json(pointer_temp, {"active": descriptor, "previous": previous})
                os.replace(pointer_temp, confined(self.store, "active.json"))
                return {"success": True, "applied": True, "data_version": manifest["data_version"], "restart_required": True}
        except (OSError, ValueError, KeyError, TypeError) as exc:
            return {"success": False, "applied": False, "error": str(exc)}
        finally:
            if stage is not None and stage.exists():
                # Only this random, confined staging directory; never user/base files.
                try:
                    shutil.rmtree(stage)
                except OSError:
                    pass  # An orphan is inert; never trade a valid pointer for cleanup.

    def _validate_identities(self, old, new, changed):
        def read(snapshot, name):
            path = snapshot.resolve(name)
            return json_bytes(path.read_bytes()) if path.is_file() else {}
        for name in changed & JSON_FILES:
            previous, candidate = read(old, name), read(new, name)
            if 'schema_version' in previous and previous['schema_version'] != candidate.get('schema_version'):
                raise UpdateError("Game file schema migration requires an application update")
            for field, value in previous.items():
                if isinstance(value, (list, dict)) and type(candidate.get(field)) is not type(value):
                    raise UpdateError("Required game collection changed type: " + field)
            if name.endswith('gear_rules_v2.json') and not previous.get('sets', {}).keys() <= candidate['sets'].keys():
                raise UpdateError("Existing gear IDs cannot be removed")
            if name.endswith('mastery_66_full.json'):
                for tree in ('offense', 'defense', 'support'):
                    before_ids = {row['id'] for row in previous.get(tree, [])}
                    if not before_ids <= {row['id'] for row in candidate[tree]}:
                        raise UpdateError("Existing mastery IDs cannot be removed/remapped")
        skills_name = 'data/bulk_stage11/champion_skills_ko_game.json'
        schema_name = 'data/bulk_stage11/skill_display_schema_game.json'
        if changed & {skills_name, schema_name}:
            skills = read(new, skills_name)
            schema = read(new, schema_name)
            if schema:
                from skill_display_engine import compile_game_views
                try:
                    compile_game_views(skills, schema)
                except (ValueError, TypeError, KeyError, AttributeError, IndexError) as exc:
                    raise UpdateError("Incompatible skill data/display schema") from exc
            def references(doc):
                return {(c['champion_id'], v.get('game_hero_id'), f.get('form_index'), str(s['skill_id']))
                        for c in doc.get('champions', []) for v in c.get('game_variants', [])
                        for f in v.get('forms', []) for s in f.get('skills', [])}
            if not references(read(old, skills_name)) <= references(skills):
                raise UpdateError("Existing champion/form/skill ID links cannot be removed/remapped")
        manifest = "nightly_collection/manifest.json"
        names = "data/bulk_stage11/champion_names_ko_game.json"
        maps = []
        for snapshot in (old, new):
            mapping = {}
            for name, collection, field in ((manifest, "targets", "id"), (names, "entries", "champion_id")):
                for row in read(snapshot, name).get(collection, []):
                    en, cid = row["name_en"].strip().lower(), row[field]
                    if en in mapping and mapping[en] != cid:
                        raise UpdateError("Champion ID maps disagree")
                    mapping[en] = cid
            maps.append(mapping)
        if any(maps[1].get(name) != cid for name, cid in maps[0].items()):
            raise UpdateError("Existing champion IDs cannot be removed/remapped")
        for name in changed & {"data/champions.json", "data/champions_collected.json"}:
            rows = read(new, name)["champions"]
            keys, aliases = [], {}
            for row in rows:
                en = row["name_en"].strip().lower()
                cid = maps[1].get(en) or row.get("id")
                if not cid:
                    raise UpdateError("Updated champion requires explicit stable ID")
                if row.get("id") and row["id"] != cid:
                    raise UpdateError("Champion ID disagrees with identity map")
                keys.append(cid)
                for alias in (en, "champ_" + re.sub(r"[^a-z0-9]", "", en), str(cid)):
                    if alias in aliases and aliases[alias] != cid:
                        raise UpdateError("Champion lookup alias collision")
                    aliases[alias] = cid
            if len(keys) != len(set(keys)):
                raise UpdateError("Duplicate resolved champion ID")
            by_name = {r["name_en"].strip().lower(): r for r in rows}
            for row in read(old, name).get("champions", []):
                en = row["name_en"].strip().lower()
                if en not in by_name or (row.get("id") and by_name[en].get("id", maps[1].get(en)) != row["id"]):
                    raise UpdateError("Existing champion cannot be removed/remapped")
