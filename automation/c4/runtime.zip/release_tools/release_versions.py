"""Build numbering is separate from the unchanged game-data compatibility ABI."""
import re

from game_data_update import UpdateError, version


def build_numbers(build, compatibility):
    version(compatibility, True)
    if build == compatibility:
        return (*version(compatibility, True)[:3], version(compatibility, True)[4])
    match = re.fullmatch(re.escape(compatibility) + r'\.([1-9][0-9]*)', build)
    if not match or '-beta.' not in compatibility:
        raise UpdateError('Build must be a numbered correction of its compatibility version')
    revision = version(compatibility, True)[4] + int(match[1])
    if revision > 65535:
        raise UpdateError('Windows build revision exceeds 65535')
    return (*version(compatibility, True)[:3], revision)


def validate_release(build, compatibility, manifest, channel):
    from game_data_online import validate_online_manifest
    numbers = build_numbers(build, compatibility)
    if channel == 'stable' and '-' in build:
        raise UpdateError('Prerelease build cannot enter stable channel')
    if build != compatibility and manifest is None:
        raise UpdateError('Separate build/compatibility versions require an actual data manifest')
    if manifest is not None:
        validate_online_manifest(manifest, compatibility, channel)
    return numbers
